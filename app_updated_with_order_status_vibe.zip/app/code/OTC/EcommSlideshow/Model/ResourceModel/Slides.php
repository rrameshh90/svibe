<?php

namespace OTC\EcommSlideshow\Model\ResourceModel;

use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Slides
 */
class Slides extends AbstractDb
{

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('otc_ecommslideshow_slides', 'id');
    }

    /**
     * @param AbstractModel $object
     * @return Slides
     */
    protected function _beforeSave(AbstractModel $object)
    {
        $storeId = $object->getStoreId();
        if (is_array($storeId)) {
            $object->setStoreId(implode(',', $storeId));
        }

        return parent::_beforeSave($object);
    }

    /**
     * @param AbstractModel $object
     * @return Slides
     */
    protected function _afterLoad(AbstractModel $object)
    {
        $storeId = $object->getStoreId();
        if (!is_array($storeId)) {
            $storeId = explode(',', $storeId);
            $object->setStoreId($storeId);
        }

        return parent::_afterLoad($object);
    }

}
