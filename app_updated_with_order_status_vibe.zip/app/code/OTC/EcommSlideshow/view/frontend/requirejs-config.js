var config = {
    paths: {
        'jquery.cycle2': 'OTC_EcommSlideshow/js/jquery.cycle2.min',
        'jquery.actual': 'OTC_EcommSlideshow/js/jquery.actual.min',
        'ecommslideshow': 'OTC_EcommSlideshow/js/slideshow',
    }
};