<?php
declare(strict_types=1);

namespace Vibe\Crm\Model;

use Vibe\Crm\Api\Data\CrmDataInterface;

Class CrmApi implements CrmDataInterface
{
    /**
     * POST for CrmOrder api
     * @param  mixed $order_ids
     * @return string
     */
    public function postOrderItems($order_ids)
    {
      return "pass";
    }
}
