<?php

namespace OTC\Core\Helper;

use Exception;
use Magento\Catalog\Helper\Product\Compare;
use Magento\Cms\Model\Template\FilterProvider;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Area;
use Magento\Framework\App\Cache\Frontend\Pool;
use Magento\Framework\App\Cache\TypeListInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Config\Storage\WriterInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\App\State;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\DesignInterface;
use Magento\Store\Api\Data\StoreInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Wishlist\Helper\Data;
use OTC\Core\Block\ChildTemplate;

/**
 * Helper
 */
class Helper extends AbstractHelper //NOSONAR
{

    const XML_PATH_CORE_LAZY = 'otc_core_settings/general/lazyload';

    const CONFIG_MODULE = 'otc_core_settings';

    const CHILD_TEMPLATE = ChildTemplate::class;

    /**
     * @var array
     */
    protected $isArea = [];

    /**
     * @var WriterInterface
     */
    protected $writerInterface;

    /**
     * @var DesignInterface
     */
    protected $designInterface;

    /**
     * @var State
     */
    protected $state;

    /**
     * @var Session
     */
    protected $session;

    /**
     * @var Data
     */
    protected $wishlistHelper;

    /**
     * @var ProductMetadataInterface
     */
    protected $productMetadata;

    /**
     * @var Compare
     */
    protected $compareHelper;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManger;

    /**
     * @var Pool
     */
    protected $pool;

    /**
     * @var FilterProvider
     */
    protected $filterProvider;

    /**
     * @var UrlInterface
     */
    protected $urlInterface;

    /**
     * @var TypeListInterface
     */
    protected $typeList;


    /**
     * @param Context $context
     * @param WriterInterface $writerInterface
     * @param DesignInterface $designInterface
     * @param State $state
     * @param Session $session
     * @param Data $wishlistHelper
     * @param ProductMetadataInterface $productMetadata
     * @param Compare $compareHelper
     * @param StoreManagerInterface $storeManager
     * @param Pool $pool
     * @param FilterProvider $filterProvider
     * @param UrlInterface $urlInterface
     * @param TypeListInterface $typeList
     */
    public function __construct( //NOSONAR
        Context $context,
        WriterInterface $writerInterface,
        DesignInterface $designInterface,
        State $state,
        Session $session,
        Data $wishlistHelper,
        ProductMetadataInterface $productMetadata,
        Compare $compareHelper,
        StoreManagerInterface $storeManager,
        Pool $pool,
        FilterProvider $filterProvider,
        UrlInterface $urlInterface,
        TypeListInterface $typeList
    ) {
        $this->writerInterface = $writerInterface;
        $this->designInterface = $designInterface;
        $this->state = $state;
        $this->session = $session;
        $this->wishlistHelper = $wishlistHelper;
        $this->productMetadata = $productMetadata;
        $this->compareHelper = $compareHelper;
        $this->storeManger = $storeManager;
        $this->pool = $pool;
        $this->fileProvider = $filterProvider;
        $this->urlInterface = $urlInterface;
        $this->typeList = $typeList;

        parent::__construct($context);
    }

    /**
     * @param string $path
     * @param integer $storeCode
     * @param string $scopeType
     * @return mixed
     */
    public function getModuleConfig($path = '', $storeCode = null, $scopeType = ScopeInterface::SCOPE_STORE)
    {
        if (empty($path)) {
            $path = static::CONFIG_MODULE;
        } else {
            $path = static::CONFIG_MODULE . '/' . $path;
        }
        return $this->getSystemValue($path, $storeCode, $scopeType);
    }

    /**
     * @param string $path
     * @param integer $storeCode
     * @param string $scopeType
     * @return mixed
     */
    public function getSystemValue($path, $storeCode = null, $scopeType = ScopeInterface::SCOPE_STORE)
    {
        $value = $this->scopeConfig->getValue(
            $path,
            $scopeType,
            $storeCode
        );
        if (is_null($value)) {
            $value = '';
        }
        return $value;
    }

    /**
     * @param $path
     * @param $value
     * @param $scope
     * @param $scopeId
     * @return mixed
     */
    public function setModuleConfig(
        $path,
        $value,
        $scope = ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
        $scopeId = 0
    ) {
        if (!empty($path)) {
            $path = static::CONFIG_MODULE . '/' . $path;
        }
        return $this->setSystemValue($path, $value, $scope, $scopeId);
    }

    /**
     * @param $path
     * @param $value
     * @param $scope
     * @param $scopeId
     * @return mixed
     */
    public function setSystemValue($path, $value, $scope = ScopeConfigInterface::SCOPE_TYPE_DEFAULT, $scopeId = 0)
    {
        $result = $this->writerInterface->save($path, $value, $scope, $scopeId);
        $this->scopeConfig->clean();
        return $result;
    }

    /**
     * @return bool
     */
    public function isEnabled()
    {
        return true;
    }

    /**
     * @param $path
     * @param $scope
     * @param $scopeId
     * @return mixed
     */
    public function deleteSystemValue($path, $scope = ScopeConfigInterface::SCOPE_TYPE_DEFAULT, $scopeId = 0)
    {
        $result = $this->writerInterface->delete($path, $scope, $scopeId);
        $this->scopeConfig->clean();
        return $result;
    }

    /**
     * @return bool
     */
    public function isMobileTheme()
    {
        return (bool)preg_match('@^OTC\/mcomm@', $this->getThemeCode());
    }

    /**
     * @return string
     */
    public function getThemeCode()
    {
        return $this->designInterface->getDesignTheme()->getCode();
    }

    /**
     * @return bool
     */
    public function isLazyLoadEnabled()
    {
        return (bool)$this->getSystemValue(static::XML_PATH_CORE_LAZY);
    }

    /**
     * @param string $path
     * @return mixed
     */
    public function getSystemDefaultValue($path)
    {
        return $this->getSystemValue(
            $path,
            0,
            ScopeConfigInterface::SCOPE_TYPE_DEFAULT
        );
    }

    /**
     * @return bool
     */
    public function isAdmin()
    {
        return $this->isArea(Area::AREA_ADMINHTML);
    }

    /**
     * @param string $area
     * @return bool
     */
    public function isArea($area = Area::AREA_FRONTEND)
    {
        if (!isset($this->isArea[$area])) {
            $state = $this->state;

            try {
                $this->isArea[$area] = ($state->getAreaCode() == $area);
            } catch (Exception $e) {
                $this->isArea[$area] = false;
            }
        }

        return $this->isArea[$area];
    }

    /**
     * @param $block
     * @param $optionPath
     * @param $fileName
     * @param $arguments
     * @return string
     */
    public function getLayoutTemplateHtml($block, $optionPath = '', $fileName = '', $arguments = [])
    {
        $value = $this->getSystemValue($optionPath);

        if (is_string($value) || is_numeric($value)) {
            return $this->getLayoutTemplateHtmlbyValue($block, $value, $fileName, $arguments);
        }
        return '';
    }

    /**
     * @param $block
     * @param $value
     * @param $fileName
     * @param $arguments
     * @param $separator
     * @return mixed
     */
    public function getLayoutTemplateHtmlbyValue(
        $block,
        $value = null,
        $fileName = null,
        $arguments = [],
        $separator = '/'
    ) {
        $newfileName = '';
        if (empty($fileName)) {
            $blockTemplate = $block->getTemplate();
            if (preg_match('/(\.[^\.]+?)$/', $blockTemplate)) { //NOSONAR
                $fileName = preg_replace('/(\.[^\.]+?)$/', '%s%s$1', $blockTemplate); //NOSONAR
            } else {
                $fileName .= '%s%s';
            }
            if (!preg_match('#([^_\:])_([^_\:])\:\:#i', $fileName)) {
                $className = array_slice(array_filter(explode('\\', get_class($block))), 0, 2);
                if ('Magento' !== $className[0]) {
                    $fileName = implode('_', $className) . '::' . $fileName;
                }
            }
        } else {
            $newfileName = $fileName;
        }
        $blockName = $separator . $block->getNameInLayout() . $separator . $newfileName . $separator . $value;
        $fileName = sprintf($fileName, $separator, $value);
        while ($block->getLayout()->getBlock($blockName)) {
            $blockName .= '_0';
        }
        $block = $block->getLayout()->createBlock(static::CHILD_TEMPLATE, $blockName);
        $block->setChild($block->getNameInLayout(), $block);
        if (!empty($arguments) && is_array($arguments)) {
            $block->addData($arguments);
        }
        return $block->setTemplate($fileName)->toHtml();
    }

    /**
     * @param string $path
     * @param integer $storeCode
     * @return mixed
     */
    public function getConfig($path, $storeCode = null)
    {
        return $this->getSystemValue($path, $storeCode);
    }

    /**
     * @return mixed
     */
    public function isLoggedIn()
    {
        return $this->session->isLoggedIn();
    }

    /**
     * @return mixed
     */
    public function getWishlistCount()
    {
        return $this->wishlistHelper->getItemCount();
    }

    /**
     * @return bool
     */
    public function isLegacyJQuery()
    {
        return $this->getVersionCompare('2.3.2');
    }

    /**
     * @param string $version
     * @param string $operator
     * @return bool
     */
    public function getVersionCompare($version, $operator = '<=')
    {
        return version_compare($this->getVersion(), $version, $operator);
    }

    /**
     * Get Product version
     *
     * @return string
     */
    public function getVersion()
    {
        return $this->productMetadata->getVersion();
    }

    /**
     * @return mixed
     */
    public function getCompareListUrl()
    {
        return $this->compareHelper->getListUrl();
    }

    /**
     * @return mixed
     */
    public function getCompareListCount()
    {
        return $this->compareHelper->getItemCount();
    }

    /**
     * @param string $type
     * @param null $secure
     * @return string
     * @throws NoSuchEntityException
     */
    public function getBaseUrl($type = UrlInterface::URL_TYPE_LINK, $secure = null)
    {
        return $this->getStore()->getBaseUrl($type, $secure);
    }

    /**
     * @return StoreInterface
     * @throws NoSuchEntityException
     */
    public function getStore()
    {
        return $this->storeManger->getStore();
    }

    /**
     * @return bool
     */
    public function isMobile() //NOSONAR
    {
        $regexMatch = "/(nokia|iphone|android|motorola|^mot\-|softbank|foma|docomo|kddi|up\.browser|up\.link|"
            . "htc|dopod|blazer|netfront|helio|hosin|huawei|novarra|CoolPad|webos|techfaith|palmsource|"
            . "blackberry|alcatel|amoi|ktouch|nexian|samsung|^sam\-|s[cg]h|^lge|ericsson|philips|sagem|wellcom|bunjalloo|maui|" //NOSONAR
            . "symbian|smartphone|mmp|midp|wap|phone|windows ce|iemobile|^spice|^bird|^zte\-|longcos|pantech|gionee|^sie\-|portalmmm|" //NOSONAR
            . "jig\s browser|hiptop|^ucweb|^benq|haier|^lct|opera\s*mobi|opera\*mini|320x320|240x320|176x220"
            . ")/i";

        if (preg_match($regexMatch, strtolower((string)$_SERVER['HTTP_USER_AGENT']))) {
            return true;
        }

        if ((strpos(
                    strtolower(
                        (string)$_SERVER['HTTP_ACCEPT']
                    ),
                    'application/vnd.wap.xhtml+xml'
                ) > 0) or (isset($_SERVER['HTTP_X_WAP_PROFILE']) or isset($_SERVER['HTTP_PROFILE']))) { //NOSONAR
            return true;
        }

        $mobileUa = strtolower(substr($_SERVER['HTTP_USER_AGENT'], 0, 4));
        $mobileAgents = array(
            'w3c ',
            'acs-',
            'alav',
            'alca',
            'amoi',
            'audi',
            'avan',
            'benq',
            'bird',
            'blac',
            'blaz',
            'brew',
            'cell',
            'cldc',
            'cmd-',
            'dang',
            'doco',
            'eric',
            'hipt',
            'inno',
            'ipaq',
            'java',
            'jigs',
            'kddi',
            'keji',
            'leno',
            'lg-c',
            'lg-d',
            'lg-g',
            'lge-',
            'maui',
            'maxo',
            'midp',
            'mits',
            'mmef',
            'mobi',
            'mot-',
            'moto',
            'mwbp',
            'nec-',
            'newt',
            'noki',
            'oper',
            'palm',
            'pana',
            'pant',
            'phil',
            'play',
            'port',
            'prox',
            'qwap',
            'sage',
            'sams',
            'sany',
            'sch-',
            'sec-',
            'send',
            'seri',
            'sgh-',
            'shar',
            'sie-',
            'siem',
            'smal',
            'smar',
            'sony',
            'sph-',
            'symb',
            't-mo',
            'teli',
            'tim-',
            'tosh',
            'tsm-',
            'upg1',
            'upsi',
            'vk-v',
            'voda',
            'wap-',
            'wapa',
            'wapi',
            'wapp',
            'wapr',
            'webc',
            'winw',
            'winw',
            'xda ',
            'xda-'
        );

        if (in_array($mobileUa, $mobileAgents)) {
            return true;
        }

        if (isset($_SERVER['ALL_HTTP']) && strpos(strtolower((string)$_SERVER['ALL_HTTP']), 'OperaMini') > 0) {
            return true;
        }

        return false;
    }

    /**
     * @param $content
     * @return mixed
     */
    public function getBlockTemplateProcessor($content = '')
    {
        if (empty($content) || !is_string($content)) {
            $content = '';
        }
        $blockFilter = $this->filterProvider->getBlockFilter();
        return $blockFilter->filter(trim($content));
    }

    /**
     * @return bool
     */
    public function isHomePage()
    {
        $currentUrl = $this->getUrl('', ['_current' => true]);
        $urlRewrite = $this->getUrl('*/*/*', ['_current' => true, '_use_rewrite' => true]);
        return $currentUrl == $urlRewrite;
    }

    /**
     * @param $route
     * @param $params
     * @return string
     */
    public function getUrl($route = '', $params = [])
    {
        return $this->urlInterface->getUrl($route, $params);
    }

    /**
     * @return void
     */
    public function clearCache()
    {
        /** @var TypeListInterface $cacheTypeList */
        $cacheTypeList = $this->typeList;
        $types = [
            'config',
            'layout',
            'block_html',
            'collections',
            'reflection',
            'db_ddl',
            'eav',
            'config_integration',
            'config_integration_api',
            'full_page',
            'translate',
            'config_webservice',
        ];
        foreach ($types as $type) {
            $cacheTypeList->cleanType($type);
        }
        /** @var Pool $cacheFrontendPool */
        $cacheFrontendPool = $this->pool;
        foreach ($cacheFrontendPool as $cacheFrontend) {
            $cacheFrontend->getBackend()->clean();
        }
    }

}
