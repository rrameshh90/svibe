<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Vibe\Blog\Block;

use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\RequestInterface;

/**
 * Cms page content block
 *
 * @api
 * @since 100.0.2
 */
class Page extends \Magento\Framework\View\Element\AbstractBlock implements
    \Magento\Framework\DataObject\IdentityInterface
{
    /**
     * @var \Vibe\Blog\Model\Template\FilterProvider
     */
    protected $_filterProvider;

    /**
     * @var \Vibe\Blog\Model\Page
     */
    protected $_page;

    /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * Page factory
     *
     * @var \Vibe\Blog\Model\PageFactory
     */
    protected $_pageFactory;

    /**
     * @var \Magento\Framework\View\Page\Config
     */
    protected $pageConfig;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * Construct
     *
     * @param \Magento\Framework\View\Element\Context $context
     * @param \Vibe\Blog\Model\Page $page
     * @param \Vibe\Blog\Model\Template\FilterProvider $filterProvider
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Vibe\Blog\Model\PageFactory $pageFactory
     * @param \Magento\Framework\View\Page\Config $pageConfig
     * @param array $data
     */
    public function __construct(
        RequestInterface $request,
        \Magento\Framework\View\Element\Context $context,
        \Vibe\Blog\Model\Page $page,
        \Vibe\Blog\Model\Template\FilterProvider $filterProvider,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Vibe\Blog\Model\PageFactory $pageFactory,
        \Magento\Framework\View\Page\Config $pageConfig,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->request = $request;
        $this->_page = $page;
        $this->_filterProvider = $filterProvider;
        $this->_storeManager = $storeManager;
        $this->_pageFactory = $pageFactory;
        $this->pageConfig = $pageConfig;
    }

    public function getBlogId(): ?int
    {
        $id = $this->request->getParam('blog_id') ?? $this->request->getParam('id');
        return $id ? (int)$id : null;
    }

    /**
     * Retrieve Page instance
     *
     * @return \Vibe\Blog\Model\Page
     */
     public function getBlogPage()
     {
         if (!$this->hasData('blog_page')) {
             if ($this->getPageId()) {
                 /** @var \Vibe\Blog\Model\Page $page */
                 $page = $this->_pageFactory->create();
                 $page->setStoreId($this->_storeManager->getStore()->getId())->load($this->getPageId(), 'identifier');
             } else {
                 $page = $this->_page;
             }
             $this->setData('blog_page', $page);
         }
         return $this->getData('blog_page');
     }

    /**
     * Prepare global layout
     *
     * @return $this
     */
    protected function _prepareLayout()
    {
        $page = $this->getBlogPage();
        $this->_addBreadcrumbs($page);
        $this->pageConfig->addBodyClass('blog-' . $page->getIdentifier());
        $metaTitle = $page->getMetaTitle();
        $this->pageConfig->getTitle()->set($metaTitle ? $metaTitle : $page->getTitle());
        $this->pageConfig->setKeywords($page->getMetaKeywords());
        $this->pageConfig->setDescription($page->getMetaDescription());

        $pageMainTitle = $this->getLayout()->getBlock('page.main.title');
        if ($pageMainTitle) {
            // Setting empty page title if content heading is absent
            $cmsTitle = $page->getContentHeading() ?: ' ';
            $pageMainTitle->setPageTitle($this->escapeHtml($cmsTitle));
        }
        return parent::_prepareLayout();
    }

    /**
     * Prepare breadcrumbs
     *
     * @param \Vibe\Blog\Model\Page $page
     * @throws \Magento\Framework\Exception\LocalizedException
     * @return void
     */
    protected function _addBreadcrumbs(\Vibe\Blog\Model\Page $page)
    {
        $breadcrumbsBlock = $this->getLayout()->getBlock('breadcrumbs');
        $breadcrumbsBlock->addCrumb('blog_page', ['label' => $page->getTitle(), 'title' => $page->getTitle()]);
    }

    /**
     * Prepare HTML content
     *
     * @return string
     */
    protected function _toHtml()
    {
        $html = $this->_filterProvider->getPageFilter()->filter($this->getBlogPage()->getContent());
        return $html;
    }

    /**
     * Return identifiers for produced content
     *
     * @return array
     */
    public function getIdentities()
    {
        return [\Vibe\Blog\Model\Page::CACHE_TAG . '_' . $this->getBlogPage()->getId()];
    }
}
