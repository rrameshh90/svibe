<?php

/**
 * Image helper
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace OTC\BannerSlider\Helper;

use Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\Directory\WriteInterface;
use Magento\Framework\Image as MagentoImage;
use Magento\Framework\Image\Factory;
use Magento\Framework\UrlInterface;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Description of Image
 *
 * @author Master
 */
class Image extends AbstractHelper
{

    /**
     * @var
     */
    protected $baseFile;

    /**
     * @var int
     */
    protected $width;

    /**
     * @var int
     */
    protected $height;

    /**
     * Default quality value (for JPEG images only).
     *
     * @var int
     */
    protected $quality = 90;

    /**
     * @var bool
     */
    protected $keepAspectRatio = true;

    /**
     * @var bool
     */
    protected $keepFrame = true;

    /**
     * @var bool
     */
    protected $keepTransparency = true;

    /**
     * @var bool
     */
    protected $constrainOnly = true;

    /**
     * @var bool
     */
    protected $cropOnly = false;

    /**
     * @var int[]
     */
    protected $backgroundColor = [255, 255, 255];

    /**
     * @var MagentoImage
     */
    protected $processor;

    /**
     * @var string
     */
    protected $destinationSubdir;

    /**
     * @var WriteInterface
     */
    protected $mediaDirectory;

    /**
     * @var Factory
     */
    protected $imageFactory;

    /**
     * @var array
     */
    protected $attributes;

    /**
     * Store Manager
     *
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @param Context $context
     * @param Filesystem $filesystem
     * @param Factory $imageFactory
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        Filesystem $filesystem,
        Factory $imageFactory,
        StoreManagerInterface $storeManager
    ) {
        parent::__construct($context);
        $this->mediaDirectory = $filesystem->getDirectoryRead(DirectoryList::MEDIA);
        $this->imageFactory = $imageFactory;
        $this->storeManager = $storeManager;
    }

    /**
     * @param $file
     * @param $size
     * @param $attributes
     * @return $this
     * @throws Exception
     */
    public function adaptiveResize($file, $size, $attributes = [])
    {
        $this->init($file, $attributes);
        [$width, $height] = $this->prepareSize($size);
        $this->setWidth($width);
        $this->setHeight($height);
        if ($this->keepAspectRatio && $this->cropOnly) {
            $this->crop();
        }
        $this->resize();

        return $this;
    }

    /**
     * @param $file
     * @param $attributes
     * @return void
     * @throws Exception
     */
    public function init($file, $attributes = [])
    {
        $this->processor = null;

        $this->setBaseFile($file);

        $this->attributes = $attributes;
        $this->setImageProperties();
    }

    /**
     * Set image properties
     *
     * @return $this
     */
    protected function setImageProperties()
    {
        $this->setDestinationSubdir('resized');


        // Set 'keep frame' flag
        $frame = $this->getAttribute('frame');
        if (!empty($frame)) {
            $this->setKeepFrame($frame);
        }

        // Set 'constrain only' flag
        $constrain = $this->getAttribute('constrain');
        if (!empty($constrain)) {
            $this->setConstrainOnly($constrain);
        }

        // Set 'keep aspect ratio' flag
        $aspectRatio = $this->getAttribute('aspect_ratio');
        if (!empty($aspectRatio)) {
            $this->setKeepAspectRatio($aspectRatio);
        }


        // Set 'keep $crop' flag
        $crop = $this->getAttribute('crop');
        if (!empty($crop)) {
            $this->seCropOnly($crop);
        }

        // Set 'transparency' flag
        $transparency = $this->getAttribute('transparency');
        if (!empty($transparency)) {
            $this->setKeepTransparency($transparency);
        }

        // Set background color
        $background = $this->getAttribute('background');
        if (!empty($background)) {
            $this->setBackgroundColor($background);
        }

        return $this;
    }

    /**
     * Retrieve image attribute
     *
     * @param string $name
     * @return string
     */
    protected function getAttribute($name)
    {
        return $this->attributes[$name] ?? null;
    }

    /**
     * @param bool $keep
     * @return $this
     */
    public function setKeepFrame($keep)
    {
        $this->keepFrame = $keep && $keep !== 'false';
        return $this;
    }

    /**
     * @param bool $flag
     * @return $this
     */
    public function setConstrainOnly($flag)
    {
        $this->constrainOnly = $flag && $flag !== 'false';
        return $this;
    }

    /**
     * @param bool $keep
     * @return $this
     */
    public function setKeepAspectRatio($keep)
    {
        $this->keepAspectRatio = $keep && $keep !== 'false';
        return $this;
    }

    /**
     * @param bool $flag
     * @return $this
     */
    public function seCropOnly($flag)
    {
        $this->cropOnly = $flag && $flag !== 'false';
        return $this;
    }

    /**
     * @param bool $keep
     * @return $this
     */
    public function setKeepTransparency($keep)
    {
        $this->keepTransparency = $keep && $keep !== 'false';
        return $this;
    }

    /**
     * @param int[] $rgbArray
     * @return $this
     */
    public function setBackgroundColor(array $rgbArray)
    {
        $this->backgroundColor = $rgbArray;
        return $this;
    }

    /**
     * @param $size
     * @return array
     */
    private function prepareSize($size)
    {
        if (is_array($size) && 1 >= count($size)) {
            $size = array_shift($size);
        }
        if (!is_array($size)) {
            $size = [$size, $size];
        }
        $size = array_map('intval', $size);
        $size = array_map('abs', $size);
        return $size;
    }

    /**
     * @return $this
     */
    public function crop()
    {
        if ($this->getWidth() === null && $this->getHeight() === null) {
            return $this;
        }
        if ($this->fileExists($this->getResizedFile())) {
            return $this;
        }

        $imageSrcWidth = $this->getImageProcessor()->getOriginalWidth();
        $imageSrcHeight = $this->getImageProcessor()->getOriginalHeight();
        $imageSrcRatio = $imageSrcWidth / $imageSrcHeight;
        $ratio = $this->width / $this->height;

        if ($imageSrcRatio != $ratio) {
            if (1 > $imageSrcRatio) {
                $newHeight = round($imageSrcWidth / $ratio);
                $deltHeight = $imageSrcHeight - $newHeight;

                $deltHeight = floor($deltHeight / 2);
                $newdeltHeight = $deltHeight % 2;

                $this->getImageProcessor()->crop($deltHeight + $newdeltHeight, 0, 0, $deltHeight);
            } elseif (1 < $imageSrcRatio) {
                $newWidth = round($imageSrcHeight * $ratio);
                $deltWidth = $imageSrcWidth - $newWidth;

                $deltWidth = floor($deltWidth / 2);
                $newdeltWidth = $deltWidth % 2;

                $this->getImageProcessor()->crop(0, $deltWidth + $newdeltWidth, $deltWidth, 0);
            }
        }

        return $this;
    }

    /**
     * @return int
     */
    public function getWidth()
    {
        return $this->width;
    }

    /**
     * @param int $width
     * @return $this
     */
    public function setWidth($width)
    {
        $this->width = $width;
        return $this;
    }

    /**
     * @return int
     */
    public function getHeight()
    {
        return $this->height;
    }

    /**
     * @param int $height
     * @return $this
     */
    public function setHeight($height)
    {
        $this->height = $height;
        return $this;
    }

    /**
     * First check this file on FS
     * If it doesn't exist - try to download it from DB
     *
     * @param string $filename
     * @return bool
     */
    protected function fileExists($filename)
    {
        return file_exists($this->mediaDirectory->getAbsolutePath($filename));
    }

    /**
     * @return string|void
     */
    private function getResizedFile()
    {
        $newFilename = pathinfo($this->getBaseFile());
        if (is_array($newFilename) && !empty($newFilename)) {
            $newFilename['filename'] = implode('_', [
                    $newFilename['filename'],
                    $this->getWidth(),
                    $this->getHeight()
                ]) . '.' . $newFilename['extension'];
            return implode('/', [$this->getDestinationSubdir(), $newFilename['dirname'], $newFilename['filename']]);
        }
    }

    /**
     * @return string
     */
    public function getBaseFile()
    {
        return $this->baseFile;
    }

    /**
     * Set filenames for base file and new file
     *
     * @param string $file
     * @return $this
     * @throws Exception
     */
    public function setBaseFile($file)
    {
        if ($this->fileExists($file)) {
            $this->baseFile = $file;
        }

        return $this;
    }

    /**
     * @return string
     */
    public function getDestinationSubdir()
    {
        return $this->destinationSubdir;
    }

    /**
     * @param string $dir
     * @return $this
     */
    public function setDestinationSubdir($dir)
    {
        $this->destinationSubdir = $dir;
        return $this;
    }

    /**
     * @return MagentoImage
     */
    public function getImageProcessor()
    {
        if (!$this->processor) {
            $filename = $this->getBaseFile() ? $this->mediaDirectory->getAbsolutePath($this->getBaseFile()) : null;
            $this->processor = $this->imageFactory->create($filename);
        }
        $this->processor->keepAspectRatio($this->keepAspectRatio);
        $this->processor->keepFrame($this->keepFrame);
        $this->processor->keepTransparency($this->keepTransparency);
        $this->processor->constrainOnly($this->constrainOnly);
        $this->processor->backgroundColor($this->backgroundColor);
        $this->processor->quality($this->quality);
        return $this->processor;
    }

    /**
     * @return $this
     * @see \Magento\Framework\Image\Adapter\AbstractAdapter
     */
    public function resize()
    {
        if ($this->getWidth() === null && $this->getHeight() === null) {
            return $this;
        }

        $resizedFile = $this->getResizedFile();
        if ($resizedFile && $this->fileExists($resizedFile)) {
            return $this;
        }

        $newFilename = $this->mediaDirectory->getAbsolutePath($resizedFile);

        $this->getImageProcessor()->resize($this->width, $this->height);

        $this->getImageProcessor()->save($newFilename);

        return $this;
    }

    /**
     * @param MagentoImage $processor
     * @return $this
     */
    public function setImageProcessor($processor)
    {
        $this->processor = $processor;
        return $this;
    }

    /**
     * Get image quality
     *
     * @return int
     */
    public function getQuality()
    {
        return $this->quality;
    }

    /**
     * Set image quality, values in percentage from 0 to 100
     *
     * @param int $quality
     * @return $this
     */
    public function setQuality($quality)
    {
        $this->quality = $quality;
        return $this;
    }

    /**
     * @return string
     * @throws NoSuchEntityException
     */
    public function getUrl()
    {
        return $this->storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_MEDIA) . $this->getResizedFile();
    }

    /**
     * @param string $size
     * @return $this
     */
    public function setSize($size)
    {
        // determine width and height from string
        $width = $height = 0;

        if (is_numeric($size)) {
            $width = $height = $size;
        } elseif (is_array($size)) {
            if (1 >= count($size)) {
                [$width, $height] = $size;
            } else {
                $width = $height = array_shift($size);
            }
        } elseif (is_string($size)) {
            [$width, $height] = explode('x', strtolower($size), 2);
        }


        foreach (['width', 'height'] as $wh) {
            ${$wh} = (int)${$wh};
            if (empty(${$wh})) {
                ${$wh} = null;
            }
        }

        // set sizes
        $this->setWidth($width)->setHeight($height);

        return $this;
    }

    /**
     * @param $file
     * @return void
     * @throws Exception
     */
    public function removeResized($file)
    {
        if (!empty($file)) {
            $this->init($file);
        }
        $file = $this->getBaseFile();

        if (!empty($file)) {
            $newFilename = pathinfo($file);
            $newFilename['filename'] = implode('_', [$newFilename['filename'], '*']) . '.' . $newFilename['extension'];
            $pattern = implode('/', [$this->getDestinationSubdir(), $newFilename['dirname'], $newFilename['filename']]);
            $pattern = $this->mediaDirectory->getAbsolutePath($pattern);
            $files = (array)@glob($pattern);
            if (!empty($files)) {
                foreach ($files as $file) {
                    if (file_exists($file)) {
                        @unlink($file);
                    }
                }
            }
        }
    }

    /**
     * Get image size
     *
     * @param string $imagePath
     * @return array
     */
    private function getImageSize($imagePath)
    {
        return getimagesize($imagePath);
    }

}
