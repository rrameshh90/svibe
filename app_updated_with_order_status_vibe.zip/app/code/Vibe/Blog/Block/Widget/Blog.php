<?php

namespace Vibe\Blog\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Widget\Block\BlockInterface;
use Vibe\Blog\Model\PageFactory;
use Magento\Framework\UrlInterface;

class Blog extends Template implements BlockInterface
{

    protected $_template = "widget/blog.phtml";

    /**
     * @var PageFactory
     */
    protected PageFactory $pageFactory;

    /**
     * @var StoreManagerInterface
     */
    protected StoreManagerInterface $storeManager;

    /**
     * @param StoreManagerInterface $storeManager
     * @param Context $context
     * @param PageFactory $pageFactory
     * @param array $data
     */
    public function __construct(
        StoreManagerInterface $storeManager,
        Context $context,
        PageFactory   $pageFactory,
        array $data = []
    )
    {
        parent::__construct($context, $data);
        $this->storeManager = $storeManager;
        $this->pageFactory = $pageFactory;
    }

    /**
     * @param $blogId
     * @return mixed
     */
    public function getBlogData($blogId)
    {
        $model = $this->pageFactory->create()->load($blogId);
        return $model;
    }

    /**
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */

    public  function mediaUrl(): string
    {
        return $this->storeManager->getStore()
                        ->getBaseUrl(UrlInterface::URL_TYPE_MEDIA).'blog/image/';
    }
}
