<?php

namespace OTC\EcommSlideshow\Controller\Adminhtml;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\Page;
use Magento\Framework\Registry;

/**
 * Slides
 */
abstract class Slides extends Action
{

    /**
     * @var Registry
     */
    protected $coreRegistry;

    /**
     * @var
     */
    protected $slidesFactory;

    /**
     * @param Context $context
     * @param Registry $coreRegistry
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry
    ) {
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context);
    }

    /**
     * Init page
     *
     * @param Page $resultPage
     * @return Page
     */
    public function initPage($resultPage)
    {
        $resultPage->setActiveMenu('OTC_Core::OTC_Core')
            ->addBreadcrumb(__('Slideshow'), __('Slideshow'))
            ->addBreadcrumb(__('Ecom slider Slides'), __('Ecom slider Slides'));
        return $resultPage;
    }

}
