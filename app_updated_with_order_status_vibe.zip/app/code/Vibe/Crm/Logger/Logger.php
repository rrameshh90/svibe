<?php
namespace Vibe\Crm\Logger;

/**
 * Crm Response Order Log
 */
class Logger extends \Monolog\Logger
{
}
