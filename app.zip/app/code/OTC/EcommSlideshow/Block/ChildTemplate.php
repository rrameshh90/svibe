<?php

namespace OTC\EcommSlideshow\Block;

use OTC\Core\Block\ChildTemplate as coreChildTemplate;

/**
 * ChildTemplate
 */
class ChildTemplate extends coreChildTemplate
{

}
