<?php
/**
 * Image helper
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace OTC\Ecomm\Helper;

/**
 * Image
 */
class Image extends \OTC\Core\Helper\Image
{

}
