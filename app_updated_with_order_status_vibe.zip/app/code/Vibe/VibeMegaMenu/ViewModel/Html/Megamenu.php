<?php

namespace Vibe\VibeMegaMenu\ViewModel\Html;
use  Magento\Cms\Block\Block;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
class Megamenu implements \Magento\Framework\View\Element\Block\ArgumentInterface
{
    /**
     * @var Block
     */
    protected $cmsBlock;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @param Block $cmsBlock
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        Block $cmsBlock,
        ScopeConfigInterface $scopeConfig
    ){
        $this->cmsBlock = $cmsBlock;
        $this->scopeConfig = $scopeConfig;
    }
    /**
     * @param $blockIdentifier
     * @return string
     */
    public function getMegaMenuBlock($blockIdentifier){
        return $this->cmsBlock->setBlockId($blockIdentifier)->toHtml();
    }

    /**
     * @param $path
     * @param $storeCode = null
     * @return boolean
     */
    public function getSystemValue($path, $storeCode = null){
        return $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeCode);
    }
}
