<?php
namespace Vibe\StripeOrder\Model\Api;

use Magento\Framework\Config\Data\ConfigData;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\GiftMessage\Model\OrderRepository;
use Magento\Sales\Api\OrderRepositoryInterface;
use Vibe\StripeOrder\Logger\Logger;
use Vibe\StripeOrder\Helper\Data;
use Magento\Framework\Encryption\EncryptorInterface;

/**
 * Class PaymentInformation
 * @package Vibe\StripeOrder\Model\Api
 */
class PaymentInformation implements \Vibe\StripeOrder\Api\OrderInterface
{
     /**
     * @var Logger
     */
    protected $logger;
    /**
     * @var OrderRepository
     */
    protected $orderRepository;
    /**
     * @var $curl
     */
    protected $curl;
    /**
     * @var ConfigData
     */
    protected $configData;
    /**
     * @var string
     */
    protected $urlPrefix = 'https://';

    /**
     * @var string
     */
    protected $apiUrl = 'api.stripe.com/v1/checkout/sessions/';

    /**
     * @var json
     */
    protected $json;

    /**
     * @param Logger $logger
     * @param OrderRepositoryInterface $orderRepository
     * @param Curl $curl
     * @param EncryptorInterface $encryptor
     * @param Data $configData
     * @param Json $json
     */

    public function __construct(
 	Logger         $logger,
        OrderRepositoryInterface $orderRepository,
        Curl                     $curl,
        EncryptorInterface       $encryptor,
	    Data                     $configData,
        Json $json

    )
    {
        $this->logger = $logger;
        $this->orderRepository = $orderRepository;
        $this->curl = $curl;
        $this->configData = $configData;
	    $this->encryptor = $encryptor;
        $this->json = $json;
    }


   /**
     * @return string
     */
    public function getApiUrl(): string
    {
        return $this->urlPrefix . $this->apiUrl;
    }


    /**
     * @param string $order_id
     * @return string
     */
    public function getOrderItem($order_id)
    {
	    try {
            $apiUrl = $this->getApiUrl();
            $order = $this->orderRepository->get($order_id);
            $this->logger->info("Stripe Request Order Id : ". \GuzzleHttp\json_encode($order_id));
            if ($order) {
                if ($order->getPayment()->getMethod() == 'stripe_payments_checkout') {
                    $stripe_sessionId = $order->getPayment()->getAdditionalInformation('checkout_session_id');
                    $this->logger->info("Checkout Session Id : ". \GuzzleHttp\json_encode($stripe_sessionId));
                    $this->curl->setOption(CURLOPT_TIMEOUT, 60);
                    $this->curl->addHeader("Content-Type", "application/json");
                    $secretApiKey = $this->encryptor->decrypt($this->configData->getStripeKey($order->getStoreId()));
                    $this->logger->info("API Secret Key : ". \GuzzleHttp\json_encode($secretApiKey));
                    $headers = ["Content-Type" => "application/json", "Authorization" => "Bearer " . $secretApiKey];
                    $this->curl->setHeaders($headers);
                    $this->curl->get($apiUrl . $stripe_sessionId);
                    $paymentResponse = $this->curl->getBody();
                    $this->logger->info("Stripe Order Response Data : ". \GuzzleHttp\json_encode($paymentResponse));
		            $result[] = ['success' => true, 'message' => $this->json->unserialize($paymentResponse)];
		            return $result;

                }
            } else {
                $this->logger->info("Information Not Available For This Order: ". \GuzzleHttp\json_encode($order_id));
                $response[] = ['success' => false, 'message' => "No Order Information Found"];
                return $response;
		}
        } catch (\Exception $e) {
               $response = ['success' => false, 'message' => $e->getMessage()];
               $this->logger->info("Information Not Available For This Order: ". \GuzzleHttp\json_encode($response));
            }

   }
}

