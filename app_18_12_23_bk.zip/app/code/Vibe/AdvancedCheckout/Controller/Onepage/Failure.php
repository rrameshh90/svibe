<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Vibe\AdvancedCheckout\Controller\Onepage;

class Failure extends \Magento\Checkout\Controller\Onepage\Failure
{
    /**
     * @return \Magento\Framework\View\Result\Page|\Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        $lastQuoteId = $this->getOnepage()->getCheckout()->getLastQuoteId();
        $lastOrderId = $this->getOnepage()->getCheckout()->getLastOrderId();
        $lastRealOrderId = $this->getOnepage()->getCheckout()->getLastRealOrderId();

        if (!$lastQuoteId || !$lastOrderId) {
            return $this->resultRedirectFactory->create()->setPath('checkout/cart');
        }
        $resultPage = $this->resultPageFactory->create();
        $storeName = $this->scopeConfig->getValue('general/store_information/name',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $resultPage->getConfig()->getTitle()->set(($storeName!='') ? $storeName." Payment Failure | ".$lastRealOrderId :"Payment Failure | ".$lastRealOrderId);
        return $resultPage;
    }
}
