<?php
namespace Vibe\StripePayment\Model;

use Magento\Framework\Serialize\Serializer\Json;
use Vibe\StripePayment\Api\StripeApiInterface;
use Vibe\StripePayment\Helper\Data;
use Magento\Framework\Encryption\EncryptorInterface;

/**
 * StripePayment Api Model.
 */

class StripeApi implements StripeApiInterface
{

    /**
     * @var  $stripeData
     */
    protected $stripeData;

    /**
     * @var json $json
     */
    protected $json;

    /**
     * @param Data $stripeData
     * @param Json $json
     */

    public function __construct(
        Data $stripeData,
        Json $json
    )
    {
        $this->stripeData = $stripeData;
        $this->json = $json;
    }
    /**
     * @inheritDoc
     */
    public function getAllStripes()
    {

      if($this->stripeData->getStripeInfo())
        return $this->stripeData->getStripeInfo();
      else
          return "No Information Available.";

    }


}
