<?php

namespace OTC\Ecomm\Block;

use Magento\Framework\App\Http\Context;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;

/**
 * SocialIcons
 */
class SocialIcons extends Template implements BlockInterface
{

    /**
     * @var Context
     */
    protected $httpContext;

    /**
     * Json Serializer Instance
     *
     * @var Json
     */
    private $json;

    /**
     * @param Template\Context $context
     * @param Context $httpContext
     * @param Json $json
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Context $httpContext,
        Json $json,
        array $data = []
    ) {
        $this->httpContext = $httpContext;
        $this->json = $json;
        parent::__construct($context, $data);
    }

    /**
     * @param $newval
     * @return array
     * @throws NoSuchEntityException
     */
    public function getCacheKeyInfo($newval = [])
    {
        return array_merge([
            'SHOPXP_SOCIALICONS_WIDGET',
            $this->_storeManager->getStore()->getId(),
            $this->_design->getDesignTheme()->getId(),
            $this->httpContext->getValue(\Magento\Customer\Model\Context::CONTEXT_GROUP),
            $this->json->serialize($this->getRequest()->getParams()),
            $this->json->serialize($this->getData()),
        ], parent::getCacheKeyInfo(), $newval);
    }

    /**
     * @return string
     */
    public function getSocialsId()
    {
        return 'sp_' . $this->getNameInLayout();
    }

    /**
     * @return array
     */
    public function getSocialLinks()
    {
        $social = [
            'facebook',
            'facebook_messenger',
            'instagram',
            'twitter',
            'pinterest',
            'skype',
            'tumblr',
            'youtube',
            'amazon',
            'amazon_pay',
            'kickstarter',
            'stripe',
            'paypal',
            'vimeo',
            'vk',
            'foursquare',
            'flickr',
            'linkedin',
            'whatsapp',
            'telegram_plane',
            'snapchat',
            'reddit',
            'discord',
            'slack',
            'tripadvisor',
            'tiktok',
            'business'
        ];
        $socialLink = [];
        $socialOrder = [];
        foreach ($social as $newSocial) {
            $link = $this->getData($newSocial . '_link');
            if ($link) {
                $socialLink[$newSocial] = $link;
                $order = $this->getData($newSocial . '_sort');
                if (empty($order)) {
                    $order = 0;
                }
                $socialOrder[$newSocial] = abs((int)$order);
            }
        }
        asort($socialOrder);
        $result = [];
        foreach ($socialOrder as $newSocial => $order) {
            $result[$newSocial] = $socialLink[$newSocial];
        }
        return $result;
    }

    /**
     * @param array $style
     * @return string
     */
    public function prepareStyleBlock(array $style)
    {
        $result = [];
        foreach ($style as $selector => $newStyle) {
            $result[$selector] = $this->prepareStyle($newStyle);
        }
        $result = array_filter($result);
        if (!empty($result)) {
            foreach ($result as $selector => $newStyle) {
                $result[$selector] = $selector . '{' . $newStyle . '}';
            }
            return '<style>' . implode("\n", $result) . '</style>';
        }
        return '';
    }

    /**
     * @param array $style
     * @param string $separatorValue
     * @param string $separatorAttribute
     * @return string
     */
    public function prepareStyle(array $style, string $separatorValue = ': ', string $separatorAttribute = ';')
    {
        $style = array_filter($style);
        if (empty($style)) {
            return '';
        }
        foreach ($style as $key => &$value) {
            $value = $key . $separatorValue . $value;
        }
        $style = implode($separatorAttribute, $style);

        return $style;
    }


}
