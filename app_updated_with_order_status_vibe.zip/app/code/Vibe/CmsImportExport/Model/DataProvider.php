<?php
/**
 * Copyright Vibe © 2023. All rights reserved.
 *
 */
namespace Vibe\CmsImportExport\Model;

class DataProvider extends \Magento\Framework\View\Element\UiComponent\DataProvider\DataProvider
{
    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        return [];
    }

}
?>
