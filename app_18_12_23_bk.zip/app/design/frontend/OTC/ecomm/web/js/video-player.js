define([
    'jquery',
    'mage/url'
], function ($,url) {
    $(".video-player-thumbnail").click(function () {
        var play_icon = url.build('media/vibe_icons/play_icon.png');
        var video_Id = $(this).find(".video-player-thumbnail-image").attr("data-videoId");
        var active_icon = $("<img />", {
            src: play_icon,
            alt: "playing",
            class: "video-player-thumbnail-image-active"
        })
        if (video_Id) {
            $(".video-player-main iframe").attr("src", `https://www.youtube.com/embed/${video_Id}?rel=0`);
            $(".video-player-thumbnail-image-active").remove();
            $(this).find(".video-player-thumbnail-image-wrapper").append(active_icon);
            $(".video-player-main")[0]?.scrollIntoView({ behavior: 'smooth' });
        }
    })
});
