var config = {
    paths: {
        'SPBannerSlider': 'OTC_BannerSlider/bannerslider'
    }
};