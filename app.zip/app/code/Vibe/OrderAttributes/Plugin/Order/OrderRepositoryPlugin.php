<?php

namespace Vibe\OrderAttributes\Plugin\Order;

use Magento\Sales\Api\Data\OrderExtensionFactory;
use Magento\Sales\Api\Data\OrderExtensionInterface;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\Data\OrderSearchResultInterface;
use Magento\Sales\Api\OrderRepositoryInterface;

/**
 * Class OrderRepositoryPlugin
 */
class OrderRepositoryPlugin
{
    /**
     * Order Marketing Consent name
     */
    const OTC_MARKETING_CONSENT = 'otc_marketing_consent';

    /**
     * Order Zapier field name
     */
    const CRM_STATUS = 'crm_status';

    /**
     * Order Extension Attributes Factory
     *
     * @var OrderExtensionFactory
     */
    protected $extensionFactory;

    /**
     * OrderRepositoryPlugin constructor
     *
     * @param OrderExtensionFactory $extensionFactory
     */
    public function __construct(OrderExtensionFactory $extensionFactory)
    {
        $this->extensionFactory = $extensionFactory;
    }

    /**
     * Add "custom extension attribute" extension attribute to order data object to make it accessible in API data of order record
     *
     * @param OrderRepositoryInterface $subject
     * @param OrderInterface $order
     * @return OrderInterface
     */
    public function afterGet(OrderRepositoryInterface $subject, OrderInterface $order): OrderInterface
    {
        $marketing = $order->getData(self::OTC_MARKETING_CONSENT);
        $crm = $order->getData(self::CRM_STATUS);
        $extensionAttributes = $order->getExtensionAttributes();
        $extensionAttributes = $extensionAttributes ? $extensionAttributes : $this->extensionFactory->create();
        if($marketing){
            $extensionAttributes->setOtcMarketingConsent(1);
        }
        else
            $extensionAttributes->setOtcMarketingConsent(0);

        $extensionAttributes->setCrmStatus($crm);
        $order->setExtensionAttributes($extensionAttributes);
        return $order;
    }

    /**
     * Add "custom extension attribute" extension attribute to order data object to make it accessible in API data of all order list
     *
     * @param OrderRepositoryInterface $subject
     * @param OrderSearchResultInterface $searchResult
     * @return OrderSearchResultInterface
     */
    public function afterGetList(OrderRepositoryInterface $subject, OrderSearchResultInterface $searchResult): OrderSearchResultInterface
    {
        $orders = $searchResult->getItems();

        foreach ($orders as &$order) {
            $marketingList = $order->getData(self::OTC_MARKETING_CONSENT);
            $crmdata = $order->getData(self::CRM_STATUS);
            $extensionAttributes = $order->getExtensionAttributes();
            $extensionAttributes = $extensionAttributes ? $extensionAttributes : $this->extensionFactory->create();
            if($marketingList){
                $extensionAttributes->setOtcMarketingConsent(1);
            }
            else
                $extensionAttributes->setOtcMarketingConsent(0);

            $extensionAttributes->setCrmStatus($crmdata);
            $order->setExtensionAttributes($extensionAttributes);
        }

        return $searchResult;
    }
}
