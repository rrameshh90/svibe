<?php

namespace OTC\CustomSettings\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

/**
 * Config
 */
class Config extends AbstractHelper
{

    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    public function getConfig($path, $storeCode = null)
    {
        return $this->getSystemValue($path, $storeCode);
    }

    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    public function getSystemValue($path, $storeCode = null)
    {
        $value = $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeCode);
        if (is_null($value)) {
            $value = '';
        }
        return $value;
    }

    /**
     * @param $path
     * @param null $storeCode
     * @param null $group
     * @param null $field
     * @return mixed|string
     */
    public function getStylesConfig($path, $storeCode = null, $group = null, $field = null)
    {
        return $this->getStyleOptionValue($path, $storeCode, $group, $field);
    }

    /**
     * @param $path
     * @param null $storeCode
     * @param $group
     * @param $field
     * @return array
     */
    public function getStyleOptionValue($path, $storeCode = null, $group = null, $field = null)
    {
        $value = $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeCode);
        if (is_null($value)) {
            $value = '';
        }
        return $this->getModifiedVarConfigs($value[$group][$field]);
    }

    /**
     * @param $config
     * @return array
     */
    public function getModifiedVarConfigs($config)
    {
        $options = [];
        if ($config) {
            $values = (array)json_decode($config, true);

            foreach ($values as $value) {
                $options[] = $value;
            }
        }
        return $options;
    }
}
