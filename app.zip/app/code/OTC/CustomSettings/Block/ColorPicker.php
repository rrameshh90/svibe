<?php

namespace OTC\CustomSettings\Block;

use Magento\Config\Block\System\Config\Form\Field;

/**
 * ColorPicker
 */
class ColorPicker extends Field
{

    /**
     * @return string
     */
    protected function _toHtml()
    {
        $html = '<input type="text" class="sp-ss-colorpicker" name="'
            . $this->getInputName() . '" id="' . $this->getInputId() . '" ';
        $html .= '<script type="text/javascript">
                        require(["jquery","spectrum"], function ($) {
                             $(".sp-ss-colorpicker").spectrum({
            preferredFormat: "rgb",
            allowEmpty: true,
            showAlpha: true,
            showInput: true,
            move: function (tinycolor) {
                $(this).hide();
                var value = "";
                if (tinycolor && tinycolor.hasOwnProperty("_a")) {
                    if (1 > tinycolor._a) {
                        value = tinycolor.toRgbString();
                    } else {
                        value = tinycolor.toHexString();
                    }
                    $(this).val(value);
                }
            }
        }).attr("type", "hidden");
                        });
                    </script>';

        return $html;
    }
}

