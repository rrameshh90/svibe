var config = {
    map: {
        '*': {
            orderReturnJS: 'Vibe_OrderReturn/js/orderReturn'
        }
    }
};