<?php
namespace Vibe\StripeOrder\Logger;

/**
 * Stripe Payment Log
 */
class Logger extends \Monolog\Logger
{
}