<?php


namespace OTC\MegaMenu\Model\Cache;

use Magento\Framework\App\Cache\Type\FrontendPool;
use Magento\Framework\Cache\Frontend\Decorator\TagScope;

/**
 * MegaMenu
 */
class MegaMenu extends TagScope
{


    const TYPE_IDENTIFIER = 'sp_megamenu';

    const CACHE_TAG = 'SPMEGAMENU';

    /**
     * @param FrontendPool $cacheFrontendPool
     */
    public function __construct(
        FrontendPool $cacheFrontendPool
    ) {
        parent::__construct($cacheFrontendPool->get(self::TYPE_IDENTIFIER), self::CACHE_TAG);
    }
}