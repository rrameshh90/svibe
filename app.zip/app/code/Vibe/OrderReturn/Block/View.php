<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Vibe\OrderReturn\Block;

use Magento\Sales\Model\Order;

/**
 * One page checkout success page
 *
 * @api
 * @since 100.0.2
 */
class View extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Sales\Model\Order\Config
     */
    protected $orderConfig;

    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected  $orderFactory;

    /**
     * @var \Magento\Framework\Pricing\PriceCurrencyInterface
     */
    protected $priceCurrency;

    /**
     * @var \Magento\Directory\Model\Currency
     */
    protected $currency;

    /**
     * @var \Magento\Sales\Model\Order\Address\Renderer
     */
    protected $addressRenderer;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    public $storeManager;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlBuilder;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    public $productRepository;

    /**
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
     * @param \Magento\Framework\UrlInterface $urlBuilder
     * @param \Magento\Directory\Model\Currency $currency
     * @param \Magento\Framework\Pricing\PriceCurrencyInterface $priceCurrency
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param Order\Address\Renderer $addressRenderer
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param array $data
     */

    public function __construct(
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Framework\UrlInterface $urlBuilder,
        \Magento\Directory\Model\Currency $currency,
        \Magento\Framework\Pricing\PriceCurrencyInterface $priceCurrency,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Sales\Model\Order\Address\Renderer $addressRenderer,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->productRepository = $productRepository;
        $this->urlBuilder = $urlBuilder;
        $this->priceCurrency = $priceCurrency;
        $this->currency = $currency;
        $this->addressRenderer = $addressRenderer;
        $this->storeManager = $storeManager;
        $this->orderFactory = $orderFactory;
    }

    /**
     * @return mixed
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */

    public function getCurrentCurrencyCode()
    {
        return $this->storeManager->getStore()->getCurrentCurrencyCode();
    }

    /**
     * @param $currencyCode
     * @return string
     */
    public function getCurrentCurrencySymbolByCode($currencyCode)
    {
        return  $this->currency->load($currencyCode)->getCurrencySymbol();
    }

    /**
     * @param $price
     * @return string
     */
    public function getCurrencyWithFormat($price)
    {
        return $this->priceCurrency->format($price,true,2);
    }

    /**
     * @param $price
     * @param $currencySymbol
     * @return string
     */

    public function getOrderPaymentFormat($price,$currencySymbol){
        return $this->currency->format($price, ['symbol' => $currencySymbol, 'precision'=> 2], false, false);
    }

    /**
     * @param $address
     * @return string|null
     */

    public function getAddressFormatHtml($address){
        return $this->addressRenderer->format($address, 'html');
    }

    /**
     * Initialize data and prepare it for output
     *
     * @return string
     */
    public function _beforeToHtml()
    {
        $this->prepareBlockData();
        return parent::_beforeToHtml();
    }

    /**
     * Prepares block data
     *
     * @return void
     */
    public function prepareBlockData()
    {
        $orderId = $this->getRequest()->getParam('order_id');
        $order = $this->orderFactory->create()->loadByIncrementId($orderId);

        $this->addData(
            [
                'print_url' => $this->getUrl(
                    'sales/order/print',
                    ['order_id' => $order->getEntityId()]
                ),
                'order_id'  => $order->getIncrementId()
            ]
        );
    }


    /**
     * @return string
     * @since 100.2.0
     */
    public function getReturnRequestUrl()
    {
        return $this->urlBuilder->getUrl(
            'return/index/returnRequest',
            ['_secure' => true]
        );
    }

    /**
     * @param $orderId
     * @return mixed
     */

    public function getOrderInfo($orderId){
        return $this->orderFactory->create()->loadByIncrementId($orderId);
    }
}
