<?php
namespace Vibe\Contact\Helper;

use Magento\Framework\App\Helper\Context;
use Vibe\Contact\Logger\Logger;
use Vibe\Contact\Helper\Config;

/**
 * Class ContactLog
 * @package Vibe\Contact\Model\ContactLog
 */
class ContactLog extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var contactLogger
     */
    protected $contactLogger;
    /**
     * @var configHelper
     */
    protected $configHelper;

    /**
     * LogData constructor.
     * @param Context $context
     * @param Logger $contactLogger
     * @param Config $configHelper
     */
    public function __construct(
        Context $context,
        Logger $contactLogger,
        Config $configHelper
    ) {
        parent::__construct($context);
        $this->contactLogger = $contactLogger;
        $this->configHelper = $configHelper;
    }

    /**
     * @param $message
     * @param $data
     */
    public function logData($message, $data)
    {
        $debugMode = $this->configHelper->getDebugMode();
        if ($debugMode) {
            $this->contactLogger->info($message. \GuzzleHttp\json_encode($data));
        }
    }
}
