<?php
declare(strict_types=1);

namespace Vibe\Contact\Model;

use Magento\Contact\Model\MailInterface;
use Magento\Framework\DataObjectFactory;
use Vibe\Contact\Api\CategoryServiceInterface;
use Vibe\Contact\Helper\ContactLog;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Serialize\Serializer\Json;
use Vibe\Contact\Model\CategoryFactory;
use Magento\Store\Api\StoreRepositoryInterface;

/**
 * Class CategoryManagement
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class CategoryManagement implements CategoryServiceInterface
{

    /**
     * @var mail
     */
    private $mail;

    /**
     * @var data
     */
    protected $dataObjectFactory;
    /**
     * @var formdata
     */
    protected $formData;
    /**
     * @var LogData
     */
    protected $logData;
    /**
     * @var json
     */
    protected $json;
    /**
     * @var StoreRepositoryInterface
     */
    private $storeRepository;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var CategoryFactory
     */
    private $categoryFactory;

    public function __construct(
        MailInterface                        $mail,
        DataObjectFactory $dataObjectFactory,
        Json                                 $json,
        ContactLog                           $logData,
        CategoryFactory                    $categoryFactory,
        StoreRepositoryInterface $storeRepository,
        StoreManagerInterface                $storeManager
    ) {
        $this->mail = $mail;
        $this->dataObjectFactory = $dataObjectFactory;
        $this->logData = $logData;
        $this->json = $json;
        $this->storeManager = $storeManager;
        $this->categoryFactory = $categoryFactory;
        $this->storeRepository = $storeRepository;
    }

    /**
     * @inheritDoc
     *
     */
    public function getCategories()
    {
        try{
            $stores = $this->getAllStoreList();
            $j=0;
                foreach ($stores as $store) {
                    $store_ids = $store->getStoreId();
                    if($store_ids ==0)
                        continue;
                    $collection = $this->categoryFactory->create()->getCollection();
                    $result =  $collection->addFieldToSelect('*')
                        ->addFieldToFilter(['store_id','store_id'],[['finset' => $store_ids],['finset' => 0]])
                        ->addFieldToFilter('status',1)
                        ->setOrder('sortorder','ASC');
                    $data[$j]['storeid'] = $store_ids;
                if($result->getSize() > 0){
                    $categories = $result->getData();
                    $i=0;
                    $catData=[];
                    foreach ($categories as $category){
                        $catData[$i][$store_ids]= $category['category'];
                        $i++;
                    }
                    $catArr = call_user_func_array('array_merge', $catData);
                    $response[] = ['store' => $store_ids,'categories' => $catArr];
                }
                else {
                    $response[] = ['store' => $store_ids,'message' => "No Category Information Found"];
                }
                $j++;
            }
        }
        catch (\Exception $e) {
            $response[] = ['message' => $e->getMessage()];
        }
        return $response;
    }

    /**
     * Get Store list
     *
     * @return StoreInterface[]
     */
    public function getAllStoreList(): array
    {
         return $this->storeRepository->getList();
    }
}
