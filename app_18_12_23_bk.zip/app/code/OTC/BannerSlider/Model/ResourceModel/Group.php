<?php

namespace OTC\BannerSlider\Model\ResourceModel;

use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Group
 */
class Group extends AbstractDb
{

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('otc_bannerslider_group', 'group_id');
    }

    /**
     * @param AbstractModel $object
     * @return Group
     */
    protected function _beforeSave(AbstractModel $object)
    {
        $storeId = $object->getStoreId();
        if (is_array($storeId)) {
            $object->setStoreId(implode(',', $storeId));
        }

        return parent::_beforeSave($object);
    }

    /**
     * @param AbstractModel $object
     * @return Group
     */
    protected function _afterLoad(AbstractModel $object)
    {
        $storeId = $object->getStoreId();
        if (!is_array($storeId)) {
            $storeId = explode(',', $storeId);
            $object->setStoreId($storeId);
        }

        return parent::_afterLoad($object);
    }

}
