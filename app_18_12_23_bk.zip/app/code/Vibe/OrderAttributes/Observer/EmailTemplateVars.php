<?php
namespace Vibe\OrderAttributes\Observer;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;

class EmailTemplateVars implements ObserverInterface
{
    protected $customerRepository;

    public function __construct(CustomerRepositoryInterface $customerRepository)
    {
        $this->customerRepository = $customerRepository;
    }

    public function execute(Observer $observer)
    {
        /** @var Action $controller */
        $transport = $observer->getEvent()->getTransport();

        if($transport->getOrder() != null)
        {
           if($transport->getOrder()->getOtcMarketingConsent())
               $transport['OtcMarketingConsent']   = 'Yes';
           else
               $transport['OtcMarketingConsent']   = 'No';
        }
    }
}
