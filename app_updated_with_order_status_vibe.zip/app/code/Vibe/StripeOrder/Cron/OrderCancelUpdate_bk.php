<?php

declare(strict_types=1);

namespace Vibe\StripeOrder\Cron;

use Magento\Framework\DB\Transaction;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Email\Sender\InvoiceSender;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Sales\Model\Service\InvoiceService;
use Vibe\CustomCheckoutUrl\Plugin\Helper;
use Vibe\StripeOrder\Helper\Data;
use Vibe\StripeOrder\Logger\Logger;
use Vibe\StripeOrder\Model\Api\PaymentInformation;

class OrderCancelUpdate_bk
{
    /**
     * @var Logger
     */
    protected $logger;
    /**
     * @var OrderRepository
     */
    protected $orderRepository;

    /**
     * @var  Data
     */
    protected $helper;

    /**
     * @var PaymentInformation
     */
    protected $paymentInformation;

    protected $order;

    protected $orderCollectionFactory;

    /**
     * @var \Magento\Sales\Model\Service\InvoiceService
     */
    protected InvoiceService $_invoiceService;

    /**
     * @var \Magento\Framework\DB\Transaction
     */
    protected Transaction $_transaction;
    protected InvoiceSender $invoiceSender;

    /**
     * @param Logger $logger
     * @param OrderRepositoryInterface $orderRepository
     * @param Helper $helper
     * @param PaymentInformation $paymentInformation
     * @param Order $order
     * @param CollectionFactory $orderCollectionFactory ;
     * @param InvoiceService $invoiceService
     * @param InvoiceSender $invoiceSender
     * @param Transaction $transaction
     */
    public function __construct(
        Logger $logger,
        OrderRepositoryInterface $orderRepository,
        Helper $helper,
        PaymentInformation $paymentInformation,
        Order $order,
        CollectionFactory $orderCollectionFactory,
        InvoiceService $invoiceService,
        InvoiceSender $invoiceSender,
        Transaction $transaction
    )
    {
        $this->logger = $logger;
        $this->orderRepository = $orderRepository;
        $this->helper = $helper;
        $this->paymentInformation = $paymentInformation;
        $this->order = $order;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->_invoiceService = $invoiceService;
        $this->invoiceSender = $invoiceSender;
        $this->_transaction = $transaction;
    }


    public function execute()
    {
        $orderCollection = $this->orderCollectionFactory->create()
            ->addAttributeToSelect('*')
            ->addFieldToFilter('status', 'pending')->setOrder('entity_id','DESC');
        //echo count($orderCollection);
        $i=0;
        foreach ($orderCollection as $order) {
            //if($i<=1) {
                //echo "<pre>";
                //var_dump($order->getData());
                $orderId = $order->getId();
                //$orderId = 1403;
                //die;
                $this->logger->info("OrderID " . $orderId);
                //if($orderId=="1409") {
                //echo "erer";
                //$this->logger->info("Same ID");
                $paymentInfo = $this->paymentInformation->getOrderItem($orderId);
//            if(!empty($paymentInfo)){
//                $this->logger->info("<pre>");
//                $this->logger->info(print_r($paymentInfo));
//            }die;
//            $this->logger->info("<pre>");
//            $this->logger->info(print_r($orderId));
//            $this->logger->info("Tsdsdss");
//            $this->logger->info($order->getData('entity_id'));
//            //echo $order->getData('entity_id')."<br>";
//            echo "";
//            echo $orderId = $order->getId()."<br>";

                $order = $this->orderRepository->get($orderId);
                //die;
                if (!empty($paymentInfo) && !empty($paymentInfo[0]['message'])) {
                    $this->logger->info("Payment Info");
                    if ($paymentInfo[0]['message'] != "" && array_key_exists("payment_status",$paymentInfo[0]['message']) && $paymentInfo[0]['message']['payment_status'] == "unpaid") {
                        $this->logger->info("U");
                        $this->logger->info(print_r($paymentInfo[0]['message']));
//                        echo "<pre>";
//                        print_r($paymentInfo[0]['message']);
//                        $this->logger->info("Cancel inititated");
                        if ($order->canCancel()) {
                            $this->logger->info("Cancel trigger");
                            $order->setStatus("canceled");
                            $order->save();
                            $this->logger->info("Cancel status updated for Order ID:".$orderId);
                        } else {
                            $this->logger->info("Cancel status not updated for Order ID:".$orderId);
                        }
                    }elseif($paymentInfo[0]['message'] != "" && array_key_exists("payment_status",$paymentInfo[0]['message']) && $paymentInfo[0]['message']['payment_status'] == "paid") {
                        if($order->canInvoice()) {
                            $this->logger->info("Invoice trigger");
                            $invoice = $this->_invoiceService->prepareInvoice($order);
                            $invoice->register();
                            $invoice->getOrder()->setIsInProcess(true);
                            $transactionSave = $this->_transaction->addObject($invoice)->addObject($invoice->getOrder());
                            $transactionSave->save();
                            $this->invoiceSender->send($invoice);
                            //send notification code
                            $order->addStatusHistoryComment(
                                __('Notified customer about invoice #%1.', $invoice->getId())
                            )
                                ->setIsCustomerNotified(true)
                                ->save();
                            $this->logger->info("Invoice created for Order ID:".$orderId);
                        }else{
                            $this->logger->info("No Invoice created for Order ID:".$orderId);
                        }
                    }else{
                        $this->logger->info("Cancel status not updated for Order ID:".$orderId);
                    }
                }
            //}
            //}
            $i++;
        }
        return $this;

    }
}
