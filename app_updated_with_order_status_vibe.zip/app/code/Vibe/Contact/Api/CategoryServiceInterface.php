<?php
namespace Vibe\Contact\Api;

use Vibe\Contact\Api\Data\CategoryInterface;
/**
 * Interface CategoryServiceInterface
 *
 * @package Vibe\Contact\Api
 */
interface CategoryServiceInterface
{

    /**
     * Contact us form.
     *
     * @return CategoryInterface
     */

    public function getCategories();

}
