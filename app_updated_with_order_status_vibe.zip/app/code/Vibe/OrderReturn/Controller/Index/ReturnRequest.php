<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Vibe\OrderReturn\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Sales\Model\OrderFactory;
use Vibe\OrderReturn\Helper\Data as ReturnHelper;

class ReturnRequest extends Action
{
    /**
     * @var \Magento\Framework\Data\Form\FormKey\Validator
     */
    protected $formKeyValidator;

    /**
     * @var OrderFactory
     */
    protected $orderFactory;

    /**
     * @var ReturnHelper
     */
    protected $returnHelper;

    /**
     * @param ReturnHelper $returnHelper
     * @param OrderFactory $orderFactory
     * @param Validator $formKeyValidator
     * @param Context $context
     */
    public function __construct(
        ReturnHelper $returnHelper,
        OrderFactory $orderFactory,
        Validator $formKeyValidator,
        Context $context
    ) {
        $this->returnHelper = $returnHelper;
        $this->orderFactory = $orderFactory;
        $this->formKeyValidator = $formKeyValidator;
        parent::__construct($context);
    }

    /**
     * Process address form save
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        if (!$this->formKeyValidator->validate($this->getRequest())) {
            return $this->resultRedirectFactory->create()->setPath('*/*/view');
        }

        if ($this->getRequest()->isPost()) {
            $orderId = $this->getRequest()->getPost('order_id');

            /** @var \Magento\Sales\Model\Order $orderFactory */
            $order = $this->orderFactory->create()->loadByIncrementId($orderId);

            if($order->getReturnStatus())
            {
                $this->messageManager->addErrorMessage(__('Return request already created.'));

            }else{
                $order->setState(ReturnHelper::STATUS_STATE)
                    ->setStatus(ReturnHelper::STATUS_CODE)
                    ->setReturnStatus(true)
                    ->save();

                $this->returnHelper->sendEmail($order);

                $this->messageManager->addSuccessMessage(__('You have requested for a return for this order.'));
                return $resultRedirect->setPath('*/*/view', ['order_id' => $orderId]);

            }
        }else{
            $this->messageManager->addErrorMessage(__('Order Id is required.'));
        }

        return $resultRedirect->setPath('*/*/view',['order_id' => $this->getRequest()->getPost('order_id')]);
    }
}
