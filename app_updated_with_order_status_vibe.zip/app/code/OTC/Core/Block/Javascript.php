<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace OTC\Core\Block;

/**
 * Class Form
 *
 * @api
 * @since 100.0.2
 */
class Javascript extends \Magento\Framework\View\Element\Template
{
    /**
     * Retrieve script options encoded to json
     *
     * @return string
     */
    public function getScriptOptions()
    {
        $params = [
            'url' => $this->getUrl(
                'page_cache/block/render/',
                [
                    '_current' => true,
                    '_secure' => $this->templateContext->getRequest()->isSecure()
                ]
            ),
            'handles' => $this->_layout->getUpdate()->getHandles(),
            'originalRequest' => [
                'route'      => $this->getRequest()->getRouteName(),
                'controller' => $this->getRequest()->getControllerName(),
                'action'     => $this->getRequest()->getActionName(),
                'uri'        => $this->specialCharacterUriCheck($this->getRequest()->getRequestUri()),
            ],
            'versionCookieName' => \Magento\Framework\App\PageCache\Version::COOKIE_NAME
        ];
        return json_encode($params);
    }

    /**
     * Check for special character in string
     *
     * @param string
     * @return string
     */
    public function specialCharacterUriCheck($uri)
    {
        $regex = preg_match('/[^A-Za-z0-9 \/&_?=]/', $uri);
        if($regex){
            $uri = substr($uri, 0, strpos($uri, "?"));
            return $uri;
        }
        return $uri;
    }
}
