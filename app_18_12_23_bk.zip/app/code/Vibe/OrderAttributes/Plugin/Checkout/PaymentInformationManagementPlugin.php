<?php

namespace Vibe\OrderAttributes\Plugin\Checkout;

use Magento\Framework\Exception\LocalizedException;
use Magento\Checkout\Api\GuestPaymentInformationManagementInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Api\Data\AddressInterface;
use Magento\Quote\Api\Data\PaymentInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\QuoteIdMaskFactory;

/**
 * Class PaymentInformationManagementPlugin
 */
class PaymentInformationManagementPlugin
{
    /**
     * @var CartRepositoryInterface
     */
    protected $quoteRepository;

    /**
     * @var TimezoneInterface
     */
    protected $localeDate;

    /**
     * @var QuoteIdMaskFactory
     */
    protected $quoteIdMaskFactory;

    /**
     * PaymentInformationManagementPlugin constructor.
     * @param CartRepositoryInterface $quoteRepository
     * @param TimezoneInterface $localeDate
     * @param QuoteIdMaskFactory $quoteIdMaskFactory
     */
    public function __construct(
        CartRepositoryInterface $quoteRepository,
        TimezoneInterface $localeDate,
        QuoteIdMaskFactory $quoteIdMaskFactory

    ) {
        $this->quoteRepository = $quoteRepository;
        $this->localeDate = $localeDate;
        $this->quoteIdMaskFactory = $quoteIdMaskFactory;
    }

    /**
     * @param GuestPaymentInformationManagementInterface $subject
     * @param string $cartId
     * @param string $email
     * @param PaymentInterface $paymentMethod
     * @param AddressInterface|null $billingAddress
     * @return array
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function beforeSavePaymentInformation(
        GuestPaymentInformationManagementInterface $subject,
        string                                     $cartId,
        string                                     $email,
        PaymentInterface                           $paymentMethod,
        AddressInterface                           $billingAddress = null
    ): array
    {
        $quoteIdMask = $this->quoteIdMaskFactory->create()->load($cartId, 'masked_id');
            /** @var Quote $quote */
        $quote = $this->quoteRepository->getActive($quoteIdMask->getQuoteId());
        if($paymentMethod->getExtensionAttributes()->getOtcMarketingConsent()){
            $orderAttributes = $paymentMethod->getExtensionAttributes() === null
        || $paymentMethod->getExtensionAttributes()->getOtcMarketingConsent() === null
            ? []
            : $paymentMethod->getExtensionAttributes()->getOtcMarketingConsent();
        }else{
            $orderAttributes=$quote->getOtcMarketingConsent();
        }
        try {
            $quote->setOtcMarketingConsent($orderAttributes);
            $this->quoteRepository->save($quote);
        } catch (LocalizedException $e) {
      }

        return [
            $cartId,
            $email,
            $paymentMethod,
            $billingAddress
        ];

    }
}
