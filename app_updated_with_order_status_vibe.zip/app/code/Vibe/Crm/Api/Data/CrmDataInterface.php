<?php

namespace Vibe\Crm\Api\Data;

/**
 * Crm Interface
 */
interface CrmDataInterface
{

    /**
     * Set OrderIds.
     * @param mixed $order_ids
     * @return  $this
     */
    public function postOrderItems($order_ids);


}
