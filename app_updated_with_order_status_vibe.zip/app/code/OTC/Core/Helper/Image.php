<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace OTC\Core\Helper;

use Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\Directory\WriteInterface;
use Magento\Framework\Filesystem\Glob;
use Magento\Framework\Filesystem\Io\File;
use Magento\Framework\Image\Factory;
use Magento\Framework\UrlInterface;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Description of Image
 *
 * @author Master
 */
class Image extends AbstractHelper  //NOSONAR
{

    const BASE_TEMPLATE_FILE_NAME = '{dirname}/{destinationSubdir}/{filename}_{width}_{height}.{extension}';

    /**
     * @var
     */
    protected $baseFile;
    /**
     * @var int
     */
    protected $width;
    /**
     * @var int
     */
    protected $height;
    /**
     * Default quality value (for JPEG images only).
     *
     * @var int
     */
    protected $quality = 90;
    /**
     * @var bool
     */
    protected $keepAspectRatio = true;
    /**
     * @var bool
     */
    protected $keepFrame = true;
    /**
     * @var bool
     */
    protected $keepTransparency = true;
    /**
     * @var bool
     */
    protected $constrainOnly = true;
    /**
     * @var bool
     */
    protected $cropOnly = false;

    protected $resizeTemplate = '';
    /**
     * @var int[]
     */
    protected $backgroundColor = [255, 255, 255];
    /**
     * @var \Magento\Framework\Image
     */
    protected $processor;
    /**
     * @var string
     */
    protected $destinationSubdir;
    /**
     * @var WriteInterface
     */
    protected $mediaDirectory;

    /**
     * Store Manager
     *
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var Factory
     */
    protected $imageFactory;
    /**
     * @var array
     */
    protected $attributes;
    /**
     * @var File
     */
    protected $file;
    /**
     * @var string
     */
    private $newFile;

    /**
     * @param Context $context
     * @param Filesystem $filesystem
     * @param Factory $imageFactory
     * @param File $file
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        Filesystem $filesystem,
        Factory $imageFactory,
        File $file,
        StoreManagerInterface $storeManager
    ) {
        $this->_mediaDirectory = $filesystem->getDirectoryRead(DirectoryList::MEDIA);
        $this->_imageFactory = $imageFactory;
        $this->newFile = $file;
        $this->_storeManager = $storeManager;

        parent::__construct($context);
    }

    /**
     * @param $size
     * @param $fileTemplate
     * @return $this
     */
    public function adaptiveResize($size, $fileTemplate = null)
    {
        if (!empty($fileTemplate)) {
            $this->setFileTemplate($fileTemplate);
        }
        try {
            [$width, $height] = $this->prepareSize($size);
            $this->setWidth($width);
            $this->setHeight($height);
            if ($this->_keepAspectRatio && $this->_cropOnly) {
                $this->crop();
            }
            $this->resize();
        } catch (Exception $e) {
            $this->_logger->error("Image Resize: " . $e, [$this->_baseFile]);
        }

        return $this;
    }

    /**
     * @param $fileTemplate
     * @return $this
     */
    public function setFileTemplate($fileTemplate)
    {
        $this->_resizeTemplate = $fileTemplate;
        return $this;
    }

    /**
     * @param $size
     * @return array
     */
    private function prepareSize($size)
    {
        if (is_array($size) && 1 >= count($size)) {
            $size = array_shift($size);
        }
        if (!is_array($size)) {
            $size = [$size, $size];
        }
        $size = array_map('intval', $size);
        $size = array_map('abs', $size);
        return $size;
    }

    /**
     * @return $this
     */
    public function crop()
    {
        if ($this->_width == 0 && $this->_height == 0 && !$this->getBaseFile()) {
            return $this;
        }
        if ($this->newFileExists($this->getResizedFile())) {
            return $this;
        }

        $imageSrcWidth = $this->getImageProcessor()->getOriginalWidth();
        $imageSrcHeight = $this->getImageProcessor()->getOriginalHeight();
        $imageSrcRatio = $imageSrcWidth / $imageSrcHeight;
        $ratio = $this->_width / $this->_height;

        if ($imageSrcRatio != $ratio) {
            if (1 > $imageSrcRatio) {
                $newHeight = round($imageSrcWidth / $ratio);
                $deltHeight = $imageSrcHeight - $newHeight;

                $deltHeight = floor($deltHeight / 2);
                $newdeltHeight = $deltHeight % 2;

                $this->getImageProcessor()->crop($deltHeight + $newdeltHeight, 0, 0, $deltHeight);
            } elseif (1 < $imageSrcRatio) {
                $newWidth = round($imageSrcHeight * $ratio);
                $deltWidth = $imageSrcWidth - $newWidth;

                $deltWidth = floor($deltWidth / 2);
                $newdeltWidth = $deltWidth % 2;

                $this->getImageProcessor()->crop(0, $deltWidth + $newdeltWidth, $deltWidth, 0);
            }
        }

        return $this;
    }

    /**
     * @return string
     */
    public function getBaseFile()
    {
        return $this->_baseFile;
    }

    /**
     * Set filenames for base file and new file
     *
     * @param string $file
     * @return Image
     */
    public function setBaseFile($file)
    {
        if ($this->newFileExists($file)) {
            $this->_baseFile = $file;
        } else {
            $this->_logger->error(__('The file does not exist: ') . $file);
        }

        return $this;
    }

    /**
     * First check this file on FS
     * If it doesn't exist - try to download it from DB
     *
     * @param string $filename
     * @return bool
     */
    protected function newFileExists($filename)
    {
        return $this->newFile->fileExists($this->_mediaDirectory->getAbsolutePath($filename));
    }

    /**
     * @return string
     */
    private function getResizedFile()
    {
        $pathData = pathinfo($this->getBaseFile());

        if (is_array($pathData) && !empty($pathData)) {
            $filename = str_replace( //NOSONAR
                [
                    '{dirname}',
                    '{basename}',
                    '{extension}',
                    '{filename}',
                    '{width}',
                    '{height}',
                    '{originalWidth}',
                    '{originalHeight}',
                    '{destinationSubdir}',
                    '{keepFrame}',
                    '{constrainOnly}',
                    '{keepAspectRatio}',
                    '{crop}',
                    '{keepTransparency}',
                    '{quality}',
                ],
                [
                    $pathData['dirname'],
                    $pathData['basename'],
                    $pathData['extension'],
                    $pathData['filename'],
                    $this->getWidth(),
                    $this->getHeight(),
                    $this->getOriginalWidth(),
                    $this->getOriginalHeight(),
                    $this->getDestinationSubdir(),
                    $this->getQuality(),
                    $this->_keepFrame,
                    $this->_constrainOnly,
                    $this->_keepAspectRatio,
                    $this->_cropOnly,
                    $this->_keepTransparency,
                ],
                $this->_resizeTemplate
            );

            return $filename;
        }
        return '';
    }

    /**
     * @return int
     */
    public function getWidth()
    {
        return $this->_width ?: $this->getOriginalWidth();
    }

    /**
     * @param int $width
     * @return Image
     */
    public function setWidth($width)
    {
        $this->_width = abs((int)$width);
        return $this;
    }

    /**
     * @return int|null
     */
    public function getOriginalWidth()
    {
        return $this->getImageProcessor()->getOriginalWidth();
    }

    /**
     * @return \Magento\Framework\Image
     */
    public function getImageProcessor()
    {
        if (!$this->_processor) {
            $filename = $this->getBaseFile() ? $this->_mediaDirectory->getAbsolutePath($this->getBaseFile()) : null;
            $this->_processor = $this->_imageFactory->create($filename);
        }
        $this->_processor->keepAspectRatio($this->_keepAspectRatio);
        $this->_processor->keepFrame($this->_keepFrame);
        $this->_processor->keepTransparency($this->_keepTransparency);
        $this->_processor->constrainOnly($this->_constrainOnly);
        $this->_processor->backgroundColor($this->_backgroundColor);
        $this->_processor->quality($this->_quality);
        return $this->_processor;
    }

    /**
     * @return int
     */
    public function getHeight()
    {
        return $this->_height ?: $this->getOriginalHeight();
    }

    /**
     * @param int $height
     * @return $this
     */
    public function setHeight($height)
    {
        $this->_height = abs((int)$height);
        return $this;
    }

    /**
     * @return int|null
     */
    public function getOriginalHeight()
    {
        return $this->getImageProcessor()->getOriginalHeight();
    }

    /**
     * @return string
     */
    public function getDestinationSubdir()
    {
        return $this->_destinationSubdir;
    }

    /**
     * @param string $dir
     * @return $this
     */
    public function setDestinationSubdir($dir)
    {
        $this->_destinationSubdir = $dir;
        return $this;
    }

    /**
     * Get image quality
     *
     * @return int
     */
    public function getQuality()
    {
        return $this->_quality;
    }

    /**
     * Set image quality, values in percentage from 0 to 100
     *
     * @param int $quality
     * @return $this
     */
    public function setQuality($quality)
    {
        $quality = abs((int)$quality);
        if (0 < $quality) {
            $this->_quality = $quality;
        }
        return $this;
    }

    /**
     * @return $this
     * @see \Magento\Framework\Image\Adapter\AbstractAdapter
     */
    public function resize()
    {
        if ($this->_width == 0
            && $this->_height == 0
            || !$this->getBaseFile()
            || !$this->newFileExists($this->getBaseFile())
        ) {
            return $this;
        }

        $resizedFile = $this->getResizedFile();
        if ($resizedFile && $this->newFileExists($resizedFile)) {
            return $this;
        }

        $newnewFilename = $this->_mediaDirectory->getAbsolutePath($resizedFile);

        $this->getImageProcessor()->resize($this->_width, $this->_height);

        $this->getImageProcessor()->save($newnewFilename);

        return $this;
    }

    /**
     * @param \Magento\Framework\Image $processor
     * @return $this
     */
    public function setImageProcessor($processor)
    {
        $this->_processor = $processor;
        return $this;
    }

    /**
     * @return string
     * @throws NoSuchEntityException
     */
    public function getUrl()
    {
        $mediaUrl = $this->_storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);
        if ($this->getBaseFile()) {
            $resizedFile = $this->getResizedFile();
            if ($resizedFile && $this->newFileExists($resizedFile)) {
                return $mediaUrl . $this->getResizedFile();
            }
        }

        return $mediaUrl . $this->newFile;
    }

    /**
     * @param string $size
     * @return $this
     */
    public function setSize($size)
    {
        // determine width and height from string
        $width = $height = 0;

        if (is_numeric($size)) {
            $width = $height = $size;
        } elseif (is_array($size)) {
            if (1 >= count($size)) {
                [$width, $height] = $size;
            } else {
                $width = $height = array_shift($size);
            }
        } elseif (is_string($size)) {
            [$width, $height] = explode('x', strtolower($size), 2);
        }

        foreach (['width', 'height'] as $wh) {
            ${$wh} = (int)${$wh};
            if (empty(${$wh})) {
                ${$wh} = null;
            }
        }

        // set sizes
        $this->setWidth($width)->setHeight($height);

        return $this;
    }

    /**
     * @param $file
     * @throws Exception
     */
    public function removeResized($file)
    {
        if (!empty($file)) {
            $this->init($file);
        }
        $file = $this->getBaseFile();

        if (!empty($file)) {
            $newnewFilename = pathinfo($file);
            $filename = implode(
                '_',
                [
                    $newnewFilename['filename'],
                    '*',
                ]
            );
            $newnewFilename['filename'] = $filename . '.' . $newnewFilename['extension'];
            $pattern = implode(
                '/',
                [
                    $this->getDestinationSubdir(),
                    $newnewFilename['dirname'],
                    $newnewFilename['filename'],
                ]
            );
            $pattern = $this->_mediaDirectory->getAbsolutePath($pattern);
            $files = Glob::glob($pattern);
            if (!empty($files)) {
                foreach ($files as $file) {
                    if ($this->newFileExists($file)) {
                        $this->newFile->rm($file);
                    }
                }
            }
        }
    }

    /**
     * @param $file
     * @param array $attributes
     * @return $this
     * @throws Exception
     */
    public function init($file, $attributes = [])
    {
        $this->_reset();
        $this->newFile = $file;
        $this->setBaseFile($file);
        $this->attributes = $attributes;
        $this->setImageProperties();

        return $this;
    }

    /**
     * Resset all attributes
     */
    protected function _reset()
    {
        $this->_processor = null;
        $this->_baseFile = null;
        $this->setQuality(90);
        $this->setFileTemplate(static::BASE_TEMPLATE_FILE_NAME);
        $this->setBackgroundColor([255, 255, 255]);
        $this->setConstrainOnly(true);
        $this->setDestinationSubdir('resized');
        $this->setKeepAspectRatio(true);
        $this->setKeepFrame(true);
        $this->setKeepTransparency(true);
        $this->setWidth(null);
        $this->setHeight(null);
    }

    /**
     * @param int[] $rgbArray
     * @return $this
     */
    public function setBackgroundColor(array $rgbArray)
    {
        $this->_backgroundColor = $rgbArray;
        return $this;
    }

    /**
     * @param bool $flag
     * @return $this
     */
    public function setConstrainOnly($flag)
    {
        $this->_constrainOnly = $flag && $flag !== 'false';
        return $this;
    }

    /**
     * @param bool $keep
     * @return $this
     */
    public function setKeepAspectRatio($keep)
    {
        $this->_keepAspectRatio = $keep && $keep !== 'false';
        return $this;
    }

    /**
     * @param bool $keep
     * @return $this
     */
    public function setKeepFrame($keep)
    {
        $this->_keepFrame = $keep && $keep !== 'false';
        return $this;
    }

    /**
     * @param bool $keep
     * @return $this
     */
    public function setKeepTransparency($keep)
    {
        $this->_keepTransparency = $keep && $keep !== 'false';
        return $this;
    }

    /**
     * Set image properties
     *
     * @return $this
     */
    protected function setImageProperties()
    {
        // Set 'keep frame' flag
        $frame = $this->getAttribute('frame');
        if (!empty($frame)) {
            $this->setKeepFrame($frame);
        }
        // Set 'quality'
        $quality = $this->getAttribute('quality');
        if (!empty($quality)) {
            $this->setQuality($quality);
        }

        // Set 'constrain only' flag
        $constrain = $this->getAttribute('constrain');
        if (!empty($constrain)) {
            $this->setConstrainOnly($constrain);
        }

        // Set 'keep aspect ratio' flag
        $aspectRatio = $this->getAttribute('aspect_ratio');
        if (!empty($aspectRatio)) {
            $this->setKeepAspectRatio($aspectRatio);
        }

        // Set 'keep $crop' flag
        $crop = $this->getAttribute('crop');
        if (!empty($crop)) {
            $this->seCropOnly($crop);
        }

        // Set 'transparency' flag
        $transparency = $this->getAttribute('transparency');
        if (!empty($transparency)) {
            $this->setKeepTransparency($transparency);
        }

        // Set background color
        $background = (array)$this->getAttribute('background');
        if (!empty($background)) {
            $this->setBackgroundColor($background);
        }

        $fileTemplate = $this->getAttribute('fileTemplate');
        $this->setFileTemplate(!empty($fileTemplate) ? $fileTemplate : static::BASE_TEMPLATE_FILE_NAME);

        return $this;
    }

    /**
     * Retrieve image attribute
     *
     * @param string $name
     * @return string
     */
    protected function getAttribute($name)
    {
        return $this->attributes[$name] ?? null;
    }

    /**
     * @param bool $flag
     * @return $this
     */
    public function seCropOnly($flag)
    {
        $this->_cropOnly = $flag && $flag !== 'false';
        return $this;
    }

}
