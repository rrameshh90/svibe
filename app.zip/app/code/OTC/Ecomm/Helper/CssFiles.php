<?php

namespace OTC\Ecomm\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\UrlInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;

/**
 * CssFiles
 */
class CssFiles extends AbstractHelper
{

    /**
     * @var
     */
    protected $storeCode;

    /**
     * @var string
     */
    protected $webFolder;

    /**
     * @var string
     */
    protected $dymanicFolder;

    /**
     * @var string
     */
    protected $generatedCssDir;

    /**
     * Store Manager
     *
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var
     */
    private $googleFontEnable;

    /**
     * @param Context $context
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager
    ) {

        $this->storeManager = $storeManager;

        $base = BP;

        $this->webFolder = 'ecomm/web/';
        $this->dymanicFolder = 'ecomm/dymanic';
        $this->generatedCssDir = sprintf('%s/pub/media/%s', $base, $this->dymanicFolder);
        parent::__construct($context);
    }

    /**
     * @return string
     */
    public function getDymanicDir()
    {
        return $this->generatedCssDir;
    }

    /**
     * @param $name
     * @param null $code
     * @return string
     * @throws NoSuchEntityException
     */
    public function getDynamicCss($name, $code = null)
    {
        return $this->getDynamicFile($name, $code);
    }

    /**
     * @param $name
     * @param $code
     * @param $format
     * @return string
     * @throws NoSuchEntityException
     */
    public function getDynamicFile($name, $code = null, $format = 'css')
    {
        if (empty($code)) {
            $code = $this->storeManager->getStore()->getCode();
        }
        return sprintf('%s/%s_%s.%s', $this->getModuleMediaUrl(), $name, $code, $format);
    }

    /**
     * @param $path
     * @return string
     * @throws NoSuchEntityException
     */
    public function getModuleMediaUrl($path = '')
    {
        return $this->getBaseMediaUrl($this->dymanicFolder) . $path;
    }

    /**
     * @param $path
     * @return string
     * @throws NoSuchEntityException
     */
    public function getBaseMediaUrl($path = '')
    {
        return $this->storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_MEDIA) . $path;
    }

    /**
     * @param $fontNameGoogle
     * @param $fontNameCustom
     * @return string
     */
    public function fontOutput($fontNameGoogle, $fontNameCustom)
    {
        $fontName = 'Open Sans';
        if ('' != $fontNameCustom) {
            $fontName = preg_replace("/[^a-zA-Z0-9-_\s]/", "", $fontNameCustom);
        } elseif ($fontNameGoogle) {
            $fontName = $fontNameGoogle;
        }
        return '\'' . $fontName . '\', Helvetica, Arial, sans-serif';
    }

    /**
     * @return string
     */
    public function getGoogleFontUrl()
    {
        if (!$this->isGoogleFontEnable()) {
            return '';
        }

        $default = array_keys($this->defaultFont());
        $fonts = [];
        foreach ($default as $fontName) {
            $font = $this->getFont($fontName);
            if (!empty($font)) {
                $gfw = explode(',', $this->getFontWeight($fontName));
                $ar = array_key_exists($font, $fonts) ? $fonts[$font] : [];
                $fonts[$font] = array_merge($ar, $gfw);
            }
        }
        $fonts = array_map('array_unique', $fonts);
        $fonts = array_map('array_filter', $fonts);
        $fonts = array_filter($fonts);
        foreach ($fonts as $font => $weight) {
            $fonts[$font] = sprintf('%s:%s', $font, implode(',', $weight));
        }
        $fonts = implode('|', $fonts);
        $fonts = urlencode($fonts);

        return '//fonts.googleapis.com/css?family=' . $fonts . '&display='
            . ($this->getConfigFont('fonts_display_mode') ?: 'fallback');
    }

    /**
     * @return mixed|string
     */
    protected function isGoogleFontEnable()
    {
        if (is_null($this->googleFontEnable)) {
            $this->googleFontEnable = $this->getConfig('ecomm_design/appearance_general/googleFontEnable',
                $this->getStoreCode());
        }
        return $this->googleFontEnable;
    }

    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    public function getConfig($path, $storeCode = null)
    {
        $value = $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeCode);
        if (is_null($value)) {
            $value = '';
        }
        return $value;
    }

    /**
     * @return mixed
     */
    public function getStoreCode()
    {
        return $this->storeCode;
    }

    /**
     * @param $storeCode
     * @return void
     */
    public function setStoreCode($storeCode = null)
    {
        $this->storeCode = $storeCode;
    }

    /**
     * @return string[]
     */
    protected function defaultFont()
    {
        return [
            'body_font' => 'Open Sans',
            'menu_font' => 'Open Sans',
            'general_font' => 'Open Sans',
            'button_font' => 'Open Sans',
            'title_font' => 'Poppins',
            'title_font_fancy' => 'Open Sans',
            'title_font_medium' => 'Poppins',
            'footer_content_font' => 'Open Sans',
            'copyright_content_font' => 'Open Sans',
            'sidebar_title_font' => 'Open Sans',
        ];
    }

    /**
     * @param $fontName
     * @return mixed|string
     */
    public function getFont($fontName)
    {
        $font = $this->getConfigFont($fontName);

        if (empty($font)) {
            $default = $this->defaultFont();
            if (array_key_exists($fontName, $default)) {
                $font = $default[$fontName];
            }
        }

        return $font;
    }

    /**
     * @param $fontName
     * @return mixed|string
     */
    protected function getConfigFont($fontName)
    {
        $storeCode = $this->getStoreCode();
        $appearanceGeneral = $this->getConfig('ecomm_design/appearance_general', $storeCode);

        if (
            is_array($appearanceGeneral)
            && isset($appearanceGeneral[$fontName])
            && !empty($appearanceGeneral[$fontName])
        ) {
            return $appearanceGeneral[$fontName];
        }

        return '';
    }

    /**
     * @param $fontName
     * @return mixed|string
     */
    public function getFontWeight($fontName)
    {
        $fontName = $fontName . '_weight';
        $fontWeight = $this->getConfigFont($fontName);

        if (empty($fontWeight)) {
            // fallback. use default font weight option if there are no specific weight option for selected font
            $fontWeight = $this->getConfigFont('general_font_weight');
        }
        return $fontWeight;
    }

}
