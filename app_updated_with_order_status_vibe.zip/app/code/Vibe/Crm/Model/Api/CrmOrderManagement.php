<?php

declare(strict_types=1);

namespace Vibe\Crm\Model\Api;

use Magento\Framework\Serialize\Serializer\Json;
use Magento\Sales\Api\OrderRepositoryInterface;
use Vibe\Crm\Api\CrmOrderManagementInterface;
use Vibe\Crm\Logger\Logger;
use Magento\Framework\Encryption\EncryptorInterface;

/**
 * POST for CrmOrder api
 * @package Vibe\Crm\Model\Api
 *
 */
class CrmOrderManagement implements CrmOrderManagementInterface
{
     /**
     * @var Logger
     */
    protected $logger;
    /**
     * @var OrderRepository
     */
    protected $orderRepository;

    /**
     * @var ConfigData
     */
    protected $configData;
    /**
     * @var json
     */
    protected $json;

    /**
     * @param Logger $logger
     * @param OrderRepositoryInterface $orderRepository
     * @param EncryptorInterface $encryptor
     * @param Json $json
     */

    public function __construct(
 	    Logger         $logger,
        OrderRepositoryInterface $orderRepository,
        EncryptorInterface       $encryptor,
        Json $json

    )
    {
        $this->logger = $logger;
        $this->orderRepository = $orderRepository;
	    $this->encryptor = $encryptor;
        $this->json = $json;
    }

    /**
     * {@inheritdoc}
     */
    public function postOrderItems($order_ids)
    {
        $this->logger->info("CRM Status Update Order Id List : ". \GuzzleHttp\json_encode($order_ids));
        if (count($order_ids) > 0) {
            foreach ($order_ids as $orderId) {
                $order = $this->orderRepository->get($orderId);
                $order->setCrmStatus('success');
                $this->logger->info(" Success Order ID : ". \GuzzleHttp\json_encode($orderId));
                try {
                    $this->orderRepository->save($order);
                } catch (\Exception $e) {
                    $this->logger->info("Failed Order ID : ". \GuzzleHttp\json_encode($orderId));
                    return $e->getMessage();
                }
            }
            return 1;
        }
        else{
            return "No Orders To Update.";
        }
    }
}

