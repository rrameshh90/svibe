<?php

namespace Vibe\StripeOrder\Helper\Rewrite;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\LocalizedException;
use StripeIntegration\Payments\Helper\Compare;
use StripeIntegration\Payments\Helper\Generic;
use StripeIntegration\Payments\Helper\Locale;
use StripeIntegration\Payments\Helper\Subscriptions;
use StripeIntegration\Payments\Model\CheckoutSessionFactory;
use StripeIntegration\Payments\Model\Config;
use StripeIntegration\Payments\Model\PaymentIntent;
use Vibe\StripeOrder\Helper\Data;


/**
 * Rewrite Stripe Checkout Session Helper Function
 */
class CheckoutSession extends \StripeIntegration\Payments\Helper\CheckoutSession
{


    /**
     * @param Config $config
     * @param PaymentIntent $paymentIntent
     * @param CheckoutSessionFactory $checkoutSessionFactory
     * @param Generic $paymentsHelper
     * @param Locale $localeHelper
     * @param Subscriptions $subscriptions
     * @param Compare $compare
     * @param ScopeConfigInterface $scopeConfig
     * @param Data $configData
     */

    public function __construct(
        Config $config,
        PaymentIntent $paymentIntent,
        CheckoutSessionFactory $checkoutSessionFactory,
        Generic $paymentsHelper,
        Locale $localeHelper,
        Subscriptions $subscriptions,
        Compare $compare,
        ScopeConfigInterface $scopeConfig,
        Data  $configData
    )
    {

        $this->configData = $configData;
        parent::__construct($config,$paymentIntent,$checkoutSessionFactory,$paymentsHelper,
            $localeHelper,$subscriptions,$compare,$scopeConfig);
    }


    protected function getSessionParamsFrom($lineItems, $subscriptions, $quote, $order = null)
    {
        if ($order) {
            $storeId = $order->getStoreId();
         }
         else if ($quote) {
             $storeId = $quote->getStoreId();
         }

        $params = [
            'expires_at' => $this->getExpirationTime(),
            'cancel_url' => $this->configData->getCancelUrl($storeId),
            'success_url' => $this->configData->getSuccessUrl($storeId),
            'locale' => $this->localeHelper->getStripeCheckoutLocale(),
            'line_items' => $lineItems
        ];

        if (!empty($subscriptions))
        {
            $params["mode"] = "subscription";
            $params["subscription_data"] = [
                "metadata" => $this->subscriptions->collectMetadataForSubscriptions($quote, $subscriptions, $order)
            ];

            foreach ($subscriptions as $subscription)
            {
                $profile = $subscription['profile'];

                if ($profile['trial_days'] > 0)
                    $params["subscription_data"]['trial_period_days'] = $profile['trial_days'];
            }
        }
        else
        {
            $params["mode"] = "payment";
            $params["payment_intent_data"] = $this->convertToPaymentIntentData($this->paymentIntent->getParamsFrom($quote, $order));
            $params["submit_type"] = "pay";
        }

        $params["payment_method_options"] = [
            "acss_debit" => [
                "mandate_options" => [
                    "payment_schedule" => "sporadic",
                    "transaction_type" => "personal"
                ]
            ],
            // "bacs_debit" => [
            //     "setup_future_usage" => "off_session"
            // ]
        ];

        if ($this->config->alwaysSaveCards())
        {
            try
            {
                $this->customer->createStripeCustomerIfNotExists(false, $order);
                $this->stripeCustomer = $this->customer->retrieveByStripeID();
                if (!empty($this->stripeCustomer->id))
                    $params['customer'] = $this->stripeCustomer->id;
            }
            catch (\Stripe\Exception\CardException $e)
            {
                throw new LocalizedException(__($e->getMessage()));
            }
            catch (\Exception $e)
            {
                $this->paymentsHelper->dieWithError(__('An error has occurred. Please contact us to complete your order.'), $e);
            }
        }
        else
        {
            if ($this->paymentsHelper->isCustomerLoggedIn())
                $this->customer->createStripeCustomerIfNotExists(false, $order);

            $this->stripeCustomer = $this->customer->retrieveByStripeID();
            if (!empty($this->stripeCustomer->id))
                $params['customer'] = $this->stripeCustomer->id;
            else if ($order)
                $params['customer_email'] = $order->getCustomerEmail();
            else if ($quote->getCustomerEmail())
                $params['customer_email'] = $quote->getCustomerEmail();

        }

        return $params;
    }
}
