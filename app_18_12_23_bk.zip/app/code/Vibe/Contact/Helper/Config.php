<?php
/**
 * @author    OTC Group
 *
 */

namespace Vibe\Contact\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\ScopeInterface;

/**
 * Config Helper
 */
class Config extends \Magento\Framework\App\Helper\AbstractHelper
{

    /**
     * Contact debug mode config
     */
    const DEBUG_MODE_PATH = "contact/backend/debug_mode";



    /**
     * Config constructor.
     * @param Context $context
     */
    public function __construct(Context $context)
    {
        parent::__construct($context);


    }


    /**
     * @return bool
     */
    public function getDebugMode(): bool
    {
        return true;
    }
}
