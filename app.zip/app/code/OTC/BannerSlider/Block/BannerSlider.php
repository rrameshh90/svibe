<?php

namespace OTC\BannerSlider\Block;

use Magento\Customer\Model\Context;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\View\Element\Template;
use Magento\Store\Model\ScopeInterface;
use Magento\Widget\Block\BlockInterface;
use OTC\BannerSlider\Model\ResourceModel\Group\CollectionFactory;
use OTC\BannerSlider\Model\ResourceModel\Slides\Collection;

/**
 * BannerSlider
 */
class BannerSlider extends Template implements BlockInterface
{

    protected $slidesCollection;
    protected $groupCollection;

    /**
     * @var \Magento\Framework\App\Http\Context
     */
    protected $httpContext;

    /**
     * Json Serializer Instance
     *
     * @var Json
     */
    private $json;

    /**
     * @param Template\Context $context
     * @param \OTC\BannerSlider\Model\ResourceModel\Slides\CollectionFactory $slidesCollectionFactory
     * @param CollectionFactory $groupCollectionFactory
     * @param \Magento\Framework\App\Http\Context $httpContext
     * @param array $data
     * @param Json|null $json
     */
    public function __construct(
        Template\Context $context,
        \OTC\BannerSlider\Model\ResourceModel\Slides\CollectionFactory $slidesCollectionFactory,
        CollectionFactory $groupCollectionFactory,
        \Magento\Framework\App\Http\Context $httpContext,
        array $data = [],
        Json $json = null
    ) {
        $this->slidesCollection = $slidesCollectionFactory->create();
        $this->groupCollection = $groupCollectionFactory->create();

        $this->httpContext = $httpContext;
        $this->json = $json;
        parent::__construct($context, $data);
    }

    /**
     * @param $newval
     * @return array
     * @throws NoSuchEntityException
     */
    public function getCacheKeyInfo($newval = [])
    {
        return array_merge([
            'SHOPXP_BANNERSLIDER_WIDGET',
            $this->_storeManager->getStore()->getId(),
            $this->_design->getDesignTheme()->getId(),
            $this->httpContext->getValue(Context::CONTEXT_GROUP),
            $this->json->serialize($this->getRequest()->getParams()),
            $this->json->serialize($this->getData()),
        ], parent::getCacheKeyInfo(), $newval);
    }

    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    public function getConfig($path, $storeCode = null)
    {
        $value = $this->_scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeCode);
        if (is_null($value)) {
            $value = '';
        }
        return $value;
    }

    /**
     * @return array|Collection
     * @throws NoSuchEntityException
     */
    public function getSlides()
    {
        $group = $this->getGroup();
        if (!empty($group)) {
            return $this->slidesCollection
                ->addFieldToSelect('*')
                ->addStoreFilter($this->_storeManager->getStore())
                ->addFieldToFilter('slide_group', $group['group_id'])
                ->addFieldToFilter('status', 1)
                ->setOrder('sort_order', 'asc');
        }

        return [];
    }

    /**
     * @return array|mixed|null
     */
    public function getGroup()
    {
        $group = $this->getData('current_group');
        if (empty($group)) {
            $groups = $this->groupCollection
                ->addFieldToSelect('*')
                ->addFieldToFilter('identifier', $this->getSlideGroup());
            if ($groups->getSize()) {
                foreach ($groups as $group) {
                    $this->setData('current_group', $group);
                    break;
                }
            }
        }

        return $group;
    }

    /**
     * @return string
     */
    public function getSliderId()
    {
        return 'sp_' . $this->getNameInLayout() . substr(md5(microtime()), -5);
    }

    /**
     * @param array $style
     * @param string $separatorValue
     * @param string $separatorAttribute
     * @return string
     */
    public function prepareStyle(array $style, string $separatorValue = ': ', string $separatorAttribute = ';')
    {
        $style = array_filter($style);
        if (empty($style)) {
            return '';
        }
        foreach ($style as $key => &$value) {
            $value = $key . $separatorValue . $value;
        }
        $style = implode($separatorAttribute, $style);

        return $style;
    }

    /**
     * @param $toString
     * @return false|int[][]|string
     */
    public function getResponsive($toString = true)
    {
        $width = $this->getGroup()->getSlideWidth();
        $responsive = [
            0 => [
                'items' => 1,
            ],
        ];
        $j = 1;
        for ($i = $width + 1; $i < 3000; $i += $width) {
            $j++;
            $responsive[$i] = [
                'items' => $j,
            ];
        }

        if ($toString) {
            return json_encode($responsive);
        }

        return $responsive;
    }

    /**
     * @return array|int|mixed|null
     */
    public function getAutoScroll()
    {
        $autoScroll = $this->getData('auto_scroll');
        if (empty($autoScroll)) {
            $autoScroll = 0;
        }

        return $autoScroll;
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        $this->addData([
            'cache_lifetime' => 86400,
        ]);
        if (!$this->hasData('template') && !$this->getTemplate()) {
            $this->setTemplate('OTC_BannerSlider::bannerslider.phtml');
        }
        parent::_construct();
    }

}
