<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Vibe\OrderReturn\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\DataObject;
use Magento\Sales\Model\OrderFactory;
use Magento\Backend\Model\View\Result\ForwardFactory;

class FormPost extends Action
{
    /**
     * @var \Magento\Framework\Data\Form\FormKey\Validator
     */
    protected $formKeyValidator;

    /**
     * @var OrderFactory
     */
    protected $orderFactory;

    /**
     * @var \Magento\Backend\Model\View\Result\Forward
     */
    protected $resultForwardFactory;

    /**
     * @param Validator $formKeyValidator
     * @param Context $context
     * @param OrderFactory $orderFactory
     * @param ForwardFactory $resultForwardFactory
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        ForwardFactory $resultForwardFactory,
        OrderFactory $orderFactory,
        Validator $formKeyValidator,
        Context $context
    ) {
        $this->resultForwardFactory = $resultForwardFactory;
        $this->orderFactory = $orderFactory;
        $this->formKeyValidator = $formKeyValidator;
        parent::__construct($context);
    }

    /**
     * Process address form save
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        $response = new DataObject();

        if (!$this->formKeyValidator->validate($this->getRequest())) {
            $response->setError(1);
            $response->setMessage(__('Form key is missing'));
        }

        if ($this->getRequest()->getPost('order_id') || $this->getRequest()->getPost('email')) {

            $orderId = $this->getRequest()->getPost('order_id');
            $email = $this->getRequest()->getPost('email');

            $order = $this->orderFactory->create()->getCollection()
                ->addFieldToFilter('customer_email', $email)
                ->addFieldToFilter('increment_id', $orderId);

            if($order->getSize() >0)
            {
                $url = $this->_url->getUrl(
                    'order-return/index/view',
                    ['order_id' => $orderId]
                );
                $response->setError(0);
                $response->setUrl($url);
            }else{
                $response->setError(1);
                $response->setMessage(__('No order found with this email and ID'));
            }
        }else{
            $response->setError(1);
            $response->setMessage(__('Email and Order Id are required.'));
        }

        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($response->toArray());
        return $resultJson;

    }
}
