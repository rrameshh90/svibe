/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    deps: [
        "js/slick-carousel",
        "js/video-player"
    ],

    map: {
        '*': {
            "jquery/hoverintent": "lib/jquery-hoverintent/jquery.hoverIntent.min",
            "SPmodal": "js/modal",
            "SPmodalMinicart": "js/modal-minicart",
            "SPmodalWishlist": "js/modal-wishlist",
            "SPmodalPhotoswipe": "js/modal-photoswipe",
            "mobileMenu": "js/mobile-menu",
            "Ecomm/modal": "js/modal",
            'AtloopOwlAddtocart': 'js/loopaddtocart-owl.carousel',
            "AtProductValidate": 'js/validate-product',            
            "SPExpand": "js/expand",
            "sp-product": "js/sp-product",
            "sp-catalog": "js/sp-catalog",
            "spslide": "Magento_Bundle/js/spslide",
            "sticky-sidebar": "js/sticky-sidebar",
            "sp-video": "js/sp-video",
            "SPmobileNoSlider": "js/mobile-noslider",
            "SPsticky": "js/sticky",
            "photoswipe": "lib/photoswipe/photoswipe",
            "photoswipe-ui": "lib/photoswipe/photoswipe-ui-default",
            "photoswipe-init":  "js/photoswipe",
            'campaignJS': 'Magento_Catalog/js/product/campaign'
        }
    },
    paths:{},
    shim:{},
    config: {
        mixins: {
            'Magento_Catalog/js/catalog-add-to-cart': {
                'js/mixins/catalog-add-to-cart': true
            },
            'Magento_Paypal/js/order-review': {
                'js/mixins/order-review': true
            }
        }
    }
};
if (!SP_CATALOG_AJAX) {
    delete config.config.mixins['Magento_Catalog/js/catalog-add-to-cart'];
}

if(SP_OWL_DISABLE){
    delete config.map['*']['AtloopOwlAddtocart'];
}
if(SP_WAYPOINTS){
    config.paths['waypoints'] = "js/waypoints";
    config.shim['js/waypoints'] = ["jquery"];
    config.map['*']['waypoints'] = "js/waypoints";
    config.map['*']['sp-waypoints-init'] = "js/waypoints-init";
}