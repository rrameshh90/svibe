<?php
return [
    'backend' => [
        'frontName' => 'admin'
    ],
    'remote_storage' => [
        'driver' => 'file'
    ],
    'queue' => [
        'consumers_wait_for_messages' => 1
    ],
    'db' => [
        'connection' => [
            'indexer' => [
                'host' => 'localhost',
                'dbname' => 'otc_vibe_uat_bk_30_10_23',
                'username' => 'root',
                'password' => 'P@ssw0rd',
                'model' => 'mysql4',
                'engine' => 'innodb',
                'initStatements' => 'SET NAMES utf8;',
                'active' => '1',
                'persistent' => null
            ],
            'default' => [
                'host' => 'localhost',
                'dbname' => 'otc_vibe_uat_bk_30_10_23',
                'username' => 'root',
                'password' => 'P@ssw0rd',
                'model' => 'mysql4',
                'engine' => 'innodb',
                'initStatements' => 'SET NAMES utf8;',
                'active' => '1',
                'driver_options' => [
                    1014 => false
                ]
            ]
        ],
        'table_prefix' => ''
    ],
    'crypt' => [
        'key' => '0dd1633345adcfb836da5559a7e4c0d5'
    ],
    'resource' => [
        'default_setup' => [
            'connection' => 'default'
        ]
    ],
    'x-frame-options' => 'SAMEORIGIN',
    'MAGE_MODE' => 'developer',
    'session' => [
        'save' => 'files'
    ],
    'cache' => [
        'frontend' => [
            'default' => [
                'id_prefix' => 'bc9_'
            ],
            'page_cache' => [
                'id_prefix' => 'bc9_'
            ]
        ],
        'allow_parallel_generation' => false
    ],
    'lock' => [
        'provider' => 'db',
        'config' => [
            'prefix' => ''
        ]
    ],
    'directories' => [
        'document_root_is_pub' => true
    ],
    'cache_types' => [
        'config' => 1,
        'layout' => 0,
        'block_html' => 0,
        'collections' => 1,
        'reflection' => 1,
        'db_ddl' => 1,
        'compiled_config' => 1,
        'eav' => 1,
        'customer_notification' => 1,
        'config_integration' => 1,
        'config_integration_api' => 1,
        'full_page' => 0,
        'target_rule' => 1,
        'config_webservice' => 1,
        'translate' => 1,
        'vertex' => 1
    ],
    'install' => [
        'date' => 'Thu, 23 Mar 2023 04:20:01 +0000'
    ],
    'system' => [
        'stores' => [
            'vibe_us' => [
                'web' => [
                    'unsecure' => [
                        'base_url' => 'http://uat-us.otc.local/',
                        'base_link_url' => '{{unsecure_base_url}}'
                    ],
                    'secure' => [
                        'base_url' => 'http://uat-us.otc.local/',
                        'base_link_url' => '{{secure_base_url}}',
                        'base_static_url' => '{{secure_base_url}}/static/'
                    ]
                ]
            ]
        ]
    ]
];
