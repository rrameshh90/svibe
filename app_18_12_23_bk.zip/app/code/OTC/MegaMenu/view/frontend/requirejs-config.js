var config = {
    map: {
        '*': {
            'SpMegaMenu': 'OTC_MegaMenu/js/megamenu',
            'plugins/velocity': 'OTC_MegaMenu/js/velocity.min',
            'plugins/scrollbar': 'OTC_MegaMenu/js/perfect-scrollbar.jquery.min',
        }
    }
};
if (SP_MOBILE) {
    delete config.map['*']['plugins/velocity'];
    delete config.map['*']['plugins/scrollbar'];
}