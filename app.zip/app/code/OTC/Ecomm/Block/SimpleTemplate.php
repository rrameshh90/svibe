<?php

namespace OTC\Ecomm\Block;

use Magento\Customer\Model\Session;
use Magento\Framework\View\Element\Template;
use Magento\Store\Model\ScopeInterface;

/**
 * SimpleTemplate
 */
class SimpleTemplate extends Template
{

    /**
     * @var Session
     */
    protected $session;

    /**
     * @param Template\Context $context
     * @param Session $session
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Session $session,
        array $data = []
    ) {
        $this->session = $session;
        parent::__construct($context, $data);
    }

    /**
     * @return mixed
     */
    public function isLoggedIn()
    {
        return $this->session->isLoggedIn();
    }


    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    public function getConfig($path, $storeCode = null)
    {
        return $this->getSystemValue($path, $storeCode);
    }

    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    public function getSystemValue($path, $storeCode = null)
    {
        $value = $this->_scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeCode);
        if (is_null($value)) {
            $value = '';
        }
        return $value;
    }

}
