<?php
namespace Vibe\Contact\Api;

use Vibe\Contact\Api\Data\GridInterface;
/**
 * Interface ContactusManagementInterface
 *
 * @package Vibe\Contact\Api
 */
interface ContactusManagementInterface
{

    /**
     * Contact us form.
     *
     * @param mixed $contactForm
     * @return GridInterface
     */

    public function submitForm($contactForm);

}
