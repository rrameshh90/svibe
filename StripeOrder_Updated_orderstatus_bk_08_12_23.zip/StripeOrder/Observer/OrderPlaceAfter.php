<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Vibe\StripeOrder\Observer;


use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Api\OrderRepositoryInterface;
use Vibe\CustomCheckoutUrl\Plugin\Helper;
use Vibe\StripeOrder\Model\Api\PaymentInformation;
use Vibe\StripeOrder\Logger\Logger;
use Vibe\StripeOrder\Helper\Data;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Service\InvoiceService;
use Magento\Sales\Model\Order\Email\Sender\InvoiceSender;
use Magento\Framework\DB\Transaction;
/**
 * Performing additional validation each time a user saves a CMS page.
 */
class OrderPlaceAfter implements ObserverInterface
{
    /**
     * @var Logger
     */
    protected $logger;
    /**
     * @var OrderRepository
     */
    protected $orderRepository;

    /**
     * @var  Data
     */
    protected $helper;

    /**
     * @var PaymentInformation
     */
    protected $paymentInformation;

    protected $order;

    /**
     * @var \Magento\Sales\Model\Service\InvoiceService
     */
    protected InvoiceService $_invoiceService;

    /**
     * @var \Magento\Framework\DB\Transaction
     */
    protected Transaction $_transaction;
    protected InvoiceSender $invoiceSender;

    /**
     * @param Logger $logger
     * @param OrderRepositoryInterface $orderRepository
     * @param Data $helper
     * @param PaymentInformation $paymentInformation
     * @param Order $order
     */
    public function __construct(
        Logger $logger,
        OrderRepositoryInterface $orderRepository,
        Helper $helper,
        PaymentInformation $paymentInformation,
        Order $order,
        InvoiceService $invoiceService,
        InvoiceSender $invoiceSender,
        Transaction $transaction
    )
    {
        $this->logger = $logger;
        $this->orderRepository = $orderRepository;
        $this->helper = $helper;
        $this->paymentInformation = $paymentInformation;
        $this->order = $order;
        $this->_invoiceService = $invoiceService;
        $this->invoiceSender = $invoiceSender;
        $this->_transaction = $transaction;
    }

    /**
     * @inheritDoc
     *
     * @throws LocalizedException
     */
    public function execute(Observer $observer)
    {
        $eventorder = $observer->getEvent()->getOrder();
        $orderId = $eventorder->getId();
        $customerId = $eventorder->getCustomerId();
        $order_status       = $eventorder->getStatus();
        $this->logger->info("Stripe Request OrderSIDD : ".$orderId);
        $this->logger->info("Stripe Request OrderStaussw : ".$order_status);
        $this->logger->info("Stripe Request OrderCusromerID : ".$customerId);
        $this->logger->info("<pre>");
        $paymentInfo=$this->paymentInformation->getOrderItem($orderId);
        if(!empty($paymentInfo)){
            if($paymentInfo[0]['message']!="" && $paymentInfo[0]['message']['payment_status']=="paid"){
                $order = $this->orderRepository->get($orderId);
                if($order->canInvoice()) {
                    $invoice = $this->_invoiceService->prepareInvoice($order);
                    $invoice->register();
                    $invoice->setState(\Magento\Sales\Model\Order\Invoice::STATE_PAID);
                    $invoice->getOrder()->setIsInProcess(true);
                    $invoice->save();
                    $transactionSave = $this->_transaction->addObject($invoice)->addObject($invoice->getOrder());
                    $transactionSave->save();
                    $this->invoiceSender->send($invoice);
                    //send notification code
                    $order->addStatusHistoryComment(
                        __('Notified customer about invoice #%1.', $invoice->getId())
                    )
                        ->setIsCustomerNotified(true)
                        ->save();
                    $this->logger->info("Invoice created :");
                }else{
                    $this->logger->info("NO Invoice created :");
                }

            }else{
                $this->logger->info("No wwInvoice created :");
            }
        }

    }


}
