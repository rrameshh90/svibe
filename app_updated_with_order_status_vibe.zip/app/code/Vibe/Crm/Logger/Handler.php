<?php
namespace Vibe\Crm\Logger;

use Magento\Framework\Logger\Handler\Base;
use Monolog\Logger;

/**
 * Crm OrderList Handler Log
 */
class Handler extends Base
{
    /**
     * Logging level
     * @var int
     */
    protected $loggerType = Logger::INFO;

    /**
     * File name
     * @var string
     */
    protected $fileName = '/var/log/crm_orderlist.log';
}
