<?php

namespace OTC\Catalog\Block\Html;

use Magento\Catalog\Helper\Category;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Magento\Catalog\Model\Product\Visibility;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Magento\Framework\Data\Tree\Node\Collection;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Topmenu
 */
class Topmenu extends Template
{

    /**
     * @var CollectionFactory
     */
    protected $categoryCollectionFactory;

    /**
     * @var CategoryFactory
     */
    protected $categoryFactory;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var Category
     */
    protected $categoryHelper;

    /**
     * @param Context $context
     * @param CollectionFactory $categoryCollectionFactory
     * @param CategoryFactory $categoryFactory
     * @param StoreManagerInterface $storeManager
     * @param Category $categoryHelper
     * @param array $data
     */
    public function __construct(
        Context $context,
        CollectionFactory $categoryCollectionFactory,
        CategoryFactory $categoryFactory,
        StoreManagerInterface $storeManager,
        Category $categoryHelper,
        array $data = []
    ) {
        $this->_categoryCollectionFactory = $categoryCollectionFactory;
        $this->categoryFactory = $categoryFactory;
        $this->_storeManager = $storeManager;
        $this->_categoryHelper = $categoryHelper;
        parent::__construct($context, $data);
    }


    /**
     * @return \Magento\Catalog\Model\ResourceModel\Category\Collection
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function getActiveCategoryCollection()
    {
        $collection = $this->_categoryCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addIsActiveFilter();
        $collection->setStore($this->_storeManager->getStore());
        return $collection;
    }

    /**
     * @param $sorted
     * @param $asCollection
     * @param $toLoad
     * @return array|Collection
     */
    public function getStoreCategories($sorted = false, $asCollection = false, $toLoad = true)
    {
        return $this->_categoryHelper->getStoreCategories($sorted = false, $asCollection = false, $toLoad = true);
    }

    /**
     * @param $categoryId
     * @return mixed
     */
    public function getProductCollectionByCategories($categoryId)
    {
        $productCollection = $this->categoryFactory->create()
            ->load($categoryId)
            ->getProductCollection()
            ->addAttributeToSelect('*');
        $productCollection->addAttributeToFilter('visibility', Visibility::VISIBILITY_BOTH);
        $productCollection->addAttributeToFilter('status', Status::STATUS_ENABLED);
        return $productCollection;
    }
}

