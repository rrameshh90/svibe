<?php

namespace OTC\Ecomm\Block;

use Magento\Customer\Model\Form;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Request\Http;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\ScopeInterface;
use OTC\Ecomm\Helper\Helper as CoreHelper;
use OTC\Ecomm\Helper\ProductImage as HelperProductImage;

/**
 * Template
 */
class Template extends SimpleTemplate
{

    const CHILD_TEMPLATE = ChildTemplate::class;

    /**
     * @var HelperProductImage
     */
    protected $productImage;

    /**
     * @var CoreHelper
     */
    protected $coreHelper;

    /**
     * @var Http
     */
    protected $request;

    /**
     * @param Context $context
     * @param Session $session
     * @param HelperProductImage $productImage
     * @param CoreHelper $coreHelper
     * @param Http $request
     * @param array $data
     */
    public function __construct(
        Context $context,
        Session $session,
        HelperProductImage $productImage,
        CoreHelper $coreHelper,
        Http $request,
        array $data = []
    ) {
        $this->productImage = $productImage;
        $this->coreHelper = $coreHelper;
        $this->request = $request;
        parent::__construct(
            $context,
            $session,
            $data
        );
    }

    /**
     * @param $product
     * @param $imageId
     * @param $template
     * @param array $attributes
     * @param $properties
     * @return mixed
     */
    public function getImage(
        $product,
        $imageId,
        $template = HelperProductImage::TEMPLATE,
        array $attributes = [],
        $properties = []
    ) {
        return $this->productImage->getImage(
            $product,
            $imageId,
            $template,
            $attributes,
            $properties
        );
    }

    /**
     * @param $product
     * @param $imageId
     * @param $imageIdHover
     * @param $template
     * @param array $attributes
     * @param $properties
     * @return mixed
     */
    public function getImageHover(
        $product,
        $imageId,
        $imageIdHover,
        $template = HelperProductImage::HOVER_TEMPLATE,
        array $attributes = [],
        $properties = []
    ) {
        return $this->productImage->getImageHover(
            $product,
            $imageId,
            $imageIdHover,
            $template,
            $attributes,
            $properties
        );
    }

    /**
     * @param $product
     * @param $imageId
     * @param $size
     * @param $template
     * @param array $attributes
     * @param $properties
     * @return mixed
     */
    public function getResizedImage(
        $product,
        $imageId,
        $size,
        $template = HelperProductImage::TEMPLATE,
        array $attributes = [],
        $properties = []
    ) {
        return $this->productImage->getResizedImage(
            $product,
            $imageId,
            $size,
            $template,
            $attributes,
            $properties
        );
    }

    /**
     * @param $product
     * @param $imageId
     * @param $imageIdHover
     * @param $size
     * @param $template
     * @param array $attributes
     * @param $properties
     * @return mixed
     */
    public function getResizedImageHover(
        $product,
        $imageId,
        $imageIdHover,
        $size,
        $template = HelperProductImage::HOVER_TEMPLATE,
        array $attributes = [],
        $properties = []
    ) {
        return $this->productImage->getResizedImageHover(
            $product,
            $imageId,
            $imageIdHover,
            $size,
            $template,
            $attributes,
            $properties
        );
    }

    /**
     * @param $product
     * @param $imageId
     * @param $imageIdHover
     * @return mixed
     */
    public function hasHoverImage($product, $imageId, $imageIdHover)
    {
        return $this->productImage->hasHoverImage(
            $product,
            $imageId,
            $imageIdHover
        );
    }

    /**
     * @param $product
     * @param $image
     * @param $size
     * @param $properties
     * @return mixed
     */
    public function getUrlResizedImage($product, $image, $size, $properties = [])
    {
        return $this->productImage->getUrlResizedImage(
            $product,
            $image,
            $size,
            $properties
        );
    }

    /**
     * @return mixed
     */
    public function isLoggedIn()
    {
        return $this->coreHelper->isLoggedIn();
    }

    /**
     * @return mixed
     */
    public function getWishlistCount()
    {
        return $this->coreHelper->getWishlistCount();
    }

    /**
     * @return mixed
     */
    public function getCompareListUrl()
    {
        return $this->coreHelper->getCompareListUrl();
    }

    /**
     * @return mixed
     */
    public function getCompareListCount()
    {
        return $this->coreHelper->getCompareListCount();
    }

    /**
     * @return bool
     */
    public function isAutocompleteDisabled()
    {
        return (bool)!$this->getSystemValue(Form::XML_PATH_ENABLE_AUTOCOMPLETE);
    }

    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    public function getSystemValue($path, $storeCode = null)
    {
        $value = $this->_scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeCode);
        if (is_null($value)) {
            $value = '';
        }
        return $value;
    }

    /**
     * @param $content
     * @return mixed
     */
    public function getBlockTemplateProcessor($content = '')
    {
        if (empty($content) || !is_string($content)) {
            $content = '';
        }
        return $this->coreHelper->getBlockTemplateProcessor($content);
    }

    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    public function getConfig($path, $storeCode = null)
    {
        return $this->getSystemValue($path, $storeCode);
    }

    /**
     * @param $pageFullActionName
     * @return bool
     */
    public function isCurrentPage($pageFullActionName)
    {
        if (empty($pageFullActionName)) {
            return true;
        }
        if (is_string($pageFullActionName)) {
            $pageFullActionName = explode(',', $pageFullActionName);
        }

        $pageFullActionName = array_filter($pageFullActionName);
        if (empty($pageFullActionName)) {
            return true;
        }

        return in_array($this->getFullActionName(), $pageFullActionName);
    }

    /**
     * @return mixed
     */
    public function getFullActionName()
    {
        return $this->request->getFullActionName();
    }

}
