<?php

namespace Vibe\Contact\Api\Data;

/**
 * Category Interface
 */
interface CategoryInterface
{
    /**
     * Constants for keys of data array.
     */
    const ID = 'id';
    const CATEGORY = 'category';
    const STORE = 'store_id';
    const STATUS = 'status';
    const SORTORDER = 'sortorder';
    const CREATED_AT = 'created_at';

   /**
    * Get EntityId.
    *
    * @return int
    */
    public function getId();

   /**
    * Set EntityId.
    * @return $this
    */
    public function setId($id);

   /**
    * Get Category.
    *
    * @return string|null
    */
    public function getCategory();

   /**
    * Set Category.
    *
    * @return $this
    */
    public function setCategory($category);

    /**
    * Get CreatedAt.
    *
    * @return string|null
    */
    public function getCreatedAt();

   /**
    * Set CreatedAt.
    *
    * @return $this
    */
    public function setCreatedAt($createdAt);

    /**
     * Get Website.
     *
     * @return string|null
     */
    public function getStoreId();

    /**
     * Set Store.
     *
     * @return $this
     */
    public function setStoreId($store);

    /**
     * Get Status.
     *
     * @return string|null
     */
    public function getStatus();

    /**
     * Set Status.
     *
     * @return $this
     */
    public function setStatus($status);

    /**
     * Get SortOrder.
     *
     * @return string|null
     */
    public function getSortOrder();

    /**
     * Set SortOrder.
     *
     * @return $this
     */
    public function setSortOrder($sortorder);

}
