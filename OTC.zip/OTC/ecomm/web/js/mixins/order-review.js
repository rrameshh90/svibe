define([
    'jquery'
], function ($) {
    return function (orderReview) {
        $.widget('mage.orderReview', orderReview, {
            /**
             * hide ajax loader
             */
            _ajaxComplete: function () {
                this._super();
                $('body').trigger('contentUpdated');
            },
        });

        return $.mage.orderReview;
    }
});