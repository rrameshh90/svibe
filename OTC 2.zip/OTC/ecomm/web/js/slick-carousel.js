define([
    'jquery',
    'slick'
], function ($) {

    const slickCarousel = $(".slick-carousel-container > .slick-carousel-item");

    if (slickCarousel?.length) {
        $(".slick-carousel-container").slick({
            slidesToScroll: 1,
            swipeToSlide: true,
            slidesToShow: 3,
            infinite: false,
            dots: true,
            arrows: false,
            responsive: [
                {
                    breakpoint: 950,
                    settings: {
                        dots: true,
                        arrows: false,
                        slidesToShow: 2,
                        slidesToScroll: 1
                    }
                },
                {
                    breakpoint: 640,
                    settings: {
                        dots: true,
                        arrows: false,
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        })
    }

});