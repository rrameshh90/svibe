<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Vibe\Blog\Model;

use Magento\Cms\Helper\Page as PageHelper;
use Vibe\Blog\Api\Data\PageInterface;
use Vibe\Blog\Model\Page\CustomLayout\CustomLayoutRepository;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\DataObject\IdentityInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Validation\ValidationException;
use Magento\Framework\Validator\HTML\WYSIWYGValidatorInterface;

/**
 * Blog Page Model
 *
 * @api
 * @method Page setStoreId(int $storeId)
 * @method int getStoreId()
 * @SuppressWarnings(PHPMD.ExcessivePublicCount)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @since 100.0.2
 */
class Page extends AbstractModel implements PageInterface, IdentityInterface
{
    const STATUS_ENABLED = 1;
    const STATUS_DISABLED = 0;

    /**
     * Blog page cache tag
     */
    const CACHE_TAG = 'blog_p';

    /**
     * @var string
     */
    protected $_cacheTag = self::CACHE_TAG;

    /**
     * Prefix of model events names
     *
     * @var string
     */
    protected $_eventPrefix = 'blog_page';
    /**#@-*/

    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @var CustomLayoutRepository
     */
    private $customLayoutRepository;

    /**
     * @var WYSIWYGValidatorInterface
     */
    private $wysiwygValidator;

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null $resourceCollection
     * @param array $data
     * @param CustomLayoutRepository|null $customLayoutRepository
     * @param WYSIWYGValidatorInterface|null $wysiwygValidator
     */
    public function __construct(
      \Magento\Framework\Model\Context $context,
      \Magento\Framework\Registry $registry,
      \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
      \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
      array $data = [],
      ScopeConfigInterface $scopeConfig,
      CustomLayoutRepository $customLayoutRepository,
      WYSIWYGValidatorInterface $wysiwygValidator
    )
    {
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
        $this->scopeConfig = $scopeConfig;
        $this->customLayoutRepository = $customLayoutRepository;
        $this->wysiwygValidator = $wysiwygValidator;
    }

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Vibe\Blog\Model\ResourceModel\Page::class);
    }

    /**
     * Check if page identifier exist for specific store return page id if page exists
     *
     * @param string $identifier
     * @param int $storeId
     * @return int
     * @throws LocalizedException
     */
    public function checkIdentifier($identifier, $storeId)
    {
        return $this->_getResource()->checkIdentifier($identifier, $storeId);
    }

    /**
     * Prepare page's statuses.
     *
     * @return array
     */
    public function getAvailableStatuses()
    {
        return [self::STATUS_ENABLED => __('Enabled'), self::STATUS_DISABLED => __('Disabled')];
    }

    /**
     * Get identities
     *
     * @return array
     */
    public function getIdentities(): array
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getStores()
    {
        return $this->hasData('stores') ? $this->getData('stores') : (array)$this->getData('store_id');
    }

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId(): ?int
    {
        return parent::getData(self::BLOG_ID);
    }

    /**
     * Get identifier
     *
     * @return string
     */
    public function getIdentifier(): string
    {
        return $this->getData(self::IDENTIFIER);
    }

    /**
     * Get title
     *
     * @return string|null
     */
    public function getTitle(): ?string
    {
        return $this->getData(self::TITLE);
    }

    /**
     * Get page layout
     *
     * @return string|null
     */
    public function getBlogLayout(): ?string
    {
        return $this->getData(self::BLOG_LAYOUT);
    }

    /**
     * Get meta title
     *
     * @return string|null
     * @since 101.0.0
     */
    public function getMetaTitle(): ?string
    {
        return $this->getData(self::META_TITLE);
    }

    /**
     * Get meta keywords
     *
     * @return string|null
     */
    public function getMetaKeywords(): ?string
    {
        return $this->getData(self::META_KEYWORDS);
    }

    /**
     * Get meta description
     *
     * @return string|null
     */
    public function getMetaDescription(): ?string
    {
        return $this->getData(self::META_DESCRIPTION);
    }

    /**
     * Get content heading
     *
     * @return string|null
     */
    public function getContentHeading(): ?string
    {
        return $this->getData(self::CONTENT_HEADING);
    }

    /**
     * Get content
     *
     * @return string|null
     */
    public function getContent(): ?string
    {
        return $this->getData(self::CONTENT);
    }

    /**
     * Get creation time
     *
     * @return string|null
     */
    public function getCreationTime(): ?string
    {
        return $this->getData(self::CREATION_TIME);
    }

    /**
     * Get update time
     *
     * @return string|null
     */
    public function getUpdateTime(): ?string
    {
        return $this->getData(self::UPDATE_TIME);
    }

    /**
     * Get sort order
     *
     * @return string|null
     */
    public function getSortOrder(): ?string
    {
        return $this->getData(self::SORT_ORDER);
    }

    /**
     * Get layout update xml
     *
     * @return string|null
     */
    public function getLayoutUpdateXml(): ?string
    {
        return $this->getData(self::LAYOUT_UPDATE_XML);
    }

    /**
     * Get custom theme
     *
     * @return string|null
     */
    public function getCustomTheme(): ?string
    {
        return $this->getData(self::CUSTOM_THEME);
    }

    /**
     * Get custom root template
     *
     * @return string|null
     */
    public function getCustomRootTemplate(): ?string
    {
        return $this->getData(self::CUSTOM_ROOT_TEMPLATE);
    }

    /**
     * Get custom layout update xml
     *
     * @return string|null
     */
    public function getCustomLayoutUpdateXml(): ?string
    {
        return $this->getData(self::CUSTOM_LAYOUT_UPDATE_XML);
    }

    /**
     * Get custom theme from
     *
     * @return string|null
     */
    public function getCustomThemeFrom(): ?string
    {
        return $this->getData(self::CUSTOM_THEME_FROM);
    }

    /**
     * Get custom theme to
     *
     * @return string|null
     */
    public function getCustomThemeTo(): ?string
    {
        return $this->getData(self::CUSTOM_THEME_TO);
    }

    /**
     * @return string|null
     */
    public function getFeaturedImage(): ?string
    {
        return $this->getData(self::FEATURED_IMAGE);
    }

    /**
     * @return string|null
     */
    public function getShortDescription(): ?string
    {
        return $this->getData(self::SHORT_DESCRIPTION);
    }

    /**
     * @return string|null
     */
    public function getPublishDate(): ?string
    {
        return $this->getData(self::PUBLISH_DATE);
    }

    /**
     * Is active
     *
     * @return bool|null
     */
    public function isActive(): ?bool
    {
        return (bool)$this->getData(self::IS_ACTIVE);
    }

    /**
     * Set ID
     *
     * @param int $id
     * @return PageInterface
     */
    public function setId($id): PageInterface
    {
        return $this->setData(self::BLOG_ID, $id);
    }

    /**
     * Set identifier
     *
     * @param string $identifier
     * @return PageInterface
     */
    public function setIdentifier(string $identifier): PageInterface
    {
        return $this->setData(self::IDENTIFIER, $identifier);
    }

    /**
     * Set title
     *
     * @param string $title
     * @return PageInterface
     */
    public function setTitle(string $title): PageInterface
    {
        return $this->setData(self::TITLE, $title);
    }

    /**
     * Set page layout
     *
     * @param string $blogLayout
     * @return PageInterface
     */
    public function setBlogLayout(string $blogLayout): PageInterface
    {
        return $this->setData(self::BLOG_LAYOUT, $blogLayout);
    }

    /**
     * Set meta title
     *
     * @param string $metaTitle
     * @return PageInterface
     * @since 101.0.0
     */
    public function setMetaTitle(string $metaTitle): PageInterface
    {
        return $this->setData(self::META_TITLE, $metaTitle);
    }

    /**
     * Set meta keywords
     *
     * @param string $metaKeywords
     * @return PageInterface
     */
    public function setMetaKeywords(string $metaKeywords): PageInterface
    {
        return $this->setData(self::META_KEYWORDS, $metaKeywords);
    }

    /**
     * Set meta description
     *
     * @param string $metaDescription
     * @return PageInterface
     */
    public function setMetaDescription(string $metaDescription): PageInterface
    {
        return $this->setData(self::META_DESCRIPTION, $metaDescription);
    }

    /**
     * Set content heading
     *
     * @param string $contentHeading
     * @return PageInterface
     */
    public function setContentHeading(string $contentHeading): PageInterface
    {
        return $this->setData(self::CONTENT_HEADING, $contentHeading);
    }

    /**
     * Set content
     *
     * @param string $content
     * @return PageInterface
     */
    public function setContent(string $content): PageInterface
    {
        return $this->setData(self::CONTENT, $content);
    }

    /**
     * @param $shortDescription
     * @return PageInterface
     */

    public function setShortDescription($shortDescription): PageInterface
    {
        return $this->setData(self::SHORT_DESCRIPTION, $shortDescription);
    }

    /**
     * @param $featuredImage
     * @return PageInterface
     */

    public function setFeaturedImage($featuredImage): PageInterface
    {
        return $this->setData(self::FEATURED_IMAGE, $featuredImage);
    }

    /**
     * @param $publishDate
     * @return PageInterface
     */

    public function setPublishDate($publishDate): PageInterface
    {
        return $this->setData(self::PUBLISH_DATE, $publishDate);
    }

    /**
     * Set creation time
     *
     * @param string $creationTime
     * @return PageInterface
     */
    public function setCreationTime(string $creationTime): PageInterface
    {
        return $this->setData(self::CREATION_TIME, $creationTime);
    }

    /**
     * Set update time
     *
     * @param string $updateTime
     * @return PageInterface
     */
    public function setUpdateTime(string $updateTime): PageInterface
    {
        return $this->setData(self::UPDATE_TIME, $updateTime);
    }

    /**
     * Set sort order
     *
     * @param string $sortOrder
     * @return PageInterface
     */
    public function setSortOrder(string $sortOrder): PageInterface
    {
        return $this->setData(self::SORT_ORDER, $sortOrder);
    }

    /**
     * Set layout update xml
     *
     * @param string $layoutUpdateXml
     * @return PageInterface
     */
    public function setLayoutUpdateXml(string $layoutUpdateXml): PageInterface
    {
        return $this->setData(self::LAYOUT_UPDATE_XML, $layoutUpdateXml);
    }

    /**
     * Set custom theme
     *
     * @param string $customTheme
     * @return PageInterface
     */
    public function setCustomTheme(string $customTheme): PageInterface
    {
        return $this->setData(self::CUSTOM_THEME, $customTheme);
    }

    /**
     * Set custom root template
     *
     * @param string $customRootTemplate
     * @return PageInterface
     */
    public function setCustomRootTemplate(string $customRootTemplate): PageInterface
    {
        return $this->setData(self::CUSTOM_ROOT_TEMPLATE, $customRootTemplate);
    }

    /**
     * Set custom layout update xml
     *
     * @param string $customLayoutUpdateXml
     * @return PageInterface
     */
    public function setCustomLayoutUpdateXml(string $customLayoutUpdateXml): PageInterface
    {
        return $this->setData(self::CUSTOM_LAYOUT_UPDATE_XML, $customLayoutUpdateXml);
    }

    /**
     * Set custom theme from
     *
     * @param string $customThemeFrom
     * @return PageInterface
     */
    public function setCustomThemeFrom(string $customThemeFrom): PageInterface
    {
        return $this->setData(self::CUSTOM_THEME_FROM, $customThemeFrom);
    }

    /**
     * Set custom theme to
     *
     * @param string $customThemeTo
     * @return PageInterface
     */
    public function setCustomThemeTo(string $customThemeTo): PageInterface
    {
        return $this->setData(self::CUSTOM_THEME_TO, $customThemeTo);
    }

    /**
     * Set is active
     *
     * @param bool|int $isActive
     * @return PageInterface
     */
    public function setIsActive($isActive): PageInterface
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }

    /**
     * Validate identifier before saving the entity.
     *
     * @return void
     * @throws LocalizedException
     */
    private function validateNewIdentifier(): void
    {
        $originalIdentifier = $this->getOrigData('identifier');
        $currentIdentifier = $this->getIdentifier();
        if ($this->getId() && $originalIdentifier !== $currentIdentifier) {
            switch ($originalIdentifier) {
                case $this->scopeConfig->getValue(PageHelper::XML_PATH_NO_ROUTE_PAGE):
                    throw new LocalizedException(
                        __('This identifier is reserved for "CMS No Route Page" in configuration.')
                    );
                case $this->scopeConfig->getValue(PageHelper::XML_PATH_HOME_PAGE):
                    throw new LocalizedException(
                        __('This identifier is reserved for "CMS Home Page" in configuration.')
                    );
                case $this->scopeConfig->getValue(PageHelper::XML_PATH_NO_COOKIES_PAGE):
                    throw new LocalizedException(
                        __('This identifier is reserved for "CMS No Cookies Page" in configuration.')
                    );
            }
        }
    }

    /**
     * @inheritdoc
     * @since 101.0.0
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function beforeSave()
    {
        if ($this->hasDataChanges()) {
            $this->setUpdateTime(null);
        }

        $this->validateNewIdentifier();

        //Removing deprecated custom layout update if a new value is provided
        $layoutUpdate = $this->getData('layout_update_selected');
        if ($layoutUpdate === '_no_update_' || ($layoutUpdate && $layoutUpdate !== '_existing_')) {
            $this->setCustomLayoutUpdateXml(null);
            $this->setLayoutUpdateXml(null);
        }
        if ($layoutUpdate === '_no_update_' || $layoutUpdate === '_existing_') {
            $layoutUpdate = null;
        }
        $this->setData('layout_update_selected', $layoutUpdate);
        $this->customLayoutRepository->validateLayoutSelectedFor($this);

        //Validating Content HTML.
        $oldValue = null;
        if ($this->getId()) {
            if ($this->getOrigData()) {
                $oldValue = $this->getOrigData(self::CONTENT);
            } elseif (array_key_exists(self::CONTENT, $this->getStoredData())) {
                $oldValue = $this->getStoredData()[self::CONTENT];
            }
        }
        if ($this->getContent() && $this->getContent() !== $oldValue) {
            try {
                $this->wysiwygValidator->validate($this->getContent());
            } catch (ValidationException $exception) {
                throw new ValidationException(
                    __('Content HTML contains restricted elements. %1', $exception->getMessage()),
                    $exception
                );
            }
        }

        return parent::beforeSave();
    }
}
