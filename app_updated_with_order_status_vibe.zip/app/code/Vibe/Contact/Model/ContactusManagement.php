<?php
declare(strict_types=1);

namespace Vibe\Contact\Model;

use Magento\Contact\Model\MailInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\DataObject;
use Magento\Framework\Exception\NoSuchEntityException;
use Vibe\Contact\Api\ContactusManagementInterface;
use Vibe\Contact\Helper\ContactLog;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Serialize\Serializer\Json;

/**
 * Class ContactusManagement
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class ContactusManagement implements ContactusManagementInterface
{

    /**
     * @var mail
     */
    private $mail;

    /**
     * @var data
     */
    protected $dataObjectFactory;
    /**
     * @var formdata
     */
    protected $formData;
    /**
     * @var LogData
     */
    protected $logData;
    /**
     * @var json
     */
    protected $json;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    public function __construct(
        MailInterface $mail,
        \Magento\Framework\DataObjectFactory $dataObjectFactory,
        \Vibe\Contact\Model\GridFactory   $formDataFactory,
        Json $json,
        ContactLog $logData,
        StoreManagerInterface $storeManager
    ) {
        $this->mail = $mail;
        $this->dataObjectFactory = $dataObjectFactory;
        $this->formData = $formDataFactory;
        $this->logData = $logData;
        $this->json = $json;
        $this->storeManager = $storeManager;

    }

    /**
     * @inheritDoc
     *
     */
    public function submitForm($contactForm)
    {

        try{
            if (!empty($contactForm['firstname']) && !empty($contactForm['lastname']) && !empty($contactForm['phone']) && !empty($contactForm['email'])
                && !empty($contactForm['category']) && !empty($contactForm['comment'])){
                try {
                    $this->insertContactForm($contactForm);
                    $this->sendEmail($contactForm);
                    $response[] = ['success' => true, 'message' => "Thanks for contacting us with your comments and questions. We\'ll respond to you very soon."];

                } catch (LocalizedException $e) {
                    $response[] = ['success' => false, 'message' => $e->getMessage()];

                } catch (\Exception $e) {
                    $response[] =  ['success' => false, 'message' => "An error occurred while processing your form. Please try again later."];
                }
            }
            else {
                $response[] =  ['success' => false, 'message' => "An error occurred while processing your form. Please try again later."];
            }
        }catch (\Exception $e) {
            $response = ['success' => false, 'message' => $e->getMessage()];
            $this->logger->info("Form Submit Failed: ". \GuzzleHttp\json_encode($response));
        }
        return $response;
    }

    /**
     * sendEmail
     * @param $post
     * @return void
     */
    private function sendEmail($post): void
    {
        $this->mail->send(
            $post['email'],
            ['data' => new DataObject($post)]
        );
    }

    /**
     * InsertContactForm
     * @param $contactForm
     * @return bool
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function insertContactForm($contactForm): bool
    {
        $model = $this->formData->create();
        $storeId = (int)$contactForm['store_id'];
        $websiteId = (int)$this->storeManager->getStore($storeId)->getWebsiteId();
      //  $websiteCode = $this->storeManager->getWebsite($websiteId)->getCode();
      //  $storeCode = $this->storeManager->getStore($storeId)->getCode();
        $model->addData([
            "firstname" => $contactForm['firstname'],
            "lastname" => $contactForm['lastname'],
            "phone" => $contactForm['phone'],
            "comment" => $contactForm['comment'],
            "email" => $contactForm['email'],
            "category" => $contactForm['category'],
            "privacy" => $contactForm['privacy'],
            "store_id" => $storeId,
            "website" => $websiteId
        ]);
        $saveData = $model->save();
        if($saveData){
            $this->logData->logData("Saved Data ---", $contactForm);
            return true;
        }
        return false;
    }
}
