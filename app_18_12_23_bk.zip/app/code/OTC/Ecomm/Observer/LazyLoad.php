<?php

namespace OTC\Ecomm\Observer;

use Magento\Framework\App\Cache\State;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Response\Http as ResponseHttp;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\PageCache\Model\Cache\Type;
use OTC\Ecomm\Helper\Helper;
use OTC\Ecomm\Helper\LazyLoad as HelperLazyLoad;

/**
 * LazyLoad
 */
class LazyLoad implements ObserverInterface
{

    const CACHE_KEY_PREFIX = 'SP_LazyLoad_';

    const TYPE_IDENTIFIER = Type::TYPE_IDENTIFIER;

    const CACHE_TAG = Type::CACHE_TAG;

    const LAZY_USE_CACHE = 'general/lazy_use_cache';

    /**
     * @var Helper
     */
    protected $helper;

    /**
     * @var State
     */
    protected $cacheState;

    /**
     * @var Type
     */
    protected $cache;

    /**
     * @var Json|null
     */
    protected $serializer;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var Helper
     */
    protected $lazyLoad;

    /**
     * @var bool
     */
    protected $useCache;

    /**
     * FrontSendResponseBefore constructor.
     *
     * @param Helper $helper
     * @param HelperLazyLoad $lazyLoad
     * @param RequestInterface $request
     * @param State $cacheState
     * @param Type $cache
     * @param Json|null $serializer
     */
    public function __construct(
        Helper $helper,
        HelperLazyLoad $lazyLoad,
        RequestInterface $request,
        State $cacheState,
        Type $cache,
        Json $serializer = null
    ) {
        $this->helper = $helper;
        $this->lazyLoad = $lazyLoad;
        $this->request = $request;
        $this->cacheState = $cacheState;
        $this->cache = $cache;
        $this->serializer = $serializer;
    }

    /**
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer) //NOSONAR
    {
        if (!$this->lazyLoad->isEnabled()
            ||
            (
                $this->request->isXmlHttpRequest() &&
                $this->request->isAjax()
            )
        ) {
            return;
        }

        /** @var ResponseHttp $response */
        $response = $observer->getEvent()->getData('response');
        if (!$response) {
            return;
        }
        $html = $response->getBody();
        if (empty($html)) {
            return;
        }
        if ($this->useCache()) {
            $html = $this->_loadCache();
            if (!empty($html)) {
                $response->setBody($html);
                return;
            }
        }

        $html = $this->lazyLoad->replaceImageToLazy($html);

        if ($this->useCache()) {
            $this->_saveCache($html, $response);
        }
        $response->setBody($html);
    }

    /**
     * @return bool
     */
    public function useCache()
    {
        if (!is_bool($this->useCache)) {
            $this->useCache = false;
        }
        return $this->useCache;
    }

    /**
     * Load response from cache storage
     *
     * @return string
     */
    protected function _loadCache()
    {
        $cacheKey = $this->getCacheKey();
        return $this->cache->load($cacheKey);
    }

    /**
     * Get Key for caching block content
     *
     * @return string
     */
    public function getCacheKey()
    {
        $data = [
            $this->request->isSecure(),
            $this->request->getUriString(),
            $this->request->get(ResponseHttp::COOKIE_VARY_STRING),
        ];

        $key = sha1($this->serializer->serialize($data));

        return static::CACHE_KEY_PREFIX . $key;
    }

    /**
     * Save response content to cache storage
     *
     * @param string $html
     * @param ResponseHttp $response
     * @return void
     */
    protected function _saveCache($html, ResponseHttp $response)
    {
        if ($this->cacheState->isEnabled(self::TYPE_IDENTIFIER)
            && (
                $response->getHttpResponseCode() == 200
                || $response->getHttpResponseCode() == 404
            )
            && (
                $this->request->isGet()
                || $this->request->isHead()
            )
        ) {
            $tagsHeader = $response->getHeader('X-Magento-Tags');
            $tags = $tagsHeader ? explode(',', $tagsHeader->getFieldValue()) : [];

            $cacheKey = $this->getCacheKey();
            $tags[] = self::CACHE_TAG;
            $this->cache->save($html, $cacheKey, array_unique($tags));
        }
    }
}
