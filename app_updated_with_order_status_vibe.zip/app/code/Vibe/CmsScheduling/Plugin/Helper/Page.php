<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Vibe\CmsScheduling\Plugin\Helper;

use Magento\Cms\Model\Page as CmsModel;
use Magento\Framework\App\ActionInterface;
use Magento\Framework\Stdlib\DateTime;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

/**
 * CMS Page
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.CyclomaticComplexity)
 * @SuppressWarnings(PHPMD.NPathComplexity)
 */
class Page
{
    /**
     * @var CmsModel
     */
    protected CmsModel $page;
    /**
     * @var TimezoneInterface
     */
    protected TimezoneInterface $timezoneInterface;

    /**
     * @param TimezoneInterface $timezoneInterface
     * @param CmsModel $page
     */
    public function __construct(
        TimezoneInterface $timezoneInterface,
        CmsModel $page
    )
    {
        $this->timezoneInterface = $timezoneInterface;
        $this->page = $page;
    }

    /**
     * @param \Magento\Cms\Helper\Page $subject
     * @param $result
     * @param ActionInterface $action
     * @param $pageId
     * @return void
     */
    public function afterPrepareResultPage(\Magento\Cms\Helper\Page $subject, $result, ActionInterface $action, $pageId = null)
    {
        /* for publish date added code start*/
        if ($result) {
            if ($this->page->load($pageId)) {
                $model = $this->page->load($pageId);

                $currentDate = $this->timezoneInterface->date()->format('y-m-d H:i:s');

                $publishDate = $model->getPublishDate();
                $convertdate = (new \DateTime())->setTimestamp(strtotime($publishDate));
                $finalpublishDate = $convertdate->format(DateTime::DATETIME_PHP_FORMAT);

                $currentToTimestamp = strtotime($currentDate);
                $publishToTimestamp = strtotime($finalpublishDate);

                if ($publishToTimestamp <= $currentToTimestamp) {
                    return $result;
                } else {
                    return false;
                }
            }
        }
    }
}
