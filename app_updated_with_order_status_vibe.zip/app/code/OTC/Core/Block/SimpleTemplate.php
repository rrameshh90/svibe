<?php

namespace OTC\Core\Block;

use Magento\Store\Model\ScopeInterface;

/**
 * SimpleTemplate
 */
class SimpleTemplate extends \Magento\Framework\View\Element\Template
{

    /**
     * @return mixed
     */
    public function isLoggedIn()
    {
        return $this->_session->isLoggedIn();
    }

    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    public function getConfig($path, $storeCode = null)
    {
        return $this->getSystemValue($path, $storeCode);
    }

    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    public function getSystemValue($path, $storeCode = null)
    {
        $value = $this->_scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeCode);
        if (is_null($value)) {
            $value = '';
        }
        return $value;
    }

}
