<?php

namespace Vibe\StripeOrder\Model\Payments;

use Magento\Customer\Model\Session;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Registry;
use Magento\Framework\Session\SessionManagerInterface;
use StripeIntegration\Payments\Helper\Address;
use StripeIntegration\Payments\Helper\Generic;
use StripeIntegration\Payments\Helper\PaymentMethod;
use StripeIntegration\Payments\Model\Config;


/**
 * Rewrite StripeCustomer
 */
class StripeCustomer extends \StripeIntegration\Payments\Model\StripeCustomer
{
    // This is the Customer object, retrieved through the Stripe API
    var $_stripeCustomer = null;
    var $_defaultPaymentMethod = null;
    var $_subscriptions = [];

    public $customerCard = null;
    public $paymentMethodsCache = [];

    /**
     * StripeCustomer constructor,
     * @param Config $config
     * @param Generic $helper
     * @param Address $addressHelper
     * @param PaymentMethod $paymentMethodHelper
     * @param Session $customerSession
     * @param SessionManagerInterface $sessionManager
     * @param Context $context
     * @param Registry $registry
     * @param AbstractResource|null $resource
     * @param AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        Config                  $config,
        Generic                 $helper,
        Address                 $addressHelper,
        PaymentMethod           $paymentMethodHelper,
        Session                 $customerSession,
        SessionManagerInterface $sessionManager,
        Context                 $context,
        Registry                $registry,
        AbstractResource        $resource = null,
        AbstractDb              $resourceCollection = null,
        array                   $data = []
    ) {
        $this->config = $config;
        $this->helper = $helper;
        $this->addressHelper = $addressHelper;
        $this->paymentMethodHelper = $paymentMethodHelper;
        $this->sessionManager = $sessionManager;
        $this->customerSession = $customerSession;

        parent::__construct($config,$helper,$addressHelper,$paymentMethodHelper,$customerSession,$sessionManager,
            $context,$registry,$resource,$resourceCollection,$data); // This will also call _construct after DI logic
    }

    // Called by parent::__construct() after DI logic
    protected function _construct()
    {
        $this->_init('StripeIntegration\Payments\Model\ResourceModel\StripeCustomer');
    }


    public function existsInStripe($skipCache = false)
    {
        return false;
    }
}
