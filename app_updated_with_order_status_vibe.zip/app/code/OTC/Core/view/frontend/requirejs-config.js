var config = {
    paths: {
        'owl.carousel': 'OTC_Core/owl.carousel/owl.carousel.min',
        'SPowlCarousel': 'OTC_Core/owl.carousel'
    },
    shim: {
        'owl.carousel': {deps: ['jquery', 'jquery-ui-modules/widget']}
    }
};
if (SP_OWL_DISABLE) {
    delete config.paths['owl.carousel'];
    delete config.paths['SPowlCarousel'];
    delete config.shim['owl.carousel'];
}