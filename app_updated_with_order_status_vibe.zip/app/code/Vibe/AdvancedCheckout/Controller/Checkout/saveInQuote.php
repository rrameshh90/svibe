<?php

namespace Vibe\AdvancedCheckout\Controller\Checkout;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\Action;
use Magento\Checkout\Model\Session;
use Magento\Quote\Model\QuoteRepository;

/**
 * Class saveInQuote to use save otc_marketing_consent field.
 *
 */
class saveInQuote extends Action
{
     /**
     * @param Context $context
     * @param Session $checkoutSession
     * @param QuoteRepository $quoteRepository
     */
    public function __construct(
        Context $context,
        Session $checkoutSession,
        QuoteRepository $quoteRepository
    )
    {
        $this->checkoutSession = $checkoutSession;
        $this->quoteRepository = $quoteRepository;
        parent::__construct($context);
    }

    /**
     * set the Otc Marketing Consent value into order details
     * @return Page
     */
    public function execute()
    {
        $consentVal = $this->getRequest()->getParam('checkVal');
        $quoteId = $this->checkoutSession->getQuoteId();
        $quote = $this->quoteRepository->get($quoteId);
        $quote->setOtcMarketingConsent($consentVal);
        $quote->save();
    }
}