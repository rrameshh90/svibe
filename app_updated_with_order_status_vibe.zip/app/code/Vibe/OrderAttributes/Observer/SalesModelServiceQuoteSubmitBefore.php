<?php

namespace Vibe\OrderAttributes\Observer;

use Magento\Framework\DataObject\Copy;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\QuoteRepository;
use Psr\Log\LoggerInterface;

/**
 * Class SalesModelServiceQuoteSubmitBefore
 */
class SalesModelServiceQuoteSubmitBefore implements ObserverInterface
{
    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var Copy
     */
    protected $objectCopyService;

    /**
     * @var QuoteRepository
     */
    private $quoteRepository;

    /**
     * @param LoggerInterface $logger
     * @param Copy $objectCopyService
     * @param QuoteRepository $quoteRepository
     */
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        Copy $objectCopyService,
        QuoteRepository $quoteRepository
    )
    {
        $this->logger = $logger;
        $this->objectCopyService = $objectCopyService;
        $this->quoteRepository = $quoteRepository;
    }

    /**
     * @param Observer $observer
     * @return bool|void
     * @throws NoSuchEntityException
     */
    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        $quote = $observer->getEvent()->getQuote();
        $quotes = $this->quoteRepository->get($order->getQuoteId());
        if ($quotes->getOtcMarketingConsent()) {
            $order->setOtcMarketingConsent($quotes->getOtcMarketingConsent());
        }
        return $this;
    }
}
