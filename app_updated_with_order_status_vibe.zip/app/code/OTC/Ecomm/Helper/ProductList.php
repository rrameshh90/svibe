<?php

namespace OTC\Ecomm\Helper;

use Magento\Catalog\Model\Category;
use Magento\Catalog\Model\ResourceModel\Category\Collection;

/**
 * ProductList
 */
class ProductList extends Helper
{

    /**
     * @param $product
     * @return Category|null
     */
    public function getLastCategory($product)
    {
        /** @var Collection $categoryCollection */
        $categoryCollection = $product->getCategoryCollection()
            ->addAttributeToSelect('name')
            ->addAttributeToFilter('is_active', '1');
        if ($rootCategoryId = $this->getRootCategoryId()) {
            $categoryCollection->addFieldToFilter('path', ['like' => '1/' . $rootCategoryId . '%']);
        }
        $category = null;
        if ($categoryCollection->getSize()) {
            $category = null;
            /** @var Category $newCategory */
            foreach ($categoryCollection as $newCategory) {
                $size_path = count(explode('/', $newCategory->getPath()));
                $sizePath = 0;
                if (!empty($category)) {
                    $sizePath = count(explode('/', $category->getPath()));
                }
                if ($sizePath < $size_path) {
                    $category = $newCategory;
                }
            }
        }
        return $category;
    }

    /**
     * @return int
     */
    protected function getRootCategoryId()
    {
        return $this->storeManger->getGroup()->getRootCategoryId();
    }
}
