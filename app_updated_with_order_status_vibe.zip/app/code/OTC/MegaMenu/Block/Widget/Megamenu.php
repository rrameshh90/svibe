<?php

/**/

namespace OTC\MegaMenu\Block\Widget;

use Magento\Customer\Model\Context;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Store\Model\ScopeInterface;
use Magento\Widget\Block\BlockInterface;
use OTC\Core\Block\SimpleTemplate as coreTemplate;

/**
 * Megamenu
 */
class Megamenu extends coreTemplate implements BlockInterface
{

    protected $topMenu;

    /**
     * @var \Magento\Framework\App\Http\Context
     */
    protected $httpContext;

    /**
     * Json Serializer Instance
     *
     * @var Json
     */
    private $json;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \OTC\MegaMenu\Block\Html\Megamenu $topMenu
     * @param \Magento\Framework\App\Http\Context $httpContext
     * @param Json|null $json
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \OTC\MegaMenu\Block\Html\Megamenu $topMenu,
        \Magento\Framework\App\Http\Context $httpContext,
        Json $json,
        array $data = []
    ) {
        $this->_topMenu = $topMenu;

        $this->httpContext = $httpContext;
        $this->json = $json;
        parent::__construct($context, $data);
    }

    /**
     * @param $path
     * @param $default
     * @return array|mixed|string|null
     */
    /**
     * @param $path
     * @param $default
     * @return array|mixed|string|null
     */
    public function getValueOption($path, $default = '')
    {
        if ($this->hasData($path)) {
            $value = $this->getData($path);
            if (is_null($value)) {
                $value = '';
            }
            return $value;
        }
        $value = $this->getConfig($path);
        if (is_null($value)) {
            $value = $default;
        }

        return $value;
    }

    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    /**
     * @param $path
     * @param $storeCode
     * @return mixed
     */
    public function getConfig($path, $storeCode = null)
    {
        return $this->_scopeConfig->getValue(
            'sp_megamenu_settings/general/' . $path,
            ScopeInterface::SCOPE_STORE,
            $storeCode
        );
    }

    /**
     * @param $newval
     * @return array
     * @throws NoSuchEntityException
     */
    /**
     * @param $newval
     * @return array
     * @throws NoSuchEntityException
     */
    public function getCacheKeyInfo($newval = [])
    {
        return array_merge([
            'SHOPXP_MEGAMENU_WIDGET',
            $this->_storeManager->getStore()->getId(),
            $this->_design->getDesignTheme()->getId(),
            $this->httpContext->getValue(Context::CONTEXT_GROUP),
            $this->json->serialize($this->getRequest()->getParams()),
            $this->json->serialize($this->getData()),
            $this->getUrl('*/*/*', ['_current' => true, '_query' => '']),
        ], parent::getCacheKeyInfo(), $newval);
    }

    /**
     * @param $outermostClass
     * @param $childrenWrapClass
     * @param $limit
     * @return string
     */
    /**
     * @param $outermostClass
     * @param $childrenWrapClass
     * @param $limit
     * @return string
     */
    public function getHtml($outermostClass = '', $childrenWrapClass = '', $limit = 0)
    {
        $this->_topMenu->setData('enable_megamenu', true);
        $data = array_diff_key(
            $this->getData(),
            ['type' => '', 'module_name' => '', 'cache_lifetime' => '', 'type_name' => '']
        );
        foreach ($data as $key => $value) {
            $this->_topMenu->setData($key, $value);
        }

        return $this->_topMenu->getHtml($outermostClass, $childrenWrapClass, $limit);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        $this->addData([
            'cache_lifetime' => 86400,
        ]);
        if (!$this->hasData('template') && !$this->getTemplate()) {
            $this->setTemplate('OTC_MegaMenu::widgetmenu.phtml');
        }
        parent::_construct();
    }

    /**
     * @return bool
     */
    /**
     * @return bool
     */
    protected function isEnabled()
    {
        return true;
    }

}
