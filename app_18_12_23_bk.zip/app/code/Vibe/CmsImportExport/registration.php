<?php
/**
 * Copyright Vibe © 2023. All rights reserved
 *
 */
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Vibe_CmsImportExport', __DIR__);

