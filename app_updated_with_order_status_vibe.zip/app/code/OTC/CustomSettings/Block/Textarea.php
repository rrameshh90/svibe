<?php

namespace OTC\CustomSettings\Block;

use Magento\Framework\View\Element\Template;

/**
 * Textarea
 */
class Textarea extends Template
{

    /**
     * @return string
     * @noinspection PhpIssetCanBeReplacedWithCoalesceInspection
     */
    public function _toHtml()
    {
        $inputName = $this->getInputName();
        $column = $this->getColumn();

        return '<textarea id="' . $this->getInputId() . '" name="' . $inputName . '" ' .
            ($column['size'] ? 'size="' . $column['size'] . '"' : '') . ' class="' .
            (isset($column['class']) ? $column['class'] : 'input-text') . '"' .
            (isset($column['style']) ? ' style="' . $column['style'] . '"' : '') . '></textarea>';
    }
}
