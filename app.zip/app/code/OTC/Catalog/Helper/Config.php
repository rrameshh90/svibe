<?php

namespace OTC\Catalog\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Locale\TranslatedLists;
use Magento\Store\Model\ScopeInterface;

/**
 * Class Config
 * @package OTC\Catalog\Helper
 */
class Config extends AbstractHelper
{
    
    const XML_PATH_LOCALE_DATA = 'general/locale/code';

    /**
     * @var TranslatedLists
     */
    protected $translatedLists;

    /**
     * @param Context $context
     * @param TranslatedLists $translatedLists
     */
    public function __construct(
        Context $context,
        TranslatedLists $translatedLists
    ) {
        parent::__construct($context);
        $this->translatedLists = $translatedLists;
    }

    /**
     * Method is used, to get config value.
     * @param null $storeId
     *
     * @return mixed
     */
    public function getLocaleDataByStore($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_LOCALE_DATA,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param null $locale
     * @return mixed
     * @noinspection PhpUndefinedVariableInspection
     */
    public function getLocaleLabelByCode($locale = null)
    {
        $locales = $this->translatedLists->getOptionLocales();
        foreach ($locales as $localeAndRegion) {
            if ($localeAndRegion['value'] == $locale) {
                $localLabel = $localeAndRegion['label'];
            }
        }
        $language = explode(" ", $localLabel);
        $language =preg_replace('/[^A-Za-z0-9\-]/', '', $language);
        return $language[1];
    }

}
