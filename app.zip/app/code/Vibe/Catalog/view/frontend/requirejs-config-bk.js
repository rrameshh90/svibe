var config =
    {
       /* map:
            {
                '*':
                    {
                       'Magento_Catalog/js/catalog-add-to-cart': 'Vibe_Catalog/js/catalog-add-to-cart'
                    }
            }*/
    };
