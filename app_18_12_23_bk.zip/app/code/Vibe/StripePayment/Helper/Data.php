<?php

namespace Vibe\StripePayment\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\ResourceModel\Website\CollectionFactory;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Api\StoreWebsiteRelationInterface;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Store\Model\StoreManagerInterface;



/**
 * Class Data
 * @package Vibe\StripePayment\Helper\Data
 */
class Data extends AbstractHelper
{

    /**
     * Fetch Stripe Secret Key
     */
    const STRIPE_SECRET_TEST_KEY_PATH = 'payment/stripe_payments_basic/stripe_test_sk';

    /**
     * Fetch Stripe Secret Key
     */
    const STRIPE_SECRET_LIVE_KEY_PATH = 'payment/stripe_payments_basic/stripe_live_sk';

    /**
     * Fetch Stripe Failure Url
     */
    const STRIPE_URL = 'https://api.stripe.com/v1/checkout/sessions/';

    /**
     * @var ScopeConfigInterface
     */
    public $scopeConfig;

    /**
     * @var _websiteCollectionFactory
     */
    public $_websiteCollectionFactory;

    /**
     * @var StoreWebsiteRelationInterface
     */
    private $storeWebsiteRelation;

    /**
     * @var EncryptorInterface
     */
    private $encryptor;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /***
     * Data constructor.
     * @param ScopeConfigInterface $scopeConfig
     * @param CollectionFactory $websiteCollectionFactory
     * @param StoreWebsiteRelationInterface $storeWebsiteRelation
     * @param EncryptorInterface $encryptor
     * @param Context $context
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        CollectionFactory $websiteCollectionFactory,
        StoreWebsiteRelationInterface $storeWebsiteRelation,
        StoreManagerInterface $storeManager,
        EncryptorInterface       $encryptor,
        Context $context
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->_websiteCollectionFactory = $websiteCollectionFactory;
        $this->storeWebsiteRelation = $storeWebsiteRelation;
        $this->encryptor = $encryptor;
        $this->storeManager = $storeManager;
        parent::__construct($context);
    }

    /**
     * @param $path
     * @param $storeId
     * @return mixed
     */
    public function getConfigData($path, $storeId)
    {
        return $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE,$storeId);
    }


    /**
     * @param $storeId
     * @return string
     */
    public function getStripeKey($storeId): string
    {
        $mode = $this->scopeConfig->getValue("payment/stripe_payments_basic/stripe_mode", ScopeInterface::SCOPE_STORE,$storeId);
        if($mode == 'live'){
            return (string) $this->scopeConfig->getValue(self::STRIPE_SECRET_LIVE_KEY_PATH, ScopeInterface::SCOPE_STORE,$storeId);

        }
        return (string) $this->scopeConfig->getValue(self::STRIPE_SECRET_TEST_KEY_PATH, ScopeInterface::SCOPE_STORE,$storeId);
    }

    /**
     * Retrieve websites collection of system
     *
     *
     */
    public function getWebsiteLists()
    {
        $collection = $this->_websiteCollectionFactory->create();
        return $collection;
    }

    /**
     * Get Store code by id
     *
     * @param int $id
     *
     * @return string|null
     */
    public function getStoreCodeById(int $id): ?string
    {
        try {
            $storeData = $this->storeManager->getStore($id);
            $storeCode = (string)$storeData->getCode();
        } catch (LocalizedException $localizedException) {
            $storeCode = null;
            $this->logger->error($localizedException->getMessage());
        }
        return $storeCode;
    }

    /**
     * Get store ids from the website
     *
     * @return array
     */
    public function getStripeInfo(): array
    {

        $storeIds = [];
        $websiteArr = [];
        $i=0;
        $stripeArr = '';
        $websiteIds = $this->getWebsiteLists();
        foreach ($websiteIds as $websiteId){
            try {
                $storeIds = $this->storeWebsiteRelation->getStoreByWebsiteId($websiteId->getId());
                $websiteId = $websiteId->getId();
                $j=0;
                $stripeData = [];
                foreach ($storeIds as $storeId){
                    $stripeData[$j]['storeCode'] = $this->storeManager->getStore($storeId)->getCode();
                    $stripeData[$j]['store_id'] = $storeId;
                    $stripeData[$j]['website_id'] = $websiteId;
                    $stripeData[$j]['stripe_url'] = self::STRIPE_URL;
                    $stripeData[$j]['stripe'] = $this->encryptor->decrypt($this->getStripeKey($storeId));
                    $j++;
                }

                $websiteArr[$i] =  $stripeData;

            } catch (Exception $exception) {
                $this->logger->error($exception->getMessage());
            }
            $i++;
        }

        return call_user_func_array('array_merge', $websiteArr);

    }
}



