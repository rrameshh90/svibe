<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Vibe\OrderReturn\Block;

/**
 * return page
 *
 * @api
 * @since 100.0.2
 */
class Page extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlBuilder;
    /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    public $storeManager;

    /**
     * Construct
     *
     * @param \Magento\Framework\UrlInterface $context,
     * @param \Magento\Framework\View\Element\Template\Context $context,
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\UrlInterface $urlBuilder,
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->urlBuilder = $urlBuilder;
        $this->storeManager = $storeManager;
    }

    /**
     * @return string
     */

    public function getPostActionUrl()
    {
        return $this->urlBuilder->getUrl(
            'return/index/formPost',
            ['_secure' => true]
        );
    }
}
