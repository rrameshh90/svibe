<?php
namespace Vibe\StripeOrder\Api;
interface OrderInterface
{
    /**
     * GET for Post api
     * @param string $order_id
     * @return string
     */
    public function getOrderItem($order_id);
}
