var config = {
    config: {
        mixins: {
            'Amasty_Conf/js/swatch-renderer': {
                'OTC_Ecomm/js/Amasty_Conf/swatch-renderer': true
            }
        }
    }
};