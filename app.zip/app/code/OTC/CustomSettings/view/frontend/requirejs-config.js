var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/view/summary/abstract-total': {
                'OTC_CustomSettings/js/view/summary/abstract-total-mixin': true
            }
        }
    },
    map: {
        '*': {
            customOTC: 'OTC_CustomSettings/js/custom_otc'
        }
    }
};