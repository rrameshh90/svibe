<?php

namespace Vibe\StripeOrder\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\ScopeInterface;

/**
 * Class Data
 * @package Vibe\StripeOrder\Helper\Data
 */
class Data extends AbstractHelper
{

    /**
     * Fetch Stripe Secret Key
     */
    const STRIPE_SECRET_TEST_KEY_PATH = 'payment/stripe_payments_basic/stripe_test_sk';

    /**
     * Fetch Stripe Secret Key
     */
    const STRIPE_SECRET_LIVE_KEY_PATH = 'payment/stripe_payments_basic/stripe_live_sk';

    /**
     * Fetch Stripe Success URL
     */
    const STRIPE_SUCCESS_CONFIG_PATH = 'vibe_url/config_url/stripe_success_url';

    /**
     * Fetch Stripe Failure Url
     */
    const STRIPE_FAILURE_CONFIG_PATH = 'vibe_url/config_url/stripe_cancel_url';

    /**
     * @var ScopeConfigInterface
     */
    public $scopeConfig;

    /***
     * Data constructor.
     * @param ScopeConfigInterface $scopeConfig
     * @param Context $context
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        Context $context
    ) {
        $this->scopeConfig = $scopeConfig;
        parent::__construct($context);
    }

    /**
     * @param $path
     * @param $storeId
     * @return mixed
     */
    public function getConfigData($path, $storeId)
    {
        return $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE,$storeId);
    }


    /**
     * @param $storeId
     * @return string
     */
    public function getStripeKey($storeId): string
    {
        $mode = $this->scopeConfig->getValue("payment/stripe_payments_basic/stripe_mode", ScopeInterface::SCOPE_STORE,$storeId);
        if($mode == 'live'){
            return (string) $this->scopeConfig->getValue(self::STRIPE_SECRET_LIVE_KEY_PATH, ScopeInterface::SCOPE_STORE,$storeId);

        }
        return (string) $this->scopeConfig->getValue(self::STRIPE_SECRET_TEST_KEY_PATH, ScopeInterface::SCOPE_STORE,$storeId);
    }

    /**
     * @param $storeId
     * @return string
     */
    public function getSuccessUrl($storeId): string
    {
        return (string) $this->scopeConfig->getValue(self::STRIPE_SUCCESS_CONFIG_PATH, ScopeInterface::SCOPE_STORE,$storeId);
    }

    /**
     * @param $storeId
     * @return string
     */
    public function getCancelUrl($storeId): string
    {
        return (string) $this->scopeConfig->getValue(self::STRIPE_FAILURE_CONFIG_PATH, ScopeInterface::SCOPE_STORE,$storeId);
    }

}


