<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Vibe\Blog\Api\Data;

/**
 * Blog page interface.
 * @api
 * @since 100.0.2
 */
interface PageInterface
{
    const BLOG_ID                  = 'blog_id';
    const IDENTIFIER               = 'identifier';
    const TITLE                    = 'title';
    const BLOG_LAYOUT              = 'blog_layout';
    const META_TITLE               = 'meta_title';
    const META_KEYWORDS            = 'meta_keywords';
    const META_DESCRIPTION         = 'meta_description';
    const CONTENT_HEADING          = 'content_heading';
    const CONTENT                  = 'content';
    const CREATION_TIME            = 'creation_time';
    const UPDATE_TIME              = 'update_time';
    const SORT_ORDER               = 'sort_order';
    const LAYOUT_UPDATE_XML        = 'layout_update_xml';
    const CUSTOM_THEME             = 'custom_theme';
    const CUSTOM_ROOT_TEMPLATE     = 'custom_root_template';
    const CUSTOM_LAYOUT_UPDATE_XML = 'custom_layout_update_xml';
    const CUSTOM_THEME_FROM        = 'custom_theme_from';
    const CUSTOM_THEME_TO          = 'custom_theme_to';
    const IS_ACTIVE                = 'is_active';
    const SHORT_DESCRIPTION        = 'short_description';
    const FEATURED_IMAGE           = 'featured_image';

    const PUBLISH_DATE           = 'publish_date';
    /**#@-*/

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId(): ?int;

    /**
     * Get identifier
     *
     * @return string
     */
    public function getIdentifier(): string;

    /**
     * Get title
     *
     * @return string|null
     */
    public function getTitle(): ?string;

    /**
     * Get page layout
     *
     * @return string|null
     */
    public function getBlogLayout(): ?string;

    /**
     * Get meta title
     *
     * @return string|null
     * @since 101.0.0
     */
    public function getMetaTitle(): ?string;

    /**
     * Get meta keywords
     *
     * @return string|null
     */
    public function getMetaKeywords(): ?string;

    /**
     * Get meta description
     *
     * @return string|null
     */
    public function getMetaDescription(): ?string;

    /**
     * Get content heading
     *
     * @return string|null
     */
    public function getContentHeading(): ?string;

    /**
     * Get content
     *
     * @return string|null
     */
    public function getContent(): ?string;

    /**
     * Get creation time
     *
     * @return string|null
     */
    public function getCreationTime(): ?string;

    /**
     * Get update time
     *
     * @return string|null
     */
    public function getUpdateTime(): ?string;

    /**
     * Get sort order
     *
     * @return string|null
     */
    public function getSortOrder(): ?string;

    /**
     * Get layout update xml
     *
     * @return string|null
     * @deprecated 103.0.4 Existing updates are applied, new are not accepted.
     */
    public function getLayoutUpdateXml(): ?string;

    /**
     * Get custom theme
     *
     * @return string|null
     */
    public function getCustomTheme(): ?string;

    /**
     * Get custom root template
     *
     * @return string|null
     */
    public function getCustomRootTemplate(): ?string;

    /**
     * Get custom layout update xml
     *
     * @deprecated 103.0.4 Existing updates are applied, new are not accepted.
     * @see \Vibe\Blog\Model\Page\CustomLayout\Data\CustomLayoutSelectedInterface
     * @return string|null
     */
    public function getCustomLayoutUpdateXml(): ?string;

    /**
     * Get custom theme from
     *
     * @return string|null
     */
    public function getCustomThemeFrom(): ?string;

    /**
     * Get custom theme to
     *
     * @return string|null
     */
    public function getCustomThemeTo(): ?string;

    /**
     * Get FeaturedImage
     * @return string|null
     *
     */
    public function getFeaturedImage(): ?string;

    /**
     * Get ShortDescription
     * @return string|null
     *
     */
    public function getShortDescription(): ?string;

    /**
     *  Get PublishDate
     * @return string|null
     */
    public function getPublishDate(): ?string;

    /**
     * Is active
     *
     * @return bool|null
     */
    public function isActive(): ?bool;

    /**
     * Set ID
     *
     * @param int $id
     * @return PageInterface
     */
    public function setId(int $id): PageInterface;

    /**
     * Set identifier
     *
     * @param string $identifier
     * @return PageInterface
     */
    public function setIdentifier(string $identifier): PageInterface;

    /**
     * Set title
     *
     * @param string $title
     * @return PageInterface
     */
    public function setTitle(string $title): PageInterface;

    /**
     * Set blog layout
     *
     * @param string $blogLayout
     * @return PageInterface
     */
    public function setBlogLayout(string $blogLayout): PageInterface;

    /**
     * Set meta title
     *
     * @param string $metaTitle
     * @return PageInterface
     * @since 101.0.0
     */
    public function setMetaTitle(string $metaTitle): PageInterface;

    /**
     * Set meta keywords
     *
     * @param string $metaKeywords
     * @return PageInterface
     */
    public function setMetaKeywords(string $metaKeywords): PageInterface;

    /**
     * Set meta description
     *
     * @param string $metaDescription
     * @return PageInterface
     */
    public function setMetaDescription(string $metaDescription): PageInterface;

    /**
     * Set content heading
     *
     * @param string $contentHeading
     * @return PageInterface
     */
    public function setContentHeading(string $contentHeading): PageInterface;

    /**
     * Set content
     *
     * @param string $content
     * @return PageInterface
     */
    public function setContent(string $content): PageInterface;

    /**
     * Set short description
     *
     * @param string $shortDescription
     * @return PageInterface
     */
    public function setShortDescription(string $shortDescription): PageInterface;

    /**
     * Set featured image
     *
     * @param string $featuredImage
     * @return PageInterface
     */
    public function setFeaturedImage(string $featuredImage): PageInterface;

    /**
     * Set publish date
     *
     * @param string $publishDate
     * @return PageInterface
     */
    public function setPublishDate(string $publishDate): PageInterface;

    /**
     * Set creation time
     *
     * @param string $creationTime
     * @return PageInterface
     */
    public function setCreationTime(string $creationTime): PageInterface;

    /**
     * Set update time
     *
     * @param string $updateTime
     * @return PageInterface
     */
    public function setUpdateTime(string $updateTime): PageInterface;

    /**
     * Set sort order
     *
     * @param string $sortOrder
     * @return PageInterface
     */
    public function setSortOrder(string $sortOrder): PageInterface;

    /**
     * Set layout update xml
     *
     * @param string $layoutUpdateXml
     * @return PageInterface
     * @deprecated 103.0.4 Existing updates are applied, new are not accepted.
     */
    public function setLayoutUpdateXml(string $layoutUpdateXml): PageInterface;

    /**
     * Set custom theme
     *
     * @param string $customTheme
     * @return PageInterface
     */
    public function setCustomTheme(string $customTheme): PageInterface;

    /**
     * Set custom root template
     *
     * @param string $customRootTemplate
     * @return PageInterface
     */
    public function setCustomRootTemplate(string $customRootTemplate): PageInterface;

    /**
     * Set custom layout update xml
     *
     * @param string $customLayoutUpdateXml
     * @return PageInterface
     * @deprecated 103.0.4 Existing updates are applied, new are not accepted.
     * @see \Vibe\Blog\Model\Page\CustomLayout\Data\CustomLayoutSelectedInterface
     */
    public function setCustomLayoutUpdateXml(string $customLayoutUpdateXml): PageInterface;

    /**
     * Set custom theme from
     *
     * @param string $customThemeFrom
     * @return PageInterface
     */
    public function setCustomThemeFrom(string $customThemeFrom): PageInterface;

    /**
     * Set custom theme to
     *
     * @param string $customThemeTo
     * @return PageInterface
     */
    public function setCustomThemeTo(string $customThemeTo): PageInterface;

    /**
     * Set is active
     *
     * @param bool|int $isActive
     * @return PageInterface
     */
    public function setIsActive( $isActive): PageInterface;
}
