<?php

namespace Vibe\StripeOrder\Helper\Rewrite;

use Magento\Framework\Exception\LocalizedException;
use Vibe\StripeOrder\Helper\Data;


/**
 * Rewrite Stripe Checkout Session Helper Function
 */
class CheckoutSession extends \StripeIntegration\Payments\Helper\CheckoutSession
{


    /**
     * @param \StripeIntegration\Payments\Model\Config $config
     * @param \StripeIntegration\Payments\Model\PaymentIntent $paymentIntent
     * @param \StripeIntegration\Payments\Model\CheckoutSessionFactory $checkoutSessionFactory
     * @param \StripeIntegration\Payments\Helper\Generic $paymentsHelper
     * @param \StripeIntegration\Payments\Helper\Locale $localeHelper
     * @param \StripeIntegration\Payments\Helper\Subscriptions $subscriptions
     * @param \StripeIntegration\Payments\Helper\Compare $compare
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param Data $configData
     */

    public function __construct(
        \StripeIntegration\Payments\Model\Config $config,
        \StripeIntegration\Payments\Model\PaymentIntent $paymentIntent,
        \StripeIntegration\Payments\Model\CheckoutSessionFactory $checkoutSessionFactory,
        \StripeIntegration\Payments\Helper\Generic $paymentsHelper,
        \StripeIntegration\Payments\Helper\Locale $localeHelper,
        \StripeIntegration\Payments\Helper\Subscriptions $subscriptions,
        \StripeIntegration\Payments\Helper\Compare $compare,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        Data  $configData
    )
    {

        $this->configData = $configData;
        parent::__construct($config,$paymentIntent,$checkoutSessionFactory,$paymentsHelper,
            $localeHelper,$subscriptions,$compare,$scopeConfig);
    }


    protected function getSessionParamsFrom($lineItems, $subscriptions, $quote, $order = null)
    {
        $params = [
            'expires_at' => $this->getExpirationTime(),
            'cancel_url' => $this->configData->getCancelUrl($order->getStoreId()),
            'success_url' => $this->configData->getSuccessUrl($order->getStoreId()),
            'locale' => $this->localeHelper->getStripeCheckoutLocale(),
            'line_items' => $lineItems
        ];

        if (!empty($subscriptions))
        {
            $params["mode"] = "subscription";
            $params["subscription_data"] = [
                "metadata" => $this->subscriptions->collectMetadataForSubscriptions($quote, $subscriptions, $order)
            ];

            foreach ($subscriptions as $subscription)
            {
                $profile = $subscription['profile'];

                if ($profile['trial_days'] > 0)
                    $params["subscription_data"]['trial_period_days'] = $profile['trial_days'];
            }
        }
        else
        {
            $params["mode"] = "payment";
            $params["payment_intent_data"] = $this->convertToPaymentIntentData($this->paymentIntent->getParamsFrom($quote, $order));
            $params["submit_type"] = "pay";
        }

        $params["payment_method_options"] = [
            "acss_debit" => [
                "mandate_options" => [
                    "payment_schedule" => "sporadic",
                    "transaction_type" => "personal"
                ]
            ],
            // "bacs_debit" => [
            //     "setup_future_usage" => "off_session"
            // ]
        ];

        if ($this->config->alwaysSaveCards())
        {
            try
            {
                $this->customer->createStripeCustomerIfNotExists(false, $order);
                $this->stripeCustomer = $this->customer->retrieveByStripeID();
                if (!empty($this->stripeCustomer->id))
                    $params['customer'] = $this->stripeCustomer->id;
            }
            catch (\Stripe\Exception\CardException $e)
            {
                throw new LocalizedException(__($e->getMessage()));
            }
            catch (\Exception $e)
            {
                $this->paymentsHelper->dieWithError(__('An error has occurred. Please contact us to complete your order.'), $e);
            }
        }
        else
        {
            if ($this->paymentsHelper->isCustomerLoggedIn())
                $this->customer->createStripeCustomerIfNotExists(false, $order);

            $this->stripeCustomer = $this->customer->retrieveByStripeID();
            if (!empty($this->stripeCustomer->id))
                $params['customer'] = $this->stripeCustomer->id;
            else if ($order)
                $params['customer_email'] = $order->getCustomerEmail();
            else if ($quote->getCustomerEmail())
                $params['customer_email'] = $quote->getCustomerEmail();

        }

        return $params;
    }
}

