<?php

namespace OTC\EcommSlideshow\Helper;

use OTC\Core\Helper\Helper as CoreHelper;

/**
 * Helper
 */
class Helper extends CoreHelper
{

    /**
     * @return string
     */
    public function setSlideshowLayout()
    {
        if ($this->isSlideshowEnabled()) {
            return sprintf('html/slideshow/%s.phtml', $this->getConfig('ecomslideshow/general/slider'));
        }
        return 'html/slideshow.phtml';
    }

    /**
     * @return bool
     */
    public function isSlideshowEnabled()
    {
        $config = $this->getConfig('ecomslideshow');
        $action = $this->_request->getActionName();
        $controller = $this->_request->getControllerName();
        $module = $this->_request->getModuleName();
        $route = $this->_request->getRouteName();
        $show = false;
        if ($config['general']['enabled']) {
            $show = true;
            if ('home' == $config['general']['show']) {
                $show = false;
                if ('cms' == $module && 'index' == $controller && 'index' == $action) {
                    $show = true;
                }
            }
            if ($show && ('customer' == $route && in_array($action, ['create', 'forgotpassword', 'login']))) {
                $show = false;
            }
        }
        return $show;
    }

}
