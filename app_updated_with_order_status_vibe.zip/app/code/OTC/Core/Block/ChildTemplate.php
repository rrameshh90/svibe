<?php

namespace OTC\Core\Block;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\View\Element\BlockInterface;

/**
 * ChildTemplate
 */
class ChildTemplate extends Template
{

    /**
     * @param $method
     * @param $args
     * @return array|bool|mixed|null
     */
    public function __call($method, $args)
    {
        $parent = $this->getParentBlock();
        if ($parent) {
            return call_user_func_array([$parent, $method], $args);
        }
        return null;
    }

    /**
     * @param $name
     * @return bool
     */
    public function __isset($name)
    {
        $parent = $this->getParentBlock();
        if ($parent) {
            return isset($parent->{$name});
        }
        return false;
    }

    /**
     * @param $name
     * @return null
     */
    public function __get($name)
    {
        $parent = $this->getParentBlock();
        if ($parent) {
            return $parent->{$name};
        }
        return null;
    }

    /**
     * @param $alias
     * @return BlockInterface|bool
     * @throws LocalizedException
     */
    public function getChildBlock($alias)
    {
        $parent = $this->getParentBlock();
        $layout = $parent->getLayout();
        if (!$layout) {
            return false;
        }
        $name = $layout->getChildName($parent->getNameInLayout(), $alias);
        if ($name) {
            return $layout->getBlock($name);
        }
        return false;
    }

    /**
     * @param $alias
     * @param $useCache
     * @return string
     * @throws LocalizedException
     */
    public function getChildHtml($alias = '', $useCache = true)
    {
        $parent = $this->getParentBlock();
        $layout = $parent->getLayout();
        if (!$layout) {
            return '';
        }
        $name = $parent->getNameInLayout();
        $out = '';
        if ($alias) {
            $childName = $layout->getChildName($name, $alias);
            if ($childName) {
                $out = $layout->renderElement($childName, $useCache);
            }
        } else {
            foreach ($layout->getChildNames($name) as $child) {
                $out .= $layout->renderElement($child, $useCache);
            }
        }

        return $out;
    }

    /**
     * @param $alias
     * @param $childChildAlias
     * @param $useCache
     * @return string
     * @throws LocalizedException
     */
    public function getChildChildHtml($alias, $childChildAlias = '', $useCache = true)
    {
        $parent = $this->getParentBlock();
        $layout = $parent->getLayout();
        if (!$layout) {
            return '';
        }
        $childName = $layout->getChildName($parent->getNameInLayout(), $alias);
        if (!$childName) {
            return '';
        }
        $out = '';
        if ($childChildAlias) {
            $childChildName = $layout->getChildName($childName, $childChildAlias);
            $out = $layout->renderElement($childChildName, $useCache);
        } else {
            foreach ($layout->getChildNames($childName) as $childChild) {
                $out .= $layout->renderElement($childChild, $useCache);
            }
        }
        return $out;
    }

    /**
     * @return array
     * @throws LocalizedException
     */
    public function getChildNames()
    {
        $parent = $this->getParentBlock();
        $layout = $parent->getLayout();
        if (!$layout) {
            return [];
        }
        return $layout->getChildNames($parent->getNameInLayout());
    }

    /**
     * @param $groupName
     * @return array
     * @throws LocalizedException
     */
    public function getGroupChildNames($groupName)
    {
        $parent = $this->getParentBlock();
        return $parent->getLayout()->getGroupChildNames(
            $parent->getNameInLayout(),
            $groupName
        );
    }

}
