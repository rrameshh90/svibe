var config = {
    map: {
        '*': {
            'blogCarousel': 'Vibe_Blog/js/blogCarousel'
        }
    },
    shim: {
        'blogCarousel': {
            deps: ['jquery']
        }
    }
};
