<?php

namespace OTC\EcommSlideshow\Block;

use Magento\Backend\Block\Template\Context;
use Magento\Framework\Exception\NoSuchEntityException;
use OTC\Core\Block\Template as coreTemplate;
use OTC\Core\Helper\Helper as CoreHelper;
use OTC\Core\Helper\ProductImage as HelperProductImage;
use OTC\EcommSlideshow\Model\ResourceModel\Slides\Collection;
use OTC\EcommSlideshow\Model\ResourceModel\Slides\CollectionFactory;

/**
 * Slideshow
 */
class Slideshow extends coreTemplate
{
    
    const CHILD_TEMPLATE = 'OTC\EcommSlideshow\Block\ChildTemplate';

    /**
     * @var Collection
     */
    protected $collection;

    /**
     * @var HelperProductImage
     */
    protected $productImage;

    /**
     * @var CoreHelper
     */
    protected $coreHelper;

    /**
     * @param Context $context
     * @param CollectionFactory $collectionFactory
     * @param HelperProductImage $productImage
     * @param CoreHelper $coreHelper
     * @param array $data
     */
    public function __construct(
        Context $context,
        CollectionFactory $collectionFactory,
        HelperProductImage $productImage,
        CoreHelper $coreHelper,
        array $data = []
    ) {
        $this->_collection = $collectionFactory->create();
        parent::__construct($context, $productImage, $coreHelper, $data);
    }

    /**
     * @return array|Collection
     * @throws NoSuchEntityException
     */
    public function getSlides()
    {
        $slides = [
        ];
        switch ($this->getConfig('ecomslideshow/general/slider')) {
            case 'revolution':

                break;

            case 'ecom':
            default:
                $slides = $this->getEcomSlides();
        }

        return $slides;
    }

    /**
     * @return Collection
     * @throws NoSuchEntityException
     */
    public function getEcomSlides()
    {
        $collection = $this->_collection;
        return $collection
            ->addStoreFilter($this->_storeManager->getStore())
            ->addFieldToSelect('*')
            ->addFieldToFilter('status', 1)
            ->setOrder('sort_order', 'asc');
    }

    /**
     * @param array $style
     * @param string $separatorValue
     * @param string $separatorAttribute
     * @return string
     */
    public function prepareStyle(array $style, string $separatorValue = ': ', string $separatorAttribute = ';')
    {
        $style = array_filter($style);
        if (empty($style)) {
            return '';
        }
        foreach ($style as $key => &$value) {
            $value = $key . $separatorValue . $value;
        }
        $style = implode($separatorAttribute, $style);

        return $style;
    }


}
