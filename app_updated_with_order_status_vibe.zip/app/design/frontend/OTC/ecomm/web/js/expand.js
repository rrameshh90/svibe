define([
    'jquery',
    'mage/translate',
    'jquery-ui-modules/widget',
    'jquery-ui-modules/core',
], function ($, $t) {
    'use strict';

    $.widget('mage.SPExpand', {
        options: {
            isMin: true,
            maxHeight: 90,
            more: $t('Show more'),
            less: $t('Show less'),
            checkCurrentSize: true
        },
        _create: function () {
            this._create_html();
            var $expand = this.element.children('.sp-expand'),
                $expandInner = $expand.children('.sp-expand__inner'),
                $expandLink = $expand.children('.sp-expand__link');

            $expand.toggleClass('minimized', this.options.isMin).data({
                'max-height': this.options.maxHeight
            });
            $expandInner.attr('aria-expanded', this.options.isMin ? 'false' : 'true')
            .css('max-height', this.options.isMin ? this.options.maxHeight : '100%');
            $expandLink.find('.more').html(this.options.more);
            $expandLink.find('.less').html(this.options.less);
        },
        _create_html: function () {
            if (this.element.children('.sp-expand').length || (this.options.checkCurrentSize && this.options.maxHeight > this.element.height()))
                return;
            var content = this.element.html(),
                new_content = $('<div class="sp-expand">').append(
                    $('<div class="sp-expand__inner">').html(content)
                ).append('<div class="sp-expand__link"><span class="more"></span><span class="less"></span></div>');
            this.element.html('').append(new_content);
        },
        _init: function () {
            $('body').off('click.SPExpand').on('click.SPExpand', '.sp-expand .sp-expand__link', $.proxy(this._click, this));
        },
        _click: function (event) {
            event.preventDefault();
            var $this = $(event.currentTarget).closest('.sp-expand').eq(0);
            this.toggle($this);
        },
        toggle: function (expand) {
            var $expand = expand || this.element.children('.sp-expand'),
                $expandInner = $expand.children('.sp-expand__inner'),
                max_height = $expand.data('max-height') || 90,
                isMin = $expand.hasClass('minimized');

            $expand.toggleClass('minimized', !isMin);
            $expandInner.attr("aria-expanded", isMin ? "true" : "false")
            .css('max-height', isMin ? '100%' : max_height);
        },
    });

    return $.mage.SPExpand;
});
