<?php

namespace OTC\Ecomm\Block\Html;

use Magento\Backend\Block\Template\Context;
use Magento\Catalog\Block\Product\Image;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Element\Template;
use OTC\Ecomm\Helper\Helper;
use OTC\Ecomm\Helper\ProductImage as HelperProductImage;

/**
 * PrevNextProduct
 */
class PrevNextProduct extends Template
{

    /**
     * @var \OTC\Ecomm\Helper\PrevNextProduct
     */
    protected $prevNextProductHelper;

    /**
     * @var HelperProductImage
     */
    protected $imageHelper;
    
    /**
     * @var Helper
     */
    private $helper;

    /**
     * @param Context $context
     * @param \OTC\Ecomm\Helper\PrevNextProduct $prevNextProductHelper
     * @param Helper $helper
     * @param HelperProductImage $imageHelper
     * @param array $data
     */
    public function __construct(
        Context $context,
        \OTC\Ecomm\Helper\PrevNextProduct $prevNextProductHelper,
        Helper $helper,
        HelperProductImage $imageHelper,
        array $data = []
    ) {
        $this->prevNextProductHelper = $prevNextProductHelper;
        $this->helper = $helper;
        $this->imageHelper = $imageHelper;
        parent::__construct($context, $data);
    }

    /**
     * @return false
     */
    public function getName()
    {
        if ($this->isProductExists()) {
            return $this->getProduct()->getName();
        }
        return false;
    }

    /**
     * @return bool
     */
    public function isProductExists()
    {
        return (bool)$this->getProduct();
    }

    /**
     * @return false
     */
    public function getProductUrl()
    {
        if ($this->isProductExists()) {
            return $this->getProduct()->getProductUrl();
        }
        return false;
    }

    /**
     * @param $imageId
     * @param $template
     * @param array $attributes
     * @param $properties
     * @return false|Image|mixed
     */
    public function getImage(
        $imageId,
        $template = HelperProductImage::TEMPLATE,
        array $attributes = [],
        $properties = []
    ) {
        if ($this->isProductExists()) {
            return $this->imageHelper->getImage(
                $this->getProduct(),
                $imageId,
                $template,
                $attributes,
                $properties
            );
        }
        return false;
    }

    /**
     * @param $imageId
     * @param $imageIdHover
     * @param $template
     * @param array $attributes
     * @param $properties
     * @return false|Image|mixed
     */
    public function getImageHover(
        $imageId,
        $imageIdHover,
        $template = HelperProductImage::HOVER_TEMPLATE,
        array $attributes = [],
        $properties = []
    ) {
        if ($this->isProductExists()) {
            return $this->imageHelper->getImageHover(
                $this->getProduct(),
                $imageId,
                $imageIdHover,
                $template,
                $attributes,
                $properties
            );
        }
        return false;
    }

    /**
     * @param $imageId
     * @param $size
     * @param $template
     * @param array $attributes
     * @param $properties
     * @return false|Image|mixed
     */
    public function getResizedImage(
        $imageId,
        $size,
        $template = HelperProductImage::TEMPLATE,
        array $attributes = [],
        $properties = []
    ) {
        if ($this->isProductExists()) {
            return $this->imageHelper->getResizedImage(
                $this->getProduct(),
                $imageId,
                $size,
                $template,
                $attributes,
                $properties
            );
        }
        return false;
    }

    /**
     * @param $imageId
     * @param $imageIdHover
     * @param $size
     * @param $template
     * @param array $attributes
     * @param $properties
     * @return false|Image|mixed
     */
    public function getResizedImageHover(
        $imageId,
        $imageIdHover,
        $size,
        $template = HelperProductImage::HOVER_TEMPLATE,
        array $attributes = [],
        $properties = []
    ) {
        if ($this->isProductExists()) {
            return $this->imageHelper->getResizedImageHover(
                $this->getProduct(),
                $imageId,
                $imageIdHover,
                $size,
                $template,
                $attributes,
                $properties
            );
        }
        return false;
    }

    /**
     * @param $imageId
     * @param $imageIdHover
     * @return bool
     */
    public function hasHoverImage($imageId, $imageIdHover)
    {
        if ($this->isProductExists()) {
            return $this->imageHelper->hasHoverImage(
                $this->getProduct(),
                $imageId,
                $imageIdHover
            );
        }
        return false;
    }

    /**
     * @return PrevNextProduct
     * @throws NoSuchEntityException
     */
    protected function _prepareLayout()
    {
        if ($this->getIsNext()) {
            $this->setData('product', $this->prevNextProductHelper->getNextProduct());
        } else {
            $this->setData('product', $this->prevNextProductHelper->getPreviousProduct());
        }

        return parent::_prepareLayout();
    }

    /**
     * @return string
     */
    protected function _toHtml()
    {
        if ($this->helper->isEnabled() &&
            $this->helper->getModuleConfig('product/prev_next') &&
            $this->isProductExists()) {
            return parent::_toHtml();
        }
        return '';
    }

}
