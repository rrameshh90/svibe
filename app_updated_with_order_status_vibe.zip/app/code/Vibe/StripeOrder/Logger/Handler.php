<?php
namespace Vibe\StripeOrder\Logger;

use Magento\Framework\Logger\Handler\Base;
use Monolog\Logger;

/**
 * Stripe Payment Handler Log
 */
class Handler extends Base
{
    /**
     * Logging level
     * @var int
     */
    protected $loggerType = Logger::INFO;

    /**
     * File name
     * @var string
     */
    protected $fileName = '/var/log/stripe_payment.log';
}