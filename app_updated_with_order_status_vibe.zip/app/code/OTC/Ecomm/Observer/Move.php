<?php

namespace OTC\Ecomm\Observer;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Store\Model\ScopeInterface;
use OTC\Core\Helper\Helper as CoreHelper;
use OTC\Ecomm\Helper\Helper;

/**
 * Move
 */
class Move implements ObserverInterface
{

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var CoreHelper
     */
    protected $coreHelper;

    /**
     * @var CoreHelper
     */
    private $helper;

    /**
     * @param Helper $helper
     * @param CoreHelper $coreHelper
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        Helper $helper,
        CoreHelper $coreHelper,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->coreHelper = $coreHelper;
        $this->helper = $helper;
    }

    /**
     * @param Observer $observer
     * @return $this|void
     */
    public function execute(Observer $observer)
    {
        if (!$this->getConfig(Helper::XML_ENABLED)) {
            return;
        }
        $layout = $observer->getData('layout');
        /* move minicart in header 1*/
        $headerLayout = $this->getConfig('ecomm_settings/header/header_layout');
        if ($headerLayout == 'header_1') {
            $layout->getUpdate()->addHandle('otc_ecomm_header_move_minicart');
        }
        $fullActionName = $observer->getData('full_action_name');

        if (version_compare($this->helper->getVersion(), '2.3.6', '>')
            && version_compare(
                $this->helper->getVersion(),
                '2.4.0',
                '!='
            )
        ) {
            $layout->getUpdate()->addHandle('otc_ecomm_header_search_args');
        }

        if ($fullActionName == 'catalog_category_view' || $fullActionName == 'catalogsearch_result_index') {
            if ($this->getConfig('ecomm_settings/products_listing/move_cat_title')) {
                $layout->getUpdate()->addHandle('otc_ecomm_category_move_title');
            }
            if ($this->getConfig('ecomm_settings/products_listing/move_cat_cms_block')) {
                $layout->getUpdate()->addHandle('otc_ecomm_category_move_cms_block');
            }
        }
        if ($fullActionName == 'sales_order_print') {
            $layout->getUpdate()->addHandle('otc_remove_newsletter');
        }
        if (!in_array($fullActionName, ['catalog_product_view', 'sp_quickview_catalog_product_view'])) {
            return $this;
        }
        /* move reviews */
        $reviewsInTab = $this->getConfig('ecomm_settings/product/reviews_position');
        if ($reviewsInTab) {
            if ($reviewsInTab == 'spbottom') {
                $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_view_review_spbottom');
            } elseif ($reviewsInTab == 'bottom') {
                $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_view_review_bottom');
            } elseif ($reviewsInTab == 'gallery') {
                $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_view_review_gallery');
            }
        } else {
            $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_view_move_review');
        }

        $tabsInInfo = $this->getConfig('ecomm_settings/product/product_tabs_position');

        if ($tabsInInfo == 'info') {
            $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_tabs_right');
        }
        if ($tabsInInfo == 'spbottom') {
            $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_tabs_spbottom');
        }
        if ($tabsInInfo == 'bottom') {
            $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_tabs_bottom');
        }
        if ($tabsInInfo == 'gallery') {
            $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_tabs_gallery');
        }
        /* move related */
        $moveRelated = $this->getConfig('ecomm_settings/product/related_positon');
        $moveUpsell = $this->getConfig('ecomm_settings/product/upsell_positon');
        if ($moveRelated == 'spbottom') {
            $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_related_spbottom');
        } elseif ($moveRelated == 'bottom') {
            $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_related_bottom');
        } elseif ($moveRelated == 'gallery') {
            $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_related_gallery');
        }
        if ($moveUpsell == 'spbottom') {
            $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_upsell_spbottom');
        } elseif ($moveUpsell == 'bottom') {
            $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_upsell_bottom');
        } elseif ($moveUpsell == 'gallery') {
            $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_upsell_gallery');
        }
        /* sticky product, move elements in sticky wrapper */
        $galleryLayout = $this->getConfig('ecomm_settings/product/gallery_layout');
        $stickyDesc = $this->getConfig('ecomm_settings/product/gallery_sticky');
        $infoWrapper = $this->getConfig('ecomm_settings/product/gallery_wrapper');
        if (($stickyDesc && ($galleryLayout == '1col' || $galleryLayout == '2cols')) || $infoWrapper) {
            $layout->getUpdate()->addHandle('otc_ecomm_catalog_product_info_wrapper');
        }
        /* replace fotorama with css only gallery for mobile theme */
        if ($this->getConfig('ecomm_settings/product/css_only_gallery')
            && $this->coreHelper->isMobileTheme()
        ) {
            $layout->getUpdate()->addHandle('otc_ecomm_css_only_gallery');
            $layout->getUpdate()->addHandle('otc_ecomm_remove_fotorama_video');
        }

        if ($fullActionName == 'catalog_product_view' && ($galleryLayout == '1col' || $galleryLayout == '2cols')) {
            /* remove fotorama video if fotorama disabled */
            $layout->getUpdate()->addHandle('otc_ecomm_remove_fotorama_video');
            /* set product gallery layout */
            $layout->getUpdate()->addHandle('otc_ecomm_product_gallery_layout');
        }
        return $this;
    }

    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    public function getConfig($path, $storeCode = null)
    {
        $value = $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE, $storeCode);
        if (is_null($value)) {
            $value = '';
        }
        return $value;
    }
}
