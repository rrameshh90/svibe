<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace OTC\MegaMenu\Model\Category;

/**
 * Class DataProvider
 *
 * @api
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @since 101.0.0
 */
class DataProvider extends \Magento\Catalog\Model\Category\DataProvider
{

    /**
     * @return array
     * @since 101.0.0
     */
    protected function getFieldsMap()
    {
        $fields = parent::getFieldsMap();
        $fields['sp-menu'] = [
            'sp_title_text_color',
            'sp_title_bg_color',
            'sp_nav_custom_class',
            'sp_nav_custom_link_content',
            'sp_nav_custom_link',
            'sp_nav_custom_link_target',
            'sp_category_label',
            'sp_label_color',
            'sp_label_text_color',
            'sp_columns',
            'sp_nav_column_width',
            'sp_bg_image',
            'sp_data_tm_align_horizontal',
            'sp_nav_type',
            'sp_mm_lvl2_align_vertical',
            'sp_nav_subcategories',
            'sp_menu_width',
            'sp_cat_image',
            'sp_layout',
            'sp_nav_btm',
            'sp_nav_top',
            'sp_nav_left',
            'sp_nav_left_width',
            'sp_nav_right',
            'sp_nav_right_width',
        ];
        return $fields;
    }

}
