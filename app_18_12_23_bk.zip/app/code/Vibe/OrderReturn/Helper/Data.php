<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Vibe\OrderReturn\Helper;

use Magento\Framework\App\Area;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\DataObject;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Address\Renderer;
use Magento\Store\Model\ScopeInterface;

/**
 * Class Data
 * @package Vibe\OrderReturn\Helper\Data
 */

class Data extends AbstractHelper
{
    const STATUS_CODE = 'return_requested';
    const STATUS_STATE = 'return_requested';

    const XML_PATH_RETURN_EMAIL_IDENTITY = 'order_return/general/identity';

    const XML_PATH_RETURN_EMAIL_COPY_TO = 'order_return/general/email_to';

    const XML_PATH_RETURN_CUSTOMER_EMAIL_TEMPLATE = 'order_return/general/customer_template';

    const XML_PATH_RETURN_EMAIL_TEMPLATE = 'order_return/general/template';

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;

    /**
     * @var TransportBuilder
     */
    protected $transportBuilder;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param TransportBuilder $transportBuilder
     * @param \Psr\Log\LoggerInterface $logger
     * @param Renderer $addressRenderer
     * @param Context $context
     */

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        TransportBuilder $transportBuilder,
        \Psr\Log\LoggerInterface $logger,
        Renderer $addressRenderer,
        Context $context
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->transportBuilder = $transportBuilder;
        $this->logger = $logger;
        $this->addressRenderer = $addressRenderer;
        parent::__construct($context);
    }

    /**
     * @param $order
     * @return void
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\MailException
     */
    public function sendEmail($order)
    {
        $this->prepareEmailForCustomer($order);
        $this->prepareEmailForAdmin($order);
    }

    /**
     * @param $order
     * @return $this
     */
    public function prepareEmailForCustomer($order)
    {
        $customerEmail = $order->getCustomerEmail();
        $storeId = $order->getStoreId();
        $templateParams = $this->prepareTemplateVariables($order);
        $customerName = $order->getBillingAddress()->getName();
        $sender = self::XML_PATH_RETURN_EMAIL_IDENTITY;

        $customerTemplateId = $this->scopeConfig->getValue(
            self::XML_PATH_RETURN_CUSTOMER_EMAIL_TEMPLATE,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );

        $recipient = ['email' => $customerEmail, 'name' => $customerName];

        $this->_sendEmailTemplate(
            $customerTemplateId,
            $templateParams,
            $sender,
            $storeId,
            $recipient
        );

        return $this;
    }

    /**
     * @param $templateId
     * @param $templateParams
     * @param $sender
     * @param $storeId
     * @param $recipient
     * @return void
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\MailException
     */
    public  function _sendEmailTemplate(
        $templateId,
        $templateParams,
        $sender,
        $storeId,
        $recipient
    )
    {
        $transport = $this->transportBuilder->setTemplateIdentifier($templateId)
            ->setTemplateOptions(
                [
                    'area' => Area::AREA_FRONTEND,
                    'store' => $storeId
                ]
            )
            ->setTemplateVars($templateParams)
            ->setFrom(
                $this->scopeConfig->getValue(
                    $sender,
                    ScopeInterface::SCOPE_STORE,
                    $storeId
                )
            )
            ->addTo($recipient['email'], $recipient['name'])
            ->getTransport();

        $transport->sendMessage();
    }

    /**
     * @param $order
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\MailException
     */
    public function prepareEmailForAdmin($order)
    {
        $storeId = $order->getStoreId();
        $templateParams = $this->prepareTemplateVariables($order);
        $sender = self::XML_PATH_RETURN_EMAIL_IDENTITY;

        $templateId = $this->scopeConfig->getValue(
            self::XML_PATH_RETURN_EMAIL_TEMPLATE,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );

        $sendTo = [];
        $copyTo = $this->getEmailCopyTo($storeId);

        if (!empty($copyTo)) {
            foreach ($copyTo as $email) {
                $sendTo[] = ['email' => $email, 'name' => null];
            }
        }
        foreach ($sendTo as $recipient)
        {
            $this->_sendEmailTemplate(
                $templateId,
                $templateParams,
                $sender,
                $storeId,
                $recipient
            );
        }
        return $this;
    }

    /**
     * @return array|false
     */
    public function getEmailCopyTo($storeId)
    {
        $data = $this->scopeConfig->getValue(
            self::XML_PATH_RETURN_EMAIL_COPY_TO,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
        if (!empty($data)) {
            return array_map('trim', explode(',', $data));
        }
        return false;
    }

    /**
     * @param Order $order
     * @return array|mixed|null
     */
    public function prepareTemplateVariables(Order $order)
    {
        $transport = [
            'order' => $order,
            'billing' => $order->getBillingAddress(),
            'store' => $order->getStore(),
            'formattedShippingAddress' => $this->getFormattedShippingAddress($order),
            'formattedBillingAddress' => $this->getFormattedBillingAddress($order),
            'order_data' => [
                'customer_name' => $order->getCustomerName(),
                'frontend_status_label' => $order->getFrontendStatusLabel()
            ]
        ];
        $transportObject = new DataObject($transport);

        return $transportObject->getData();
    }

    /**
     * @param $order
     * @return string|null
     */
    public function getFormattedShippingAddress($order)
    {
        return $order->getIsVirtual()
            ? null
            : $this->addressRenderer->format($order->getShippingAddress(), 'html');
    }

    /**
     * @param $order
     * @return string|null
     */

    public function getFormattedBillingAddress($order)
    {
        return $this->addressRenderer->format($order->getBillingAddress(), 'html');
    }

}
