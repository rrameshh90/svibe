<?php

namespace OTC\Ecomm\Block\Product;

use Exception;
use Magento\Backend\Block\Template\Context;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Helper\Product;
use Magento\Catalog\Model\ProductTypes\ConfigInterface;
use Magento\Cms\Model\BlockFactory;
use Magento\Cms\Model\Template\FilterProvider;
use Magento\Customer\Model\Session;
use Magento\Framework\Filter\Template;
use Magento\Framework\Json\EncoderInterface;
use Magento\Framework\Locale\FormatInterface;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\Stdlib\StringUtils;

/**
 * View
 */
class View extends \Magento\Catalog\Block\Product\View
{

    /**
     * @var BlockFactory
     */
    protected $blockFactory;

    /**
     * @var FilterProvider
     */
    protected $filterProvider;

    /**
     * @param Context $context
     * @param \Magento\Framework\Url\EncoderInterface $urlEncoder
     * @param EncoderInterface $jsonEncoder
     * @param StringUtils $string
     * @param Product $productHelper
     * @param ConfigInterface $productTypeConfig
     * @param FormatInterface $localeFormat
     * @param Session $customerSession
     * @param ProductRepositoryInterface $productRepository
     * @param PriceCurrencyInterface $priceCurrency
     * @param BlockFactory $blockFactory
     * @param FilterProvider $filterProvider
     * @param array $data
     */
    public function __construct( //NOSONAR
        \Magento\Catalog\Block\Product\Context $context,
        \Magento\Framework\Url\EncoderInterface $urlEncoder,
        EncoderInterface $jsonEncoder,
        StringUtils $string,
        Product $productHelper,
        ConfigInterface $productTypeConfig,
        FormatInterface $localeFormat,
        Session $customerSession,
        ProductRepositoryInterface $productRepository,
        PriceCurrencyInterface $priceCurrency,
        BlockFactory $blockFactory,
        FilterProvider $filterProvider,
        array $data = []
    ) {
        $this->blockFactory = $blockFactory;
        $this->filterProvider = $filterProvider;
        parent::__construct(
            $context,
            $urlEncoder,
            $jsonEncoder,
            $string,
            $productHelper,
            $productTypeConfig,
            $localeFormat,
            $customerSession,
            $productRepository,
            $priceCurrency,
            $data
        );
    }

    /**
     * @return string
     * @throws Exception
     */
    protected function _toHtml()
    {
        if ($this->allowShowTab()) {
            $blockId = $this->getData('block');
            $attributeCode = $this->getData('attribute');
            if (!empty($blockId)) {
                return $this->getStaticBlockContent($blockId);
            }

            if (!empty($attributeCode)) {
                return $this->getAttributeContent($attributeCode);
            }
        }

        return '';
    }

    /**
     * @return bool
     */
    protected function allowShowTab()  //NOSONAR
    {
        $productSkus = $this->getData('product_skus');
        $categoryIds = $this->getData('category_ids');
        if (empty($categoryIds) && empty($productSkus)) {
            return true;
        }
        $product = $this->getProduct();
        if (!empty($productSkus)) {
            $productSkus = array_filter(explode(',', $productSkus));
            $sku = $product->getSku();
            $id = $product->getId();
            if (in_array($sku, $productSkus) || in_array($id, $productSkus)) {
                return true;
            }
        }
        if (!empty($categoryIds)) {
            $categoryIds = array_filter(explode(',', $categoryIds));
            $productCats = [];
            foreach ($product->getCategoryCollection() as $product_cat) {
                $productCats[] = $product_cat->getId();
            }
            if (0 < count(array_intersect($categoryIds, $productCats))) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param $blockId
     * @return string
     * @throws Exception
     */
    protected function getStaticBlockContent($blockId)
    {
        $storeId = $this->getStoreId();
        $block = $this->blockFactory->create()->setStoreId($storeId)->load($blockId);
        $content = '';
        if ($block) {
            $blockContent = $block->getContent();
            if ($blockContent) {
                $content = $this->getBlockTemplateProcessor($blockContent, $storeId);
            }
        }

        return $content;
    }

    /**
     * @return mixed
     */
    public function getStoreId()
    {
        return $this->_storeManager->getStore()->getId();
    }

    /**
     * @param $content
     * @param $storeId
     * @return string
     * @throws Exception
     */
    public function getBlockTemplateProcessor($content = '', $storeId = null)
    {
        if (empty($content) || !is_string($content)) {
            $content = '';
        }
        $content = trim($content);
        /** @var Template $filter */
        $filter = $this->filterProvider->getBlockFilter();
        if (!empty($storeId)) {
            $filter = $filter->setStoreId($storeId);
        }

        $content = $filter->filter($content);

        return $content;
    }

    /**
     * @param $attributeCode
     * @return string
     * @throws Exception
     */
    protected function getAttributeContent($attributeCode)
    {
        $product = $this->getProduct();
        $attribute = $product->getResource()->getAttribute($attributeCode);
        $content = '';
        if ($attribute) {
            $attrValue = $attribute->getFrontend()->getValue($product);
            if ($attrValue) {
                $content = $this->getBlockTemplateProcessor($attrValue, $this->getStoreId());
            }
        }
        return $content;
    }

}
