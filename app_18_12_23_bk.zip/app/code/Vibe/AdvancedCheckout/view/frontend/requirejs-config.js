var config = {
    config: {
    mixins: {
        'Magento_Checkout/js/view/shipping': {
            'Vibe_AdvancedCheckout/js/view/shipping': true
        },
    }
    }
};