<?php
	/**
	 * @author Vibe Team
	 * @package Vibe_AdvancedCheckout
	 */

	\Magento\Framework\Component\ComponentRegistrar::register(
	    \Magento\Framework\Component\ComponentRegistrar::MODULE,
	    'Vibe_AdvancedCheckout',
	    __DIR__
	);