<?php

namespace OTC\Ecomm\Model\DynamicStyle;

use Exception;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\Message\ManagerInterface as MessageManager;
use Magento\Framework\Registry;
use Magento\Framework\View\LayoutInterface as ViewLayout;
use Magento\Store\Model\StoreManagerInterface as StoreManager;
use OTC\Ecomm\Block\Template;
use OTC\Ecomm\Helper\CssFiles;
use OTC\Ecomm\Helper\Helper;

/**
 * Generator
 */
class Generator
{

    /**
     * Store Manager
     *
     * @var StoreManager
     */
    private $storeManager;

    /**
     * Theme css files
     *
     * @var CssFiles
     */
    private $cssFiles;

    /**
     * Registry
     *
     * @var Registry
     */
    private $registry;

    /**
     * File
     *
     * @var File
     */
    private $file;

    /**
     * View Layout
     *
     * @var ViewLayout
     */
    private $viewLayout;

    /**
     * Store Manager
     *
     * @var MessageManager
     */
    private $messageManager;
    /**
     * @var Helper
     */
    private $helper;

    /**
     * Generator constructor.
     * @param StoreManager $storeManager
     * @param CssFiles $cssFiles
     * @param Registry $registry
     * @param File $file
     * @param ViewLayout $viewLayout
     * @param MessageManager $messageManager
     * @param Helper $helper
     */
    public function __construct(
        StoreManager $storeManager,
        CssFiles $cssFiles,
        Registry $registry,
        File $file,
        ViewLayout $viewLayout,
        MessageManager $messageManager,
        Helper $helper
    ) {
        $this->_storeManager = $storeManager;
        $this->_cssFiles = $cssFiles;
        $this->_registry = $registry;
        $this->_file = $file;
        $this->_viewLayout = $viewLayout;
        $this->_messageManager = $messageManager;
        $this->_helper = $helper;
    }

    /**
     * @param $type
     * @param $website
     * @param $store
     * @return void
     */
    public function generate($type, $website, $store)
    {
        $this->generateCSS($type, $website, $store);
    }

    /**
     * @param $type
     * @param $website
     * @param $store
     * @return void
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function generateCSS($type, $website, $store)
    {
        if (!empty($website)) {
            $this->generateWebsite($type, $website, 'css');
        } elseif (!empty($store)) {
            $this->generateStore($type, $store, 'css');
        } else {
            $this->generateAll($type, 'css');
        }
    }

    /**
     * @param $type
     * @param $id
     * @param $format
     * @return void
     * @throws LocalizedException
     */
    private function generateWebsite($type, $id, $format)
    {
        $website = $this->_storeManager->getWebsite($id);
        $stores = $website->getStoreIds();
        if (!empty($stores) && is_array($stores)) {
            foreach ($stores as $store) {
                $this->generateStore($type, $store, $format);
            }
        }
    }

    /**
     * @param $type
     * @param $id
     * @param $format
     * @return void
     * @throws NoSuchEntityException
     */
    private function generateStore($type, $id, $format)
    {
        $store = $this->_storeManager->getStore($id);
        if (!$store->isActive()) {
            return;
        }
        $storeCode = $store->getCode();
        $dynamicTemplate = sprintf('dynamic_%s/%s.phtml', $format, $type);
        $dynamicFile = sprintf('%s/%s_%s.%s', $this->_cssFiles->getDymanicDir(), $type, $storeCode, $format);

        try {
            $this->_file->createDirectory(dirname($dynamicFile), 0775);
            $block = $this->_viewLayout->getBlock($type . $storeCode . $format);
            if (!$block) {
                $block = $this->_viewLayout->createBlock(
                    Template::class,
                    $type . $storeCode . $format
                );
            }
            $content = $block->setData([
                'area' => 'frontend',
                'dynamic_store_code' => $storeCode
            ])
                ->setTemplate($dynamicTemplate)
                ->toHtml();

            if (!empty($content)) {
                $content = preg_replace('/[\r\n\t]/', ' ', $content);
                $content = preg_replace('/[\r\n\t ]{2,}/', ' ', $content);
                $content = preg_replace('/\s+(\:|\;|\{|\})\s+/', '\1', $content);
                $content = preg_replace('/<[^<>]+>(.*?)<\/[^<>]+>/m', '/* Forbidden tags in styles */', $content);
            }
            $this->_file->filePutContents($dynamicFile, $content);

            $dynamic_file_arg = $this->_helper->getSystemValue(
                'ecomm_design/appearance_custom/dynamic_file_arg'
            );
            $dynamic_file_arg = abs((int)$dynamic_file_arg);
            $dynamic_file_arg++;
            $this->_helper->setSystemValue(
                'ecomm_design/appearance_custom/dynamic_file_arg',
                $dynamic_file_arg,
                ScopeConfigInterface::SCOPE_TYPE_DEFAULT
            );
        } catch (Exception $e) {
            $this->_messageManager->addError(sprintf(__('Failed generaing file: %s<br/>Message: %s'),
                str_replace(BP, '', $dynamicFile), $e->getMessage()));
        }
    }

    /**
     * @param $type
     * @param $format
     * @return void
     * @throws LocalizedException
     */
    private function generateAll($type, $format)
    {
        $websites = $this->_storeManager->getWebsites(false, false);
        if (!empty($websites) && is_array($websites)) {
            foreach ($websites as $website => $value) {
                $this->generateWebsite($type, $website, $format);
            }
        }
    }
}
