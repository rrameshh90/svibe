define([
    'jquery',
], function ($) {

    $(".video-player-thumbnail").click(function () {
        var video_Id = $(this).find(".video-player-thumbnail-image").attr("data-videoId");
        var active_icon = $("<img />", {
            src: "https://au.vibe-hearing.com/-/media/Images/Feature/WSA/Vibe/play-icon.png",
            alt: "playing",
            class: "video-player-thumbnail-image-active"
        })
        if (video_Id) {
            $(".video-player-main iframe").attr("src", `https://www.youtube.com/embed/${video_Id}?rel=0`);
            $(".video-player-thumbnail-image-active").remove();
            $(this).find(".video-player-thumbnail-image-wrapper").append(active_icon);
            $(".video-player-main")[0]?.scrollIntoView({ behavior: 'smooth' });
        }
    })
});