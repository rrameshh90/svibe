<?php

namespace OTC\BannerSlider\Controller\Adminhtml;

use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\Page;

/**
 * Slides
 */
abstract class Slides extends Action
{
    
    /**
     * Init page
     *
     * @param Page $resultPage
     * @return Page
     */
    public function initPage($resultPage)
    {
        $resultPage->setActiveMenu('OTC_Core::OTC_Core')
            ->addBreadcrumb(__('Banners'), __('Banners'))
            ->addBreadcrumb(__('Banner Slides'), __('Banner Slides'));
        return $resultPage;
    }

}
