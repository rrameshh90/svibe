<?php
namespace Vibe\StripePayment\Api;

/**
 * Custom Api Interface
 */
interface StripeApiInterface
{
    /**
     * Get All Posts.
     *
     * @return mixed
     */
    public function getAllStripes();


}
