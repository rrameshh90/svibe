<?php

namespace OTC\Ecomm\Helper;

use Exception;
use Magento\Catalog\Block\Product\Image as CatalogBlockProductImage;
use Magento\Catalog\Helper\Image;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\Product\Image\ParamsBuilder;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\Config\View;
use Magento\Framework\View\ConfigInterface;
use Magento\Store\Model\ScopeInterface;

/**
 * Description of Image
 *
 * @author Master
 */
class ProductImage extends AbstractHelper
{

    const HOVER_IMAGE_ENABLED = 'ecomm_settings/products_listing/hover_image';

    const TEMPLATE = 'Magento_Catalog::product/image_with_borders.phtml';

    const HOVER_TEMPLATE = 'Magento_Catalog::product/hover_image_with_borders.phtml';

    /**
     * @var Image
     */
    protected $imageHelper;

    /**
     * @var ConfigInterface
     */
    protected $viewConfig;

    /**
     * @var View
     */
    protected $configView;

    /**
     * @var string
     */
    protected $magentoVersion;

    /**
     * @var Video
     */
    protected $videoHelper;

    /**
     * @var ProductMetadataInterface
     */
    protected $productMetadata;

    /**
     * @var CatalogBlockProductImage
     */
    protected $catalogBlock;
    
    /**
     * @var ParamsBuilder
     */
    private $imageParamsBuilder;

    /**
     * @param Context $context
     * @param Image $imageHelper
     * @param ConfigInterface $viewConfig
     * @param ParamsBuilder $imageParamsBuilder
     * @param Video $videoHelper
     * @param ProductMetadataInterface $productMetadata
     * @param CatalogBlockProductImage $catalogBlock
     */
    public function __construct(
        Context $context,
        Image $imageHelper,
        ConfigInterface $viewConfig,
        ParamsBuilder $imageParamsBuilder,
        Video $videoHelper,
        ProductMetadataInterface $productMetadata,
        CatalogBlockProductImage $catalogBlock
    ) {
        $this->imageHelper = $imageHelper;
        $this->viewConfig = $viewConfig;
        $this->imageParamsBuilder = $imageParamsBuilder;
        $this->videoHelper = $videoHelper;
        $this->productMetadata = $productMetadata;
        $this->catalogBlock = $catalogBlock;
        parent::__construct($context);
    }

    /**
     * @param Product $product
     * @param string $imageId
     * @param string $imageIdHover
     * @param string $template
     * @param array $attributes
     * @param array $properties
     *
     * @return mixed
     */
    public function getImageHover(
        Product $product,
        $imageId,
        $imageIdHover,
        $template = self::HOVER_TEMPLATE,
        array $attributes = [],
        $properties = []
    ) {
        if (!$this->hasHoverImage($product, $imageId, $imageIdHover)
            && !$this->videoHelper->videoOnHover($product)
        ) {
            return $this->getImage($product, $imageId, self::TEMPLATE, $attributes, $properties);
        }
        if ($this->videoHelper->videoOnHover($product)) {
            $imageIdHover = $imageId;
        }

        $image = $this->_getImage($product, $imageId, $properties)->getUrl();
        $imageMiscParams = $this->getImageParams($imageId);
        $imageHoverMiscParams = $this->getImageParams($imageIdHover);

        $imageHover = $this->resizeImage(
            $product,
            $imageIdHover,
            [
                $imageMiscParams['image_width'],
                $imageMiscParams['image_height'],
            ],
            $properties
        )->getUrl();

        $data = [
            'data' => [
                'template' => $template,
                'product_id' => $product->getId(),
                'product' => $product,
                'image_id' => $imageId,
                'image_hover_id' => $imageIdHover,
                'image_url' => $image,
                'image_hover_url' => $imageHover,
                'label' => $this->getLabel($product, $imageMiscParams['image_type']),
                'label_hover' => $this->getLabel($product, $imageHoverMiscParams['image_type']),
                'width' => $imageMiscParams['image_width'],
                'height' => $imageMiscParams['image_height'],
                'ratio' => $this->getRatio($imageMiscParams['image_width'], $imageMiscParams['image_height']),
                'class' => $this->getClass($attributes),
                'custom_attributes' => $this->getStringCustomAttributes($attributes),
            ],
        ];

        return $this->createTemplate($data);
    }

    /**
     * @param Product $product
     * @param string $imageId
     * @param string $imageIdHover
     *
     * @return bool
     */
    public function hasHoverImage(Product $product, $imageId, $imageIdHover)
    {
        if ($this->hoverImageEnabled()) {
            if ($imageId != $imageIdHover) {
                $imageId = $this->getImageParams($imageId);
                $imageIdHover = $this->getImageParams($imageIdHover);
                if ($imageId['image_type'] !== $imageIdHover['image_type']) {
                    $image = $product->getData($imageId['image_type']);
                    $imageHover = $product->getData($imageIdHover['image_type']);
                    return $image && $imageHover && 'no_selection' !== $imageHover && $image !== $imageHover;
                }
            }
        }

        return false;
    }

    /**
     * @return bool
     */
    public function hoverImageEnabled()
    {
        return (bool)$this->getConfig(static::HOVER_IMAGE_ENABLED);
    }

    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    public function getConfig($path, $storeCode = null)
    {
        return $this->getSystemValue($path, $storeCode);
    }

    /**
     * @param $path
     * @param $storeCode
     * @param $scopeType
     * @return mixed|string
     */
    public function getSystemValue($path, $storeCode = null, $scopeType = ScopeInterface::SCOPE_STORE)
    {
        $value = $this->scopeConfig->getValue(
            $path,
            $scopeType,
            $storeCode
        );
        if (is_null($value)) {
            $value = '';
        }
        return $value;
    }

    /**
     * @param int $imageId
     *
     * @return array
     */
    public function getImageParams($imageId)
    {
        $viewImageConfig = $this->getConfigView()->getMediaAttributes(
            'Magento_Catalog',
            Image::MEDIA_TYPE_CONFIG_NODE,
            $imageId
        );

        $imageMiscParams = $this->imageParamsBuilder->build($viewImageConfig);
        if (empty($imageMiscParams)) {
            $imageMiscParams = $this->getDefaultParams();
            $this->_logger->critical(sprintf('No options found for "%s" images!', $imageId));
        }

        return $imageMiscParams;
    }

    /**
     * Retrieve config view
     *
     * @return View
     */
    protected function getConfigView()
    {
        if (!$this->configView) {
            $this->configView = $this->viewConfig->getViewConfig();
        }
        return $this->configView;
    }

    /**
     * @return array
     */
    protected function getDefaultParams()
    {
        return [
            "image_type" => "small_image",
            "image_height" => 240,
            "image_width" => 240,
            "background" => [255, 255, 255],
            "quality" => 80,
            "keep_aspect_ratio" => true,
            "keep_frame" => true,
            "keep_transparency" => true,
            "constrain_only" => true,
        ];
    }

    /**
     * @param Product $product
     * @param string $imageId
     * @param string $template
     * @param array $attributes
     * @param array $properties
     *
     * @return CatalogBlockProductImage
     */
    public function getImage(
        Product $product,
        $imageId,
        $template = self::TEMPLATE,
        array $attributes = [],
        $properties = []
    ) {
        $image = $this->_getImage($product, $imageId, $properties);
        $imageMiscParams = $this->getImageParams($imageId);

        $data = [
            'data' => [
                'template' => $template,
                'product_id' => $product->getId(),
                'product' => $product,
                'image_id' => $imageId,
                'image_url' => $image->getUrl(),
                'label' => $this->getLabel($product, $imageMiscParams['image_type']),
                'width' => $imageMiscParams['image_width'],
                'height' => $imageMiscParams['image_height'],
                'ratio' => $this->getRatio($imageMiscParams['image_width'], $imageMiscParams['image_height']),
                'class' => $this->getClass($attributes),
                'custom_attributes' => $this->getStringCustomAttributes($attributes),
            ],
        ];

        return $this->createTemplate($data);
    }

    /**
     * @param Product $product
     * @param string $imageId
     * @param array $properties
     *
     * @return Image
     */
    private function _getImage(Product $product, $imageId, $properties = [])
    {
        return $this->imageHelper->init($product, $imageId, $properties);
    }

    /**
     * @param Product $product
     *
     * @param string $imageType
     *
     * @return string
     */
    private function getLabel(Product $product, string $imageType): string
    {
        $label = "";
        if (!empty($imageType)) {
            $label = $product->getData($imageType . '_' . 'label');
        }
        if (empty($label)) {
            $label = $product->getName();
        }
        return (string)$label;
    }

    /**
     * Calculate image ratio
     *
     * @param int $width
     * @param int $height
     *
     * @return float
     */
    private function getRatio(int $width, int $height): float
    {
        if ($width && $height) {
            return $height / $width;
        }
        return 1.0;
    }

    /**
     * Retrieve image class for HTML element
     *
     * @param array $attributes
     *
     * @return string
     */
    private function getClass(array $attributes): string
    {
        return $attributes['class'] ?? 'product-image-photo';
    }

    /**
     * Retrieve image custom attributes for HTML element
     *
     * @param array $attributes
     *
     * @return string|array
     */
    private function getStringCustomAttributes(array $attributes)
    {
        if (!$this->compareVersion()) {
            return $attributes;
        }
        $result = [];
        foreach ($attributes as $name => $value) {
            $result[] = $name . '="' . $value . '"';
        }
        return !empty($result) ? implode(' ', $result) : '';
    }

    /**
     * @param $version
     *
     * @return bool
     */
    protected function compareVersion($version = '2.4.0')
    {
        return version_compare($this->getMagentoVersion(), $version, '<');
    }

    /**
     * @return string
     */
    private function getMagentoVersion()
    {
        if (!$this->magentoVersion) {
            $this->magentoVersion = $this->productMetadata->getVersion();
        }

        return $this->magentoVersion;
    }

    /**
     * @param array $data
     *
     * @return CatalogBlockProductImage
     */
    private function createTemplate()
    {
        return $this->catalogBlock;
    }

    /**
     * @param Product $product
     * @param string $imageId
     * @param array|int $size
     * @param array $properties
     *
     * @return Image
     */
    public function resizeImage(Product $product, $imageId, $size, $properties = [])
    {
        $size = $this->prepareSize($size);
        $image = $this->_getImage($product, $imageId, $properties);
        $image->resize($size[0], $size[1]);

        return $image;
    }

    /**
     * @param array|int $size
     *
     * @return array
     */
    private function prepareSize($size)
    {
        if (is_array($size) && 1 >= count($size)) {
            $size = array_shift($size);
        }
        if (!is_array($size)) {
            $size = [$size, $size];
        }
        $size = array_map('floatval', $size);
        $size = array_map('abs', $size);
        return $size;
    }

    /**
     * @param Product $product
     * @param string $imageId
     * @param string $imageIdHover
     * @param array|int $size
     * @param string $template
     * @param array $attributes
     * @param array $properties
     *
     * @return CatalogBlockProductImage|mixed
     */
    public function getResizedImageHover( //NOSONAR
        Product $product,
        $imageId,
        $imageIdHover,
        $size,
        $template = self::HOVER_TEMPLATE,
        array $attributes = [],
        $properties = []
    ) {
        if (!is_array($template)) {
            $template = [
                $template,
                self::TEMPLATE,
            ];
        } else {
            foreach ([self::HOVER_TEMPLATE, self::TEMPLATE] as $key => $value) {
                if (!isset($template[$key]) || empty($template[$key])) {
                    $template[$key] = $value;
                }
            }
        }
        if (!$this->hasHoverImage($product, $imageId, $imageIdHover)
            && !$this->videoHelper->videoOnHover($product)
        ) {
            return $this->getResizedImage($product, $imageId, $size, $template[1], $attributes, $properties);
        }
        if ($this->videoHelper->videoOnHover($product)) {
            $imageIdHover = $imageId;
        }
        $imageMiscParams = $this->getImageParams($imageId);
        if (empty($size)) {
            $size = [$imageMiscParams['image_width'], $imageMiscParams['image_height']];
        } elseif (is_array($size)) {
            foreach (['image_width', 'image_height'] as $key => $value) {
                if (!isset($size[$key]) || empty($size[$key])) {
                    $size[$key] = $imageMiscParams[$value];
                }
            }
        }

        $image = $this->resizeImage($product, $imageId, $size, $properties);
        try {
            [
                $imageMiscParams['image_width'],
                $imageMiscParams['image_height']
            ] = $image->getResizedImageInfo();
        } catch (Exception $e) {
            $this->_logger->error("SP Product Image: " . $e->getMessage());
            $imageMiscParams['image_width'] = $imageMiscParams['image_height'] = 1;
        }
        $image = $image->getUrl();
        $imageHover = $this->resizeImage($product, $imageIdHover, $size, $properties)->getUrl();
        $imageHoverMiscParams = $this->getImageParams($imageIdHover);

        if (array_key_exists('class', $attributes)) {
            unset($attributes['class']);
        }

        $data = [
            'data' => [
                'template' => $template[0],
                'product_id' => $product->getId(),
                'product' => $product,
                'image_id' => $imageId,
                'image_hover_id' => $imageIdHover,
                'image_url' => $image,
                'image_hover_url' => $imageHover,
                'label' => $this->getLabel($product, $imageMiscParams['image_type']),
                'label_hover' => $this->getLabel($product, $imageHoverMiscParams['image_type']),
                'width' => $imageMiscParams['image_width'],
                'height' => $imageMiscParams['image_height'],
                'ratio' => $this->getRatio($imageMiscParams['image_width'], $imageMiscParams['image_height']),
                'class' => $this->getClass($attributes),
                'custom_attributes' => $this->getStringCustomAttributes($attributes),
            ],
        ];

        return $this->createTemplate($data);
    }

    /**
     * @param Product $product
     * @param string $imageId
     * @param array|int $size
     * @param string $template
     * @param array $attributes
     * @param array $properties
     *
     * @return CatalogBlockProductImage|mixed
     */
    public function getResizedImage(
        Product $product,
        $imageId,
        $size,
        $template = self::TEMPLATE,
        array $attributes = [],
        $properties = []
    ) {
        $imageMiscParams = $this->getImageParams($imageId);
        if (empty($size)) {
            return $this->getImage($product, $imageId, $template, $attributes, $properties);
        }
        if (is_array($size)) {
            foreach (['image_width', 'image_height'] as $key => $value) {
                if (!isset($size[$key]) || empty($size[$key])) {
                    $size[$key] = $imageMiscParams[$value];
                }
            }
        }
        $image = $this->resizeImage($product, $imageId, $size, $properties);
        $imageMiscParams = $this->getImageParams($imageId);
        try {
            [
                $imageMiscParams['image_width'],
                $imageMiscParams['image_height']
            ] = $image->getResizedImageInfo();
        } catch (Exception $e) {
            $this->_logger->error("SP Product Image: " . $e->getMessage());
            $imageMiscParams['image_width'] = $imageMiscParams['image_height'] = 1;
        }

        $data = [
            'data' => [
                'template' => $template,
                'product_id' => $product->getId(),
                'product' => $product,
                'image_id' => $imageId,
                'image_url' => $image->getUrl(),
                'label' => $this->getLabel($product, $imageMiscParams['image_type']),
                'width' => $imageMiscParams['image_width'],
                'height' => $imageMiscParams['image_height'],
                'ratio' => $this->getRatio($imageMiscParams['image_width'], $imageMiscParams['image_height']),
                'class' => $this->getClass($attributes),
                'custom_attributes' => $this->getStringCustomAttributes($attributes),
            ],
        ];

        return $this->createTemplate($data);
    }

    /**
     * @param Product $product
     * @param string $image
     * @param array|int $size
     * @param array $properties
     *
     * @return string
     */
    public function getUrlResizedImage(Product $product, $image, $size, $properties = [])
    {
        $image = $this->resizeImage($product, $image, $size, $properties);
        return $image->getUrl();
    }
}
