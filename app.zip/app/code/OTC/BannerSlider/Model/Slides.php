<?php

namespace OTC\BannerSlider\Model;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Io\File;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Magento\Framework\UrlInterface;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Slides
 */
class Slides extends AbstractModel
{

    /**
     * @var DirectoryList
     */
    protected $directoryList;

    /**
     * @var File
     */
    protected $io;

    /**
     * @var
     */
    protected $storeManager;

    /**
     * @var string
     */
    protected $eventPrefix = 'otc_bannerslider_slides';

    /**
     * @param Context $context
     * @param Registry $registry
     * @param StoreManagerInterface $storeManager
     * @param DirectoryList $directoryList
     * @param File $io
     */
    public function __construct(
        Context $context,
        Registry $registry,
        StoreManagerInterface $storeManager,
        DirectoryList $directoryList,
        File $io
    ) {
        $this->storeManager = $storeManager;
        $this->directoryList = $directoryList;
        $this->io = $io;
        parent::__construct($context, $registry);
    }

    /**
     * @return string[]
     */
    public function getIdentities()
    {
        return [$this->_eventPrefix . '_' . $this->getId()];
    }

    /**
     * @param $fieldId
     * @return string
     * @throws NoSuchEntityException
     */
    public function getImageUrl($fieldId = 'image')
    {
        return $this->getPrefixedPath(
            $this->getData($fieldId),
            rtrim(
                (string)$this->storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_MEDIA),
                '/'
            ) . '/'
        );
    }

    /**
     * @param $path
     * @param $prefix
     * @return string
     */
    private function getPrefixedPath($path, $prefix = '')
    {
        $fullPath = '';
        $path = ltrim($path, '/');
        if (!empty($path)) {
            $fullPath = $prefix . $path;
        }

        return $fullPath;
    }

    /**
     * @param $fieldId
     * @return bool
     */
    public function hasImage($fieldId = 'image')
    {

        return ((bool)$this->getData($fieldId) !== false && $this->existsImage());
    }

    /**
     * @param $fieldId
     * @return bool
     */
    public function existsImage($fieldId = 'image')
    {
        return is_file($this->getImagePath($fieldId));
    }

    /**
     * @param $fieldId
     * @return string
     */
    public function getImagePath($fieldId = 'image')
    {
        return $this->getPrefixedPath(
            $this->getData($fieldId),
            $this->directoryList->getRoot() . '/pub/media/'
        );
    }

    /**
     * @return void
     */
    public function _construct()
    {
        $this->_init(ResourceModel\Slides::class);
    }

}
