<?php

namespace OTC\Ecomm\Helper;

use Exception;
use Magento\Catalog\Helper\Product\Compare;
use Magento\Cms\Model\Template\FilterProvider;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Area;
use Magento\Framework\App\Cache\Frontend\Pool;
use Magento\Framework\App\Cache\TypeListInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Config\Storage\WriterInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\App\State;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\DesignInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Wishlist\Helper\Data;
use OTC\Core\Helper\Helper as OTCHelper;
use OTC\Ecomm\Block\ChildTemplate;

/**
 * Helper
 */
class Helper extends AbstractHelper
{

    const XML_ENABLED = 'ecomm_settings/general/enable';

    const CONFIG_MODULE = 'ecomm_settings';

    const CHILD_TEMPLATE = ChildTemplate::class;

    const XML_PATH_LAZY = 'ecomm_settings/general/lazyload';

    /**
     * @var array
     */
    protected $isArea = [];

    /**
     * @var WriterInterface
     */
    protected $writerInterface;

    /**
     * @var DesignInterface
     */
    protected $designInterface;

    /**
     * @var State
     */
    protected $state;

    /**
     * @var Session
     */
    protected $session;

    /**
     * @var Data
     */
    protected $wishlistHelper;

    /**
     * @var ProductMetadataInterface
     */
    protected $productMetadata;

    /**
     * @var Compare
     */
    protected $compareHelper;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManger;

    /**
     * @var Pool
     */
    protected $pool;

    /**
     * @var FilterProvider
     */
    protected $filterProvider;

    /**
     * @var UrlInterface
     */
    protected $urlInterface;

    /**
     * @var TypeListInterface
     */
    protected $typeList;

    /**
     * @var OTCHelper
     */
    protected $otcHelper;

    /**
     * @param Context $context
     * @param WriterInterface $writerInterface
     * @param DesignInterface $designInterface
     * @param State $state
     * @param Session $session
     * @param Data $wishlistHelper
     * @param ProductMetadataInterface $productMetadata
     * @param Compare $compareHelper
     * @param StoreManagerInterface $storeManager
     * @param Pool $pool
     * @param FilterProvider $filterProvider
     * @param UrlInterface $urlInterface
     * @param TypeListInterface $typeList
     * @param OTCHelper $otcHelper
     */
    public function __construct( //NOSONAR
        Context $context,
        WriterInterface $writerInterface,
        DesignInterface $designInterface,
        State $state,
        Session $session,
        Data $wishlistHelper,
        ProductMetadataInterface $productMetadata,
        Compare $compareHelper,
        StoreManagerInterface $storeManager,
        Pool $pool,
        FilterProvider $filterProvider,
        UrlInterface $urlInterface,
        TypeListInterface $typeList,
        OTCHelper $otcHelper
    ) {
        $this->context = $context;
        $this->writerInterface = $writerInterface;
        $this->designInterface = $designInterface;
        $this->state = $state;
        $this->session = $session;
        $this->wishlistHelper = $wishlistHelper;
        $this->productMetadata = $productMetadata;
        $this->compareHelper = $compareHelper;
        $this->storeManger = $storeManager;
        $this->pool = $pool;
        $this->filterProvider = $filterProvider;
        $this->urlInterface = $urlInterface;
        $this->typeList = $typeList;
        $this->otcHelper = $otcHelper;

        parent::__construct($context);
    }

    /**
     * @param string $path
     * @param integer $storeCode
     * @param string $scopeType
     * @return mixed
     */
    public function getModuleConfig($path = '', $storeCode = null, $scopeType = ScopeInterface::SCOPE_STORE)
    {
        if (empty($path)) {
            $path = static::CONFIG_MODULE;
        } else {
            $path = static::CONFIG_MODULE . '/' . $path;
        }
        return $this->getSystemValue($path, $storeCode, $scopeType);
    }

    /**
     * @param string $path
     * @param integer $storeCode
     * @param string $scopeType
     * @return mixed
     */
    public function getSystemValue($path, $storeCode = null, $scopeType = ScopeInterface::SCOPE_STORE)
    {
        $value = $this->scopeConfig->getValue(
            $path,
            $scopeType,
            $storeCode
        );
        if (is_null($value)) {
            $value = '';
        }
        return $value;
    }

    /**
     * @param $path
     * @param $value
     * @param $scope
     * @param $scopeId
     * @return mixed
     */
    public function setModuleConfig(
        $path,
        $value,
        $scope = ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
        $scopeId = 0
    ) {
        if (!empty($path)) {
            $path = static::CONFIG_MODULE . '/' . $path;
        }
        return $this->setSystemValue($path, $value, $scope, $scopeId);
    }

    /**
     * @param $path
     * @param $value
     * @param $scope
     * @param $scopeId
     * @return mixed
     */
    public function setSystemValue($path, $value, $scope = ScopeConfigInterface::SCOPE_TYPE_DEFAULT, $scopeId = 0)
    {
        return $this->writerInterface->save($path, $value, $scope, $scopeId);
    }


    /**
     * @param $path
     * @return mixed|string
     */
    public function getSystemDefaultValue($path)
    {
        $value = $this->scopeConfig->getValue(
            $path,
            ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
            0
        );
        if (is_null($value)) {
            $value = '';
        }
        return $value;
    }

    /**
     * @return bool
     */
    public function isLazyLoadEnabled()
    {
        return $this->getSystemValue(Helper::XML_ENABLED)
            && $this->getSystemValue(Helper::XML_PATH_LAZY)
            && $this->otcHelper->isLazyLoadEnabled();
    }

    /**
     * @return bool
     */
    public function isEnabled()
    {
        return (bool)$this->getConfig(static::XML_ENABLED);
    }

    /**
     * @param $path
     * @param $storeCode
     * @return mixed|string
     */
    public function getConfig($path, $storeCode = null)
    {
        return $this->getSystemValue($path, $storeCode);
    }

    /**
     * @param $block
     * @param $optionPath
     * @param $fileName
     * @param $arguments
     * @return void
     */
    public function getLayoutTemplateHtml($block, $optionPath = '', $fileName = '', $arguments = [])
    {
        $value = $this->getConfig($optionPath);

        if (is_string($value) || is_numeric($value)) {
            return $this->getLayoutTemplateHtmlbyValue($block, $value, $fileName, $arguments);
        }
    }

    /**
     * @param $block
     * @param $value
     * @param $fileName
     * @param $arguments
     * @param $separator
     * @return mixed
     */
    public function getLayoutTemplateHtmlbyValue(
        $block,
        $value = null,
        $fileName = null,
        $arguments = [],
        $separator = '/'
    ) {
        $newfileName = '';
        if (empty($fileName)) {
            $blockTemplate = $block->getTemplate();
            if (preg_match('/(\.[^\.]+?)$/', $blockTemplate)) { //NOSONAR
                $fileName = preg_replace('/(\.[^\.]+?)$/', '%s%s$1', $blockTemplate); //NOSONAR
            } else {
                $fileName .= '%s%s';
            }
            if (!preg_match('#([^_:]+)_([^_:]+)::#i', $fileName)) {
                $className = array_slice(array_filter(explode('\\', get_class($block))), 0, 2);
                if ('Magento' !== $className[0]) {
                    $fileName = implode('_', $className) . '::' . $fileName;
                }
            }
        } else {
            $newfileName = $fileName;
        }
        $blockName = $separator . $block->getNameInLayout() . $separator . $newfileName . $separator . $value;
        $fileName = sprintf($fileName, $separator, $value);
        while ($block->getLayout()->getBlock($blockName)) {
            $blockName .= '_0';
        }
        $block = $block->getLayout()->createBlock(static::CHILD_TEMPLATE, $blockName);
        $block->setChild($block->getNameInLayout(), $block);
        if (!empty($arguments) && is_array($arguments)) {
            $block->addData($arguments);
        }

        return $block->setTemplate($fileName)->toHtml();
    }

    /**
     * @return bool|mixed
     */
    public function isAdmin()
    {
        return $this->isArea(Area::AREA_ADMINHTML);
    }

    /**
     * @param $area
     * @return bool|mixed
     */
    public function isArea($area = Area::AREA_FRONTEND)
    {
        if (!isset($this->isArea[$area])) {
            /** @var State $state */
            $state = $this->state;

            try {
                $this->isArea[$area] = ($state->getAreaCode() == $area);
            } catch (Exception $e) {
                $this->isArea[$area] = false;
            }
        }

        return $this->isArea[$area];
    }

    /**
     * @param $path
     * @param $scope
     * @param $scopeId
     * @return mixed
     */
    public function deleteSystemValue($path, $scope = ScopeConfigInterface::SCOPE_TYPE_DEFAULT, $scopeId = 0)
    {
        return $this->writerInterface->delete($path, $scope, $scopeId);
    }


    /**
     * @return mixed
     */
    public function isLoggedIn()
    {
        return $this->session->isLoggedIn();
    }

    /**
     * @return mixed
     */
    public function getWishlistCount()
    {
        return $this->wishlistHelper->getItemCount();
    }

    /**
     * @return mixed
     */
    public function getCompareListUrl()
    {
        return $this->compareHelper->getListUrl();
    }

    /**
     * @return mixed
     */
    public function getCompareListCount()
    {
        return $this->compareHelper->getItemCount();
    }

    /**
     * @param $name
     * @return bool
     */
    public function isActivePlugin($name)
    {
        return $this->_moduleManager->isOutputEnabled($name);
    }

    /**
     * @return mixed
     */
    public function getVersion()
    {
        return $this->productMetadata->getVersion();
    }

    /**
     * @param $content
     * @return mixed
     */
    public function getBlockTemplateProcessor($content = '')
    {
        if (empty($content) || !is_string($content)) {
            $content = '';
        }
        return $this->filterProvider->getBlockFilter()->filter(trim($content));
    }

    /**
     * @return bool
     */
    public function isHomePage()
    {
        $currentUrl = $this->getUrl('', ['_current' => true]);
        $urlRewrite = $this->getUrl('*/*/*', ['_current' => true, '_use_rewrite' => true]);
        return $currentUrl == $urlRewrite;
    }

    /**
     * @param $route
     * @param $params
     * @return string
     */
    public function getUrl($route = '', $params = [])
    {
        return $this->urlInterface->getUrl($route, $params);
    }

    /**
     * @return bool
     */
    public function isAccountPage()
    {
        $request = $this->context->getRequest();
        return $request->getFullActionName() == 'customer_account_login';
    }

    /**
     * @return bool
     */
    public function isMulticheckout()
    {
        $request = $this->context->getRequest();
        return $request->getFullActionName() == 'multishipping_checkout_login';
    }

    /**
     * @return bool
     */
    public function isMobile()
    {
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $result = false;
        if (!empty($user_agent)) {
            $result = preg_match(
                    '/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino|android|ipad|playbook|silk/i',
                    $user_agent) || preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',
                    substr($user_agent, 0, 4)
                );
        }

        return $result;
    }


}
