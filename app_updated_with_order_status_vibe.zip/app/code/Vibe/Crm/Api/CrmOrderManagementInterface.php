<?php
declare(strict_types=1);

namespace Vibe\Crm\Api;

use Vibe\Crm\Api\Data\CrmDataInterface;

interface CrmOrderManagementInterface
{
    /**
     * POST for CrmOrder api
     * @param  mixed $order_ids
     * @return CrmDataInterface
     */
    public function postOrderItems($order_ids);
}
