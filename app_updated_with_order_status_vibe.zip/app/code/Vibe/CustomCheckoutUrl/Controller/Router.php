<?php

namespace Vibe\CustomCheckoutUrl\Controller;

class Router implements \Magento\Framework\App\RouterInterface
{

    /**
     * @var \Magento\Framework\App\ActionFactory
     */

    protected $actionFactory;

    /**
     * @param \Magento\Framework\App\ActionFactory $actionFactory
     */

    public function __construct(
        \Magento\Framework\App\ActionFactory $actionFactory
    )
    {
        $this->actionFactory = $actionFactory;
    }

    /**
     * @param \Magento\Framework\App\RequestInterface $request
     * @return bool
     */
    public function match(\Magento\Framework\App\RequestInterface $request)
    {
        $uri = \Vibe\CustomCheckoutUrl\Plugin\Helper::getArrayPathInfo($request->getPathInfo());
        $route = [];
        //cart page url redirect
        if (count($uri) == 1 && ($uri[0] == 'cart')) {
            $route = [
                'module' => 'checkout',
                'controller' => 'cart',
                'action' => 'index'
            ];
        }

         if (count($uri) == 2 && ($uri[0] == 'checkout') && $uri[1] == 'order-confirmation') {

            $route = [
                'module' => 'checkout',
                'controller' => 'onepage',
                'action' => 'success'
            ];
             $uri[0] ='checkout/order-confirmation';
        }

        if (count($uri) == 2 && ($uri[0] == 'checkout') && $uri[1] == 'payment-error') {
            $route = [
                'module' => 'checkout',
                'controller' => 'onepage',
                'action' => 'failure'
            ];
            $uri[0] ='checkout/payment-error';
        }
        if (!empty($route)) {
            $module = $request->setModuleName($route['module']);
            $module->setControllerName($route['controller'])->setActionName($route['action']);
            $request->setAlias(\Magento\Framework\Url::REWRITE_REQUEST_PATH_ALIAS, $uri[0]);
            return $this->actionFactory->create('Magento\Framework\App\Action\Forward');
        } else {
            return null;
        }

    }

}
