var config = {
    paths: {
        'EcommSlideshow/templates': 'OTC_EcommSlideshow/js/templates',
    }
};