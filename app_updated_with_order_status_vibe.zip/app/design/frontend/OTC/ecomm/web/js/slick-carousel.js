define([
    'jquery',
    'slick'
], function ($) {

    const slickCarousel = $(".slick-carousel-container > .slick-carousel-item");

    if (slickCarousel?.length) {
        $(".slick-carousel-container").slick({
            slidesToScroll: 1,
            swipeToSlide: true,
            slidesToShow: 3,
            infinite: false,
            dots: true,
            arrows: false,
            responsive: [
                {
                    breakpoint: 950,
                    settings: {
                        dots: true,
                        arrows: true,
                        slidesToShow: 2,
                        slidesToScroll: 1
                    }
                },
                {
                    breakpoint: 640,
                    settings: {
                        dots: true,
                        arrows: true,
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        })
    }

    const slickReviewCarousel = $(".slick-carousel-review-container > .slick-carousel-item");

    if (slickReviewCarousel?.length) {
        $(".slick-carousel-review-container").slick({
            slidesToScroll: 1,
            swipeToSlide: true,
            slidesToShow: 1,
            infinite: false,
            dots: false,
            arrows: true,
            autoplay:true,
            autoplaySpeed:5000,
            responsive: [
                {
                    breakpoint: 950,
                    settings: {
                        dots: false,
                        arrows: true,
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                },
                {
                    breakpoint: 640,
                    settings: {
                        dots: false,
                        arrows: true,
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        });
        $(".prev-btn").click(function () {
            $(".slick-carousel-review-container").slick("slickPrev");
        });
        $(".next-btn").click(function () {
            $(".slick-carousel-review-container").slick("slickNext");
        });
        $(".prev-btn").addClass("slick-disabled");
        $('.slick-carousel-review-container').on('afterChange', function (event, slick, currentSlide) {
            if(currentSlide === 1){
                $(".prev-btn").removeClass("slick-disabled");
                $(".next-btn").removeClass("slick-disabled");
            }
            if(currentSlide === 2){
                $(".next-btn").addClass("slick-disabled");
            }
            if(currentSlide === 0){
                $(".prev-btn").addClass("slick-disabled");
            }
        });
    }

    $('.teaser-cards-wrapper-hearing-aid .pagebuilder-column-group').slick({
        slidesToScroll: 1,
        swipeToSlide: true,
        slidesToShow: 3,
        infinite: false,
        dots: true,
        arrows: false,
        responsive: [
            {
                breakpoint: 950,
                settings: {
                    dots: true,
                    arrows: true,
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 640,
                settings: {
                    dots: true,
                    arrows: true,
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    })

});
