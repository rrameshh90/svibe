<?php

declare(strict_types=1);

namespace Vibe\StripeOrder\Cron;

use Magento\Sales\Api\OrderRepositoryInterface;
use Vibe\CustomCheckoutUrl\Plugin\Helper;
use Vibe\StripeOrder\Model\Api\PaymentInformation;
use Vibe\StripeOrder\Logger\Logger;
use Vibe\StripeOrder\Helper\Data;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Sales\Model\Service\InvoiceService;
use Magento\Sales\Model\Order\Email\Sender\InvoiceSender;
use Magento\Framework\DB\Transaction;
use \Magento\Sales\Api\OrderManagementInterface;

class OrderStatusUpdate
{
    /**
     * @var Logger
     */
    protected $logger;
    /**
     * @var OrderRepository
     */
    protected $orderRepository;

    /**
     * @var  Data
     */
    protected $helper;

    /**
     * @var PaymentInformation
     */
    protected $paymentInformation;

    protected $order;

    protected $orderCollectionFactory;

    /**
     * @var \Magento\Sales\Model\Service\InvoiceService
     */
    protected InvoiceService $_invoiceService;

    /**
     * @var \Magento\Framework\DB\Transaction
     */
    protected Transaction $_transaction;
    protected InvoiceSender $invoiceSender;

    protected OrderManagementInterface $orderManagement;

    /**
     * @param Logger $logger
     * @param OrderRepositoryInterface $orderRepository
     * @param Helper $helper
     * @param PaymentInformation $paymentInformation
     * @param Order $order
     * @param CollectionFactory $orderCollectionFactory ;
     * @param InvoiceService $invoiceService
     * @param InvoiceSender $invoiceSender
     * @param Transaction $transaction
     * @param OrderManagementInterface $orderManagement
     */
    public function __construct(
        Logger $logger,
        OrderRepositoryInterface $orderRepository,
        Helper $helper,
        PaymentInformation $paymentInformation,
        Order $order,
        CollectionFactory $orderCollectionFactory,
        InvoiceService $invoiceService,
        InvoiceSender $invoiceSender,
        Transaction $transaction,
        OrderManagementInterface $orderManagement
    )
    {
        $this->logger = $logger;
        $this->orderRepository = $orderRepository;
        $this->helper = $helper;
        $this->paymentInformation = $paymentInformation;
        $this->order = $order;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->_invoiceService = $invoiceService;
        $this->invoiceSender = $invoiceSender;
        $this->_transaction = $transaction;
        $this->orderManagement = $orderManagement;
    }


    public function execute()
    {
        $orderCollection = $this->orderCollectionFactory->create()
            ->addAttributeToSelect('*')
            ->addFieldToFilter('status', 'pending')->setOrder('entity_id','DESC');
        foreach ($orderCollection as $order) {
                $orderId = $order->getId();
                $this->logger->info("OrderID " . $orderId);
                $paymentInfo = $this->paymentInformation->getOrderItem($orderId);
                $order = $this->orderRepository->get($orderId);
                if (!empty($paymentInfo) && !empty($paymentInfo[0]['message'])) {
                    $this->logger->info("Payment Info");
                    if ($paymentInfo[0]['message'] != "" && array_key_exists("payment_status",$paymentInfo[0]['message']) && $paymentInfo[0]['message']['payment_status'] == "unpaid") {
                        $this->logger->info("U");
                        $this->logger->info(print_r($paymentInfo[0]['message']));
                        if ($order->canCancel()) {
                            $this->logger->info("Cancel trigger");
                            //$order->setStatus("canceled");
                            $this->orderManagement->cancel($orderId);
                            //$order->save();
                            $this->logger->info("Cancel status updated for Order ID:".$orderId);
                        } else {
                            $this->logger->info("Cancel status not updated for Order ID:".$orderId);
                        }
                    }elseif($paymentInfo[0]['message'] != "" && array_key_exists("payment_status",$paymentInfo[0]['message']) && $paymentInfo[0]['message']['payment_status'] == "paid") {
                        if($order->canInvoice()) {
                            $this->logger->info("Invoice trigger");
                            $invoice = $this->_invoiceService->prepareInvoice($order);
                            $invoice->register();
                            $invoice->setState(\Magento\Sales\Model\Order\Invoice::STATE_PAID);
                            $invoice->getOrder()->setIsInProcess(true);
                            $invoice->save();
                            $transactionSave = $this->_transaction->addObject($invoice)->addObject($invoice->getOrder());
                            $transactionSave->save();
                            $this->invoiceSender->send($invoice);
                            //send notification code
                            $order->addStatusHistoryComment(
                                __('Notified customer about invoice #%1.', $invoice->getId())
                            )
                                ->setIsCustomerNotified(true)
                                ->save();
                            $this->logger->info("Invoice created for Order ID:".$orderId);
                        }else{
                            $this->logger->info("No Invoice created for Order ID:".$orderId);
                        }
                    }else{
                        $this->logger->info("Cancel status not updated for Order ID:".$orderId);
                    }
                }
        }
        return $this;

    }
}
