<?php
namespace Vibe\AdvancedCheckout\Block\Onepage;

class Success extends \Magento\Checkout\Block\Onepage\Success
{
    /**
     * Constructor Modification
     *
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Sales\Model\Order\Config $orderConfig
     * @param \Magento\Framework\App\Http\Context $httpContext
     * @param array $data
     */

     protected $priceCurrency; 

     protected $orderRepository;
 
     protected $currency;
 
     protected $addressRenderer;

     protected $order;

     protected $storeManager;
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Sales\Model\Order\Config $orderConfig,
        \Magento\Framework\App\Http\Context $httpContext,
        \Magento\Framework\Pricing\PriceCurrencyInterface $priceCurrency,
        \Magento\Sales\Model\OrderRepository $orderRepository,
        \Magento\Directory\Model\Currency $currency,
        \Magento\Sales\Model\Order\Address\Renderer $addressRenderer,
        \Magento\Sales\Model\Order $order,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        array $data = []
    ) {
        $this->priceCurrency = $priceCurrency;
        $this->orderRepository = $orderRepository;
        $this->currency = $currency;
        $this->addressRenderer = $addressRenderer;
        $this->order = $order;
        $this->storeManager = $storeManager;
        parent::__construct(
            $context,
            $checkoutSession,
            $orderConfig,
            $httpContext,
            $data
        );
    }
     /**
     * Get current store currency code
     *
     * @return string
     */
    public function getCurrentCurrencyCode()
    {
        return $this->storeManager->getStore()->getCurrentCurrencyCode();
    }    
    
    /**
     * Get default store currency code
     *
     * @return string
     */
    public function getDefaultCurrencyCode()
    {
        return $this->storeManager->getStore()->getDefaultCurrencyCode();
    }

    public function getCurrentCurrencySymbolByCode($currencyCode)
    {
        return  $this->currency->load($currencyCode)->getCurrencySymbol();
    }

    public function getCurrencyWithFormat($price)
    {
        return $this->priceCurrency->format($price,true,2);
    }
 
    public function getRoundedPrice($price)
    {
        return $this->priceCurrency->round($price);
    }
 
    public function getCurrentCurrencySymbol()
    {
        return $this->priceCurrency->getCurrencySymbol();
    }

    public function getOrderInfo($orderId){
            return $this->order->loadByIncrementId($orderId);
    }

    public function getOrderPaymentFormat($price,$currencySymbol){
        return $this->currency->format($price, ['symbol' => $currencySymbol, 'precision'=> 2], false, false);
    }

    public function getAddressFormatHtml($address){
        return $this->addressRenderer->format($address, 'html');
    }
}

