<?php

namespace Vibe\Contact\Api\Data;

/**
 * Grid Interface
 */
interface GridInterface
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case.
     */
    const ID = 'id';
    const FIRSTNAME = 'firstname';

    const LASTNAME = 'lastname';
    const COMMENT = 'comment';
    const CATEGORY = 'category';
    const EMAIL = 'email';
    const PRIVACY = 'privacy';
    const STORE = 'store_id';
    const WEBSITE = 'website';
    const PHONE = 'phone';
    const CREATED_AT = 'created_at';

   /**
    * Get EntityId.
    *
    * @return int
    */
    public function getId();

   /**
    * Set EntityId.
    * @return $this
    */
    public function setId($id);

   /**
    * Get FirstName.
    *
    * @return string|null
    */
    public function getFirstName();

   /**
    * Set FirstName.
    *
    * @return $this
    */
    public function setFirstName($name);

    /**
     * Get LastName.
     *
     * @return string|null
     */
    public function getLastName();

    /**
     * Set LastName.
     *
     * @return $this
     */
    public function setLastName($name);

    /**
     * Get Email.
     *
     * @return string|null
     */
    public function getEmail();

    /**
     * Set Email.
     *
     * @return $this
     */
    public function setEmail($name);

   /**
    * Get Comment.
    *
    * @return string|null
    */
    public function getComment();

   /**
    * Set Comment.
    *
    * @return $this
    */
    public function setComment($comment);

   /**
    * Get Category.
    *
    * @return string|null
    */
    public function getCategory();

   /**
    * Set Category.
    *
    * @return $this
    */
    public function setCategory($category);

   /**
    * Get Phone.
    *
    * @return string|null
    */
    public function getPhone();

   /**
    * Set Phone.
    *
    * @return $this
    */
    public function setPhone($phone);

   /**
    * Get Privacy.
    *
    * @return string|null
    */
    public function getPrivacy();

   /**
    * Set Privacy.
    *
    * @return $this
    */
    public function setPrivacy($privacy);

   /**
    * Get CreatedAt.
    *
    * @return string|null
    */
    public function getCreatedAt();

   /**
    * Set CreatedAt.
    *
    * @return $this
    */
    public function setCreatedAt($createdAt);

    /**
     * Get Website.
     *
     * @return string|null
     */
    public function getStoreId();

    /**
     * Set Store.
     *
     * @return $this
     */
    public function setStoreId($store);

    /**
     * Get Store.
     *
     * @return string|null
     */
    public function getWebsite();

    /**
     * Set Website.
     *
     * @return $this
     */
    public function setWebsite($website);

}
