<?php

namespace Vibe\AdvancedCheckout\Model;


use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Checkout\Model\Session;
use Magento\Quote\Model\QuoteRepository;

class AdditionalConfigVars implements ConfigProviderInterface
{
    /**
     * @param Session $checkoutSession
     * @param QuoteRepository $quoteRepository
     */
    public function __construct(
        Session $checkoutSession,
        QuoteRepository $quoteRepository)
    {
        $this->checkoutSession = $checkoutSession;
        $this->quoteRepository = $quoteRepository;
    }
    /**
     * set the window checkout additional getConfig value for otcMarketingConsent
     * @return String
     */
    public function getConfig()
   {
        $quoteId = $this->checkoutSession->getQuoteId();
        $quote = $this->quoteRepository->get($quoteId);
        $otc_market_consent=$quote->getOtcMarketingConsent();
        $additionalVariables['otcMarketingConsent'] = $otc_market_consent;
        return $additionalVariables;
   }
}