<?php

namespace OTC\Ecomm\Block;

use Magento\Customer\Model\Context;
use Magento\Customer\Model\Session;
use Magento\Customer\Model\Url;
use Magento\Framework\View\Element\Template;
use OTC\Ecomm\Helper\Helper as EcommHelper;

/**
 * TopLinks
 */
class TopLinks extends SimpleTemplate
{
    /**
     * @var \Magento\Framework\App\Http\Context
     */
    protected $httpContext;

    /**
     * @var Url
     */
    protected $customerUrl;

    /**
     * @var EcommHelper
     */
    protected $ecommHelper;

    /**
     * @param Template\Context $context
     * @param Session $session
     * @param \Magento\Framework\App\Http\Context $httpContext
     * @param Url $customerUrl
     * @param EcommHelper $ecommHelper
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Session $session,
        \Magento\Framework\App\Http\Context $httpContext,
        Url $customerUrl,
        EcommHelper $ecommHelper,
        array $data = []
    ) {
        $this->ecommHelper = $ecommHelper;
        $this->httpContext = $httpContext;
        $this->_customerUrl = $customerUrl;
        parent::__construct($context, $session, $data);
    }

    /**
     * @return mixed
     */
    public function getCompareListUrl()
    {
        return $this->ecommHelper->getCompareListUrl();
    }

    /**
     * @return string
     */
    public function getLoginUrl()
    {
        return $this->_customerUrl->getLoginUrl();
    }

    /**
     * @return string
     */
    public function getLogoutUrl()
    {
        return $this->_customerUrl->getLogoutUrl();
    }

    /**
     * Is logged in
     *
     * @return bool
     */
    public function isLoggedIn()
    {
        return $this->httpContext->getValue(Context::CONTEXT_AUTH);
    }

}
