<?php

namespace OTC\BannerSlider\Model;

use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Io\File;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Group
 */
class Group extends AbstractModel
{

    /**
     * @var DirectoryList
     */
    protected $directoryList;

    /**
     * @var File
     */
    protected $io;

    /**
     * @var
     */
    protected $storeManager;

    /**
     * @var string
     */
    protected $eventPrefix = 'otc_bannerslider_group';

    /**
     * @param Context $context
     * @param Registry $registry
     * @param StoreManagerInterface $storeManager
     * @param DirectoryList $directoryList
     * @param File $io
     */
    public function __construct(
        Context $context,
        Registry $registry,
        StoreManagerInterface $storeManager,
        DirectoryList $directoryList,
        File $io
    ) {
        $this->_storeManager = $storeManager;
        $this->directoryList = $directoryList;
        $this->io = $io;
        parent::__construct($context, $registry);
    }

    /**
     * @return string[]
     */
    public function getIdentities()
    {
        return [$this->_eventPrefix . '_' . $this->getId()];
    }

    /**
     * @return array|mixed|null
     */
    public function getIdentifier()
    {
        return $this->getData('identifier');
    }

    /**
     * @return void
     */
    public function _construct()
    {
        $this->_init(ResourceModel\Group::class);
    }

}
